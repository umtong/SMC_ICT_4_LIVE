#!/usr/bin/env python3
"""Evaluate the public Smallfish family on real Binance flow/depth data."""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
WORK = REPO / ".work" / "candidate-51-smallfish-v18"
ARTIFACTS = REPO / "artifacts" / "candidate-51"
CACHE = REPO / ".cache" / "candidate-51-smallfish-v18"
EVIDENCE = HERE / "evidence" / "v18-smallfish-real-flow"

DEVELOPMENT = ("2025-06-02", "2025-06-08")
HOLDOUT = ("2024-11-04", "2024-11-10")
CONTINUOUS_30D = ("2025-01-01", "2025-01-30")
CONTINUOUS_90D = ("2024-04-01", "2024-06-29")

VARIANTS: dict[str, dict[str, Any]] = {
    "source_aggressive_5m": {
        "bucket": 5,
        "signals": 3,
        "confidence": 0.58,
        "sl_range": 1.00,
        "tp_range": 2.50,
        "trail": 0.20,
        "activation_r": 0.30,
        "min_stop": 0.0010,
        "min_target": 0.0025,
        "min_rr": 1.20,
        "opposite_exit": 2.0,
        "max_hold_candles": 12,
        "description": "public aggressive profile on five-minute observations",
    },
    "source_starter_5m": {
        "bucket": 5,
        "signals": 4,
        "confidence": 0.58,
        "sl_range": 0.80,
        "tp_range": 2.00,
        "trail": 0.25,
        "activation_r": 0.30,
        "min_stop": 0.0015,
        "min_target": 0.0030,
        "min_rr": 1.30,
        "opposite_exit": 2.0,
        "max_hold_candles": 10,
        "description": "public starter_50 profile with project risk sizing",
    },
    "realflow_cost_5m": {
        "bucket": 5,
        "signals": 3,
        "confidence": 0.58,
        "sl_range": 1.00,
        "tp_range": 3.50,
        "trail": 0.25,
        "activation_r": 0.30,
        "min_stop": 0.0025,
        "min_target": 0.0080,
        "min_rr": 2.00,
        "opposite_exit": 0.65,
        "max_hold_candles": 12,
        "description": "source fusion with Binance-cost-aware geometry",
    },
    "source_aggressive_1m": {
        "bucket": 1,
        "signals": 3,
        "confidence": 0.58,
        "sl_range": 1.00,
        "tp_range": 2.50,
        "trail": 0.20,
        "activation_r": 0.30,
        "min_stop": 0.0010,
        "min_target": 0.0025,
        "min_rr": 1.20,
        "opposite_exit": 2.0,
        "max_hold_candles": 12,
        "description": "public aggressive profile at source backtest cadence",
    },
    "realflow_cost_1m": {
        "bucket": 1,
        "signals": 3,
        "confidence": 0.55,
        "sl_range": 1.00,
        "tp_range": 3.00,
        "trail": 0.25,
        "activation_r": 0.30,
        "min_stop": 0.0015,
        "min_target": 0.0050,
        "min_rr": 1.75,
        "opposite_exit": 0.65,
        "max_hold_candles": 12,
        "description": "dense real-flow source with cost-aware target space",
    },
    "quality_realflow_1m": {
        "bucket": 1,
        "signals": 4,
        "confidence": 0.58,
        "sl_range": 0.80,
        "tp_range": 2.50,
        "trail": 0.25,
        "activation_r": 0.30,
        "min_stop": 0.0020,
        "min_target": 0.0060,
        "min_rr": 1.75,
        "opposite_exit": 0.70,
        "max_hold_candles": 10,
        "description": "stricter real-flow agreement and cost geometry",
    },
}


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def frozen_config(base: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(base)
    for key in (
        "sma_offset_low",
        "sma_offset_high",
        "sma_stop_min_fraction",
        "sma_stop_max_fraction",
        "sma_stop_atr_buffer",
    ):
        config["strategy"].pop(key, None)
    bucket = int(spec["bucket"])
    config["strategy"].update(
        {
            "cooldown_minutes": 0,
            "max_hold_minutes": bucket * int(spec["max_hold_candles"]),
            "funding_flatten_minute": 60,
            "funding_blackout_before_minutes": -1,
            "funding_blackout_after_minutes": -1,
            "smallfish_bucket_minutes": bucket,
            "smallfish_ema_fast": 3,
            "smallfish_ema_slow": 8,
            "smallfish_range_period": 20,
            "smallfish_vwap_period": 20,
            "smallfish_alpha": 4.0,
            "smallfish_enter_confidence": float(spec["confidence"]),
            "smallfish_exit_confidence": 0.30,
            "smallfish_min_signals": int(spec["signals"]),
            "smallfish_signal_threshold": 0.10,
            "smallfish_prt_cancel_threshold": 0.60,
            "smallfish_prt_max_move_fraction": 0.50,
            "smallfish_sl_range_mult": float(spec["sl_range"]),
            "smallfish_tp_range_mult": float(spec["tp_range"]),
            "smallfish_min_stop_fraction": float(spec["min_stop"]),
            "smallfish_min_target_fraction": float(spec["min_target"]),
            "smallfish_min_reward_r": float(spec["min_rr"]),
            "smallfish_trail_pct": float(spec["trail"]),
            "smallfish_trail_activation_r": float(spec["activation_r"]),
            "smallfish_max_hold_candles": int(spec["max_hold_candles"]),
            "smallfish_opposite_exit_confidence": float(
                spec["opposite_exit"]
            ),
            "smallfish_low_mvr": 0.65,
            "smallfish_high_mvr": 1.50,
            "smallfish_extreme_mvr": 4.00,
            "smallfish_w_obi": 0.22,
            "smallfish_w_prt": 0.10,
            "smallfish_w_umom": 0.15,
            "smallfish_w_ltb": 0.08,
            "smallfish_w_sweep": 0.05,
            "smallfish_w_ice": 0.03,
            "smallfish_w_vwap": 0.05,
            "smallfish_w_regime": 0.02,
            "smallfish_w_cvd": 0.07,
            "smallfish_w_tps": 0.05,
            "smallfish_w_liq": 0.06,
            "smallfish_w_mvr": 0.06,
            "smallfish_w_absorb": 0.06,
        }
    )
    return config


def run_case(
    *,
    label: str,
    config_path: Path,
    interval: tuple[str, str],
) -> tuple[int, Path]:
    output = ARTIFACTS / f"smallfish-v18-{label}"
    workspace = WORK / f"workspace-{label}"
    command = [
        sys.executable,
        str(HERE / "launch.py"),
        "--config",
        str(config_path),
        "--start",
        interval[0],
        "--end",
        interval[1],
        "--cache",
        str(CACHE),
        "--output",
        str(output),
        "--workspace",
        str(workspace),
    ]
    env = dict(os.environ)
    env["PYTHONPATH"] = str(HERE)
    completed = subprocess.run(
        command,
        cwd=REPO,
        env=env,
        check=False,
    )
    return completed.returncode, output


def summarize(output: Path, returncode: int) -> dict[str, Any]:
    metrics_path = output / "metrics.json"
    diagnostics_path = output / "strategy_diagnostics.json"
    if (
        returncode != 0
        or not metrics_path.is_file()
        or not diagnostics_path.is_file()
    ):
        return {"produced": False, "returncode": returncode}
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    diagnostics = json.loads(diagnostics_path.read_text(encoding="utf-8"))
    gate_checks = metrics.get("gate_checks", {})
    return {
        "produced": True,
        "returncode": returncode,
        **{
            key: metrics.get(key)
            for key in (
                "calendar_days",
                "ending_nav",
                "total_return",
                "geometric_daily_growth",
                "max_drawdown",
                "min_equity",
                "trades",
                "wins",
                "losses",
                "win_rate",
                "profit_factor",
                "expectancy_usdt",
                "largest_winner_share",
                "active_days",
            )
        },
        "no_liquidation": gate_checks.get("no_liquidation"),
        "source_signals": diagnostics.get(
            "source_signals_before_execution_filters"
        ),
        "source_edges": diagnostics.get("smallfish_source_edges"),
        "entries": diagnostics.get("entry_submissions"),
        "trailing_activations": diagnostics.get(
            "smallfish_trailing_activations"
        ),
        "trailing_exits": diagnostics.get("smallfish_trailing_exits"),
        "opposite_exits": diagnostics.get("smallfish_opposite_exits"),
        "selected_symbols": diagnostics.get("selected_symbols"),
        "actionable_family_counts": diagnostics.get(
            "actionable_family_counts"
        ),
        "unresolved_reason_counts": diagnostics.get(
            "unresolved_reason_counts"
        ),
        "global_position_violations": diagnostics.get(
            "global_position_violations"
        ),
        "order_rejections": diagnostics.get("order_rejections"),
    }


def component_pass(row: dict[str, Any], days: int) -> bool:
    return bool(
        row.get("produced")
        and int(row.get("trades") or 0) >= days
        and float(row.get("expectancy_usdt") or 0.0) > 0.0
        and float(row.get("geometric_daily_growth") or 0.0) > 0.0
        and float(row.get("max_drawdown") or 1.0) <= 0.20
        and float(row.get("min_equity") or 0.0) > 0.0
        and bool(row.get("no_liquidation"))
        and int(row.get("global_position_violations") or 0) == 0
        and int(row.get("order_rejections") or 0) == 0
    )


def target_pass(row: dict[str, Any], days: int) -> bool:
    return bool(
        component_pass(row, days)
        and float(row.get("geometric_daily_growth") or 0.0) >= 0.01
    )


def preserve_case(source: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for name in (
        "metrics.json",
        "strategy_diagnostics.json",
        "run.json",
        "data_manifest.json",
    ):
        path = source / name
        if path.is_file():
            shutil.copy2(path, destination / name)


def main() -> int:
    WORK.mkdir(parents=True, exist_ok=True)
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    CACHE.mkdir(parents=True, exist_ok=True)
    if EVIDENCE.exists():
        shutil.rmtree(EVIDENCE)
    EVIDENCE.mkdir(parents=True, exist_ok=True)

    base = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
    configs: dict[str, Path] = {}
    for name, spec in VARIANTS.items():
        path = WORK / f"{name}.json"
        write_json(path, frozen_config(base, spec))
        configs[name] = path

    manifest = {
        "family": "public_smallfish_real_flow_v18",
        "source": {
            "repository": "azseza/smallfish_",
            "public_claims_used_only_as_search_signal": {
                "seven_day_trades": "269-412",
                "seven_day_return": "+28.5% to +76.3%",
                "parameter_sweep": (
                    "hundreds of trades and positive PF/returns in many rows"
                ),
            },
            "implementation_error_separated_from_logic": {
                "rejected": (
                    "source backtest synthetic order book and synthetic trade tape"
                ),
                "retained": (
                    "13-category fusion, source weights, agreement gate, range stop/target, 0.3R range trail, no partial TP"
                ),
                "replacement_observations": (
                    "checksum-verified Binance aggTrades and bookDepth features"
                ),
            },
        },
        "variants": VARIANTS,
        "development_interval": DEVELOPMENT,
        "untouched_interval": HOLDOUT,
        "conditional_30d_interval": CONTINUOUS_30D,
        "conditional_90d_interval": CONTINUOUS_90D,
        "engine": "NautilusTrader BacktestNode",
        "risk_fraction": 0.03,
        "global_entry_or_position_limit": 1,
        "cost_model": {
            "all_in_cost_bps_each_side": base[
                "all_in_cost_bps_each_side"
            ],
            "adverse_slippage_bps_each_side": base[
                "adverse_slippage_bps_each_side"
            ],
            "funding_reserve_bps": base["funding_reserve_bps"],
        },
        "router_sha256": hashlib.sha256(
            (HERE / "router.py").read_bytes()
        ).hexdigest(),
        "strategy_sha256": hashlib.sha256(
            (HERE / "strategy.py").read_bytes()
        ).hexdigest(),
    }
    write_json(EVIDENCE / "manifest.json", manifest)

    development: dict[str, dict[str, Any]] = {}
    outputs: dict[str, Path] = {}
    for name in VARIANTS:
        returncode, output = run_case(
            label=f"{name}-development",
            config_path=configs[name],
            interval=DEVELOPMENT,
        )
        outputs[name] = output
        development[name] = summarize(output, returncode)
    eligible = [
        name
        for name, row in development.items()
        if component_pass(row, 7)
    ]
    eligible.sort(
        key=lambda name: (
            -float(development[name].get("geometric_daily_growth") or 0.0),
            -float(development[name].get("expectancy_usdt") or 0.0),
            -int(development[name].get("trades") or 0),
            name,
        )
    )
    selected = eligible[0] if eligible else None
    write_json(
        EVIDENCE / "development.json",
        {
            "comparison": development,
            "eligible": eligible,
            "selected": selected,
            "status": "TEST_UNTOUCHED" if selected else "NO_SOURCE_SURVIVOR",
        },
    )
    for name, output in outputs.items():
        preserve_case(output, EVIDENCE / "development-cases" / name)

    holdout_row: dict[str, Any] = {
        "variant": selected,
        "produced": False,
        "component_pass": False,
    }
    if selected is not None:
        returncode, output = run_case(
            label=f"{selected}-holdout",
            config_path=configs[selected],
            interval=HOLDOUT,
        )
        holdout_row = {"variant": selected, **summarize(output, returncode)}
        holdout_row["component_pass"] = component_pass(holdout_row, 7)
        preserve_case(output, EVIDENCE / "holdout")
        shutil.copy2(configs[selected], EVIDENCE / "selected_config.json")
    write_json(EVIDENCE / "holdout_assessment.json", holdout_row)

    row_30d: dict[str, Any] = {
        "variant": selected,
        "produced": False,
        "target_pass": False,
    }
    if holdout_row.get("component_pass") and selected is not None:
        returncode, output = run_case(
            label=f"{selected}-continuous-30d",
            config_path=configs[selected],
            interval=CONTINUOUS_30D,
        )
        row_30d = {"variant": selected, **summarize(output, returncode)}
        row_30d["target_pass"] = target_pass(row_30d, 30)
        preserve_case(output, EVIDENCE / "continuous-30d")
    write_json(EVIDENCE / "continuous_30d_assessment.json", row_30d)

    row_90d: dict[str, Any] = {
        "variant": selected,
        "produced": False,
        "target_pass": False,
    }
    if row_30d.get("target_pass") and selected is not None:
        returncode, output = run_case(
            label=f"{selected}-continuous-90d",
            config_path=configs[selected],
            interval=CONTINUOUS_90D,
        )
        row_90d = {"variant": selected, **summarize(output, returncode)}
        row_90d["target_pass"] = target_pass(row_90d, 90)
        preserve_case(output, EVIDENCE / "continuous-90d")
    write_json(EVIDENCE / "continuous_90d_assessment.json", row_90d)

    final = {
        "selected": selected,
        "development_component_pass": bool(selected),
        "holdout_component_pass": bool(holdout_row.get("component_pass")),
        "continuous_30d_target_pass": bool(row_30d.get("target_pass")),
        "continuous_90d_target_pass": bool(row_90d.get("target_pass")),
        "goal_met": bool(row_90d.get("target_pass")),
        "next_action": (
            "PROMOTE_FOR_LONGER_CONTINUOUS_AND_SHADOW_VALIDATION"
            if row_90d.get("target_pass")
            else "REJECT_SOURCE_OR_MINE_ONLY_REAL_FLOW_COMPONENTS"
        ),
    }
    write_json(EVIDENCE / "FINAL_GATE.json", final)
    print(json.dumps(final, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
