"""NautilusTrader adapter for Smallfish over real Binance flow/depth features.

The public Smallfish decision stack is preserved at signal/management level,
but its synthetic backtest book and tape are not.  This adapter reads the
checksum-verified Candidate 05 aggTrades/bookDepth feature stream, chooses one
causal episode across the four-symbol universe, and delegates fills, costs,
orders, margin, liquidation and NAV to NautilusTrader.
"""
from __future__ import annotations

from collections import deque
from dataclasses import replace
from datetime import datetime, timezone
import math
from pathlib import Path

import numpy as np
import pandas as pd

from router import (
    SMALLFISH_STATE,
    BarObservation,
    FeatureObservation,
    RouteConfig,
    _aggregate_complete,
    classify_symbol,
    route_universe,
)
from strategy_base import SYMBOLS
from strategy_base import Candidate35Config as _ExecutionConfig
from strategy_base import Candidate35Strategy as _ExecutionShell


class _SmallfishFeatureStore:
    """Causal columnar view over real Binance aggregate-trade/depth features."""

    _FIELDS = (
        "flow_15s",
        "flow_60s",
        "flow_open_10s",
        "flow_3m",
        "notional_60s",
        "notional_burst",
        "notional_open_10s_burst",
        "trade_count_60s",
        "trade_count_burst",
        "trade_vwap_60s",
        "ret_60s_bps",
        "path_60s_bps",
        "efficiency_60s",
        "flow_price_alignment_60s",
        "absorption_60s",
        "depth_snapshot_age_seconds",
        "depth_imbalance_1",
        "depth_imbalance_2",
        "bid_depth_change_1_1m",
        "ask_depth_change_1_1m",
        "bid_depth_change_1_5m",
        "ask_depth_change_1_5m",
    )

    _REQUIRED_FINITE = (
        "flow_60s",
        "flow_3m",
        "notional_60s",
        "notional_burst",
        "trade_count_60s",
        "trade_count_burst",
        "ret_60s_bps",
        "path_60s_bps",
        "efficiency_60s",
        "depth_snapshot_age_seconds",
        "depth_imbalance_1",
        "bid_depth_change_1_1m",
        "ask_depth_change_1_1m",
    )

    def __init__(self, path: Path) -> None:
        header = list(pd.read_csv(path, compression="infer", nrows=0).columns)
        required = {"observed_time_ns", "feature_ready", *self._REQUIRED_FINITE}
        missing = required.difference(header)
        if missing:
            raise RuntimeError(
                f"smallfish real-flow schema missing {sorted(missing)} in {path}"
            )
        usecols = [
            "observed_time_ns",
            "feature_ready",
            *[field for field in self._FIELDS if field in header],
        ]
        frame = pd.read_csv(path, compression="infer", usecols=usecols)
        self.times = (
            pd.to_numeric(frame["observed_time_ns"], errors="raise")
            .astype("int64")
            .to_numpy(copy=True)
        )
        if self.times.size == 0 or np.any(np.diff(self.times) <= 0):
            raise RuntimeError(
                f"smallfish feature times must be non-empty, unique and monotonic: {path}"
            )
        self.ready = (
            frame["feature_ready"]
            .astype(str)
            .str.strip()
            .str.lower()
            .isin({"true", "1", "yes"})
            .to_numpy(dtype=np.bool_, copy=True)
        )
        self.values: dict[str, np.ndarray] = {}
        for field in self._FIELDS:
            if field in frame:
                self.values[field] = pd.to_numeric(
                    frame[field], errors="coerce"
                ).to_numpy(dtype=np.float64, copy=True)

    def _value(self, field: str, index: int) -> float:
        values = self.values.get(field)
        if values is None:
            return math.nan
        return float(values[index])

    def observation(
        self,
        ts_event: int,
        max_age_seconds: float,
    ) -> FeatureObservation:
        index = int(np.searchsorted(self.times, ts_event, side="right") - 1)
        if index < 0:
            return FeatureObservation(0, ready=False)
        observed = int(self.times[index])
        age = (ts_event - observed) / 1_000_000_000
        if age < -1e-9:
            raise RuntimeError("future Smallfish feature reached strategy")
        finite_required = all(
            math.isfinite(self._value(field, index))
            for field in self._REQUIRED_FINITE
        )
        ready = (
            age <= max_age_seconds
            and bool(self.ready[index])
            and finite_required
        )
        depth_delta = math.nan
        depth = self.values.get("depth_imbalance_1")
        if depth is not None and index > 0:
            current = float(depth[index])
            previous = float(depth[index - 1])
            if math.isfinite(current) and math.isfinite(previous):
                depth_delta = current - previous
        return FeatureObservation(
            observed_time_ns=observed,
            ready=ready,
            flow_15s=self._value("flow_15s", index),
            flow_60s=self._value("flow_60s", index),
            flow_open_10s=self._value("flow_open_10s", index),
            flow_3m=self._value("flow_3m", index),
            notional_60s=self._value("notional_60s", index),
            notional_burst=self._value("notional_burst", index),
            notional_open_10s_burst=self._value(
                "notional_open_10s_burst", index
            ),
            trade_count_60s=self._value("trade_count_60s", index),
            trade_count_burst=self._value("trade_count_burst", index),
            trade_vwap_60s=self._value("trade_vwap_60s", index),
            ret_60s_bps=self._value("ret_60s_bps", index),
            path_60s_bps=self._value("path_60s_bps", index),
            efficiency_60s=self._value("efficiency_60s", index),
            flow_price_alignment_60s=self._value(
                "flow_price_alignment_60s", index
            ),
            absorption_60s=self._value("absorption_60s", index),
            depth_snapshot_age_seconds=self._value(
                "depth_snapshot_age_seconds", index
            ),
            depth_imbalance_1=self._value("depth_imbalance_1", index),
            depth_imbalance_2=self._value("depth_imbalance_2", index),
            depth_imbalance_delta_1=depth_delta,
            bid_depth_change_1_1m=self._value(
                "bid_depth_change_1_1m", index
            ),
            ask_depth_change_1_1m=self._value(
                "ask_depth_change_1_1m", index
            ),
            bid_depth_change_1_5m=self._value(
                "bid_depth_change_1_5m", index
            ),
            ask_depth_change_1_5m=self._value(
                "ask_depth_change_1_5m", index
            ),
        )


class Candidate35Config(_ExecutionConfig, frozen=True):
    smallfish_bucket_minutes: int = 5
    smallfish_ema_fast: int = 3
    smallfish_ema_slow: int = 8
    smallfish_range_period: int = 20
    smallfish_vwap_period: int = 20
    smallfish_alpha: float = 4.0
    smallfish_enter_confidence: float = 0.58
    smallfish_exit_confidence: float = 0.30
    smallfish_min_signals: int = 3
    smallfish_signal_threshold: float = 0.10
    smallfish_prt_cancel_threshold: float = 0.60
    smallfish_prt_max_move_fraction: float = 0.50
    smallfish_sl_range_mult: float = 1.00
    smallfish_tp_range_mult: float = 2.50
    smallfish_min_stop_fraction: float = 0.0010
    smallfish_min_target_fraction: float = 0.0025
    smallfish_min_reward_r: float = 1.20
    smallfish_trail_pct: float = 0.20
    smallfish_trail_activation_r: float = 0.30
    smallfish_max_hold_candles: int = 12
    smallfish_opposite_exit_confidence: float = 2.0
    smallfish_low_mvr: float = 0.65
    smallfish_high_mvr: float = 1.50
    smallfish_extreme_mvr: float = 4.00

    smallfish_w_obi: float = 0.22
    smallfish_w_prt: float = 0.10
    smallfish_w_umom: float = 0.15
    smallfish_w_ltb: float = 0.08
    smallfish_w_sweep: float = 0.05
    smallfish_w_ice: float = 0.03
    smallfish_w_vwap: float = 0.05
    smallfish_w_regime: float = 0.02
    smallfish_w_cvd: float = 0.07
    smallfish_w_tps: float = 0.05
    smallfish_w_liq: float = 0.06
    smallfish_w_mvr: float = 0.06
    smallfish_w_absorb: float = 0.06


class Candidate35Strategy(_ExecutionShell):
    """One global slot, real flow/depth fusion, source range management."""

    def __init__(self, config: Candidate35Config) -> None:
        super().__init__(config)
        fields = {
            name: getattr(config, name)
            for name in RouteConfig.__dataclass_fields__
            if name.startswith("smallfish_") and hasattr(config, name)
        }
        self.route_config = replace(self.route_config, **fields)
        self.bars = {
            symbol: deque(self.bars[symbol], maxlen=4_000)
            for symbol in SYMBOLS
        }
        self.last_source_side = {symbol: 0 for symbol in SYMBOLS}
        self._trail_active = False
        self._trail_best: float | None = None
        self.diagnostics.update(
            {
                "external_source": "azseza/smallfish_",
                "external_claim_screened": (
                    "public_high-frequency returns; synthetic source backtest rejected"
                ),
                "feature_policy": (
                    "checksum-verified Binance aggTrades/bookDepth; no synthetic book/tape"
                ),
                "smallfish_bucket_minutes": int(
                    config.smallfish_bucket_minutes
                ),
                "smallfish_source_edges": 0,
                "smallfish_trailing_activations": 0,
                "smallfish_trailing_exits": 0,
                "smallfish_opposite_exits": 0,
                "source_signals_before_execution_filters": 0,
                "funding_runway_rejections": 0,
                "cooldown_rejections": 0,
                "feature_stale_by_symbol": {},
                "unresolved_reason_counts": {},
                "actionable_family_counts": {},
            }
        )

    def on_start(self) -> None:
        super().on_start()
        for symbol in SYMBOLS:
            self.features[symbol] = _SmallfishFeatureStore(
                self.feature_paths[symbol]
            )

    def _observation(
        self,
        symbol: str,
        ts_event: int,
    ) -> FeatureObservation:
        return self.features[symbol].observation(
            ts_event,
            self.config.feature_max_age_seconds,
        )

    def _decision_boundary(self, ts_event: int) -> bool:
        bucket = int(self.route_config.smallfish_bucket_minutes)
        if bucket <= 0:
            return False
        moment = datetime.fromtimestamp(
            ts_event / 1_000_000_000,
            tz=timezone.utc,
        )
        return moment.minute % bucket == bucket - 1

    def _required_minute_bars(self) -> int:
        candles = max(
            self.route_config.smallfish_ema_slow + 3,
            self.route_config.smallfish_range_period + 3,
            self.route_config.smallfish_vwap_period + 3,
        )
        return candles * self.route_config.smallfish_bucket_minutes

    def _average_bucket_range(self, symbol: str) -> float:
        candles = _aggregate_complete(
            tuple(self.bars[symbol]),
            self.route_config.smallfish_bucket_minutes,
        )
        period = int(self.route_config.smallfish_range_period)
        if not candles:
            return math.nan
        window = candles[-min(period, len(candles)) :]
        if not window:
            return math.nan
        return sum(
            max(float(bar.high) - float(bar.low), 0.0)
            for bar in window
        ) / len(window)

    def _manage_smallfish(self, ts_event: int) -> bool:
        if self.current_symbol is None:
            return False
        scenario = self.current_scenario or {}
        if scenario.get("state") != SMALLFISH_STATE:
            return False
        side = int(scenario.get("side", 0))
        entry = float(scenario.get("entry_reference", math.nan))
        stop = float(scenario.get("stop", math.nan))
        if side not in (-1, 1) or not math.isfinite(entry):
            return False
        bar = self.bars[self.current_symbol][-1]
        average_range = self._average_bucket_range(self.current_symbol)
        if not math.isfinite(average_range) or average_range <= 0.0:
            average_range = abs(entry - stop)
        trail_distance = max(
            average_range * self.route_config.smallfish_trail_pct,
            entry * 1e-6,
        )

        # A trail computed from prior completed bars is applied to this bar.
        # New favourable extremes only affect the next bar, avoiding same-bar
        # high/low sequencing assumptions.
        if self._trail_active and self._trail_best is not None:
            trailing_stop = self._trail_best - side * trail_distance
            hit = (
                float(bar.low) <= trailing_stop
                if side > 0
                else float(bar.high) >= trailing_stop
            )
            if hit:
                instrument_id = self.instrument_ids[self.current_symbol]
                self.cancel_all_orders(instrument_id)
                self.close_all_positions(instrument_id)
                self.diagnostics["smallfish_trailing_exits"] += 1
                self._event(
                    "PUBLIC_SMALLFISH_RANGE_TRAILING_EXIT",
                    ts_event,
                    trailing_stop=trailing_stop,
                    best_price=self._trail_best,
                    range_value=average_range,
                    trail_pct=self.route_config.smallfish_trail_pct,
                )
                return True

        favourable = float(bar.high) if side > 0 else float(bar.low)
        risk = abs(entry - stop)
        favourable_r = (
            side * (favourable - entry) / risk
            if risk > 1e-12
            else 0.0
        )
        if (
            not self._trail_active
            and favourable_r
            >= self.route_config.smallfish_trail_activation_r
        ):
            self._trail_active = True
            self._trail_best = favourable
            self.diagnostics["smallfish_trailing_activations"] += 1
            self._event(
                "PUBLIC_SMALLFISH_RANGE_TRAILING_ACTIVATED",
                ts_event,
                favourable_price=favourable,
                favourable_r=favourable_r,
                activation_r=(
                    self.route_config.smallfish_trail_activation_r
                ),
            )
        elif self._trail_active:
            assert self._trail_best is not None
            self._trail_best = (
                max(self._trail_best, favourable)
                if side > 0
                else min(self._trail_best, favourable)
            )

        threshold = float(
            self.route_config.smallfish_opposite_exit_confidence
        )
        if threshold <= 1.0 and self._decision_boundary(ts_event):
            observation = self._observation(
                self.current_symbol,
                ts_event,
            )
            decision = classify_symbol(
                self.current_symbol,
                tuple(self.bars[self.current_symbol]),
                observation,
                self.route_config,
            )
            confidence = float(
                decision.diagnostics.get("confidence", 0.0)
            )
            if (
                decision.actionable
                and int(decision.side) == -side
                and confidence >= threshold
            ):
                instrument_id = self.instrument_ids[self.current_symbol]
                self.cancel_all_orders(instrument_id)
                self.close_all_positions(instrument_id)
                self.diagnostics["smallfish_opposite_exits"] += 1
                self._event(
                    "PUBLIC_SMALLFISH_OPPOSITE_FUSION_EXIT",
                    ts_event,
                    position_side=side,
                    opposite_side=decision.side,
                    confidence=confidence,
                    diagnostics=dict(decision.diagnostics),
                )
                return True
        return False

    def _manage_open_position(self, ts_event: int) -> None:
        if self._manage_smallfish(ts_event):
            return
        super()._manage_open_position(ts_event)

    def _on_complete_universe_minute(self, ts_event: int) -> None:
        self.minute_index += 1
        self.diagnostics["complete_universe_minutes"] += 1
        self._record_equity(ts_event)
        open_symbols = [
            symbol
            for symbol in SYMBOLS
            if not self.portfolio.is_flat(self.instrument_ids[symbol])
        ]
        self.diagnostics["max_open_positions_observed"] = max(
            int(self.diagnostics["max_open_positions_observed"]),
            len(open_symbols),
        )
        if len(open_symbols) > 1:
            self.diagnostics["global_position_violations"] += 1
            for symbol in open_symbols:
                self.cancel_all_orders(self.instrument_ids[symbol])
                self.close_all_positions(self.instrument_ids[symbol])
            return
        if open_symbols:
            self.current_symbol = open_symbols[0]
            self._manage_open_position(ts_event)
            return
        if self.entry_pending:
            self.diagnostics["max_simultaneous_entry_intents"] = max(
                int(self.diagnostics["max_simultaneous_entry_intents"]),
                1,
            )
            if self.minute_index - self.entry_pending_minute > 2:
                assert self.current_symbol is not None
                self.cancel_all_orders(
                    self.instrument_ids[self.current_symbol]
                )
                self.diagnostics["entry_expirations"] += 1
                self._event(
                    "ENTRY_EXPIRED",
                    ts_event,
                    reason="NOT_FILLED_WITHIN_TWO_COMPLETE_MINUTES",
                )
                self._clear_trade_state()
            return
        if not (
            self.config.evaluation_start_ns
            <= ts_event
            <= self.config.evaluation_end_ns
        ):
            return
        if not self._decision_boundary(ts_event):
            return
        if any(
            len(self.bars[symbol]) < self._required_minute_bars()
            for symbol in SYMBOLS
        ):
            return

        observations = {
            symbol: self._observation(symbol, ts_event)
            for symbol in SYMBOLS
        }
        stale = self.diagnostics["feature_stale_by_symbol"]
        for symbol, observation in observations.items():
            if not observation.ready:
                stale[symbol] = int(stale.get(symbol, 0)) + 1

        self.diagnostics["quarter_hour_decisions"] += 1
        _, decisions = route_universe(
            bars_by_symbol={
                symbol: tuple(self.bars[symbol])
                for symbol in SYMBOLS
            },
            features_by_symbol=observations,
            config=self.route_config,
        )
        route_counts = self.diagnostics["route_counts"]
        reason_counts = self.diagnostics["unresolved_reason_counts"]
        family_counts = self.diagnostics["actionable_family_counts"]
        edges = []
        actionable_count = 0
        for symbol, decision in decisions.items():
            route_counts[decision.state] = (
                int(route_counts.get(decision.state, 0)) + 1
            )
            current_side = int(decision.side) if decision.actionable else 0
            previous_side = int(self.last_source_side[symbol])
            if decision.actionable:
                actionable_count += 1
                family_counts[decision.state] = (
                    int(family_counts.get(decision.state, 0)) + 1
                )
                if current_side != previous_side:
                    edges.append(decision)
            else:
                for reason in decision.reasons:
                    reason_counts[reason] = (
                        int(reason_counts.get(reason, 0)) + 1
                    )
            self.last_source_side[symbol] = current_side

        self.diagnostics[
            "source_signals_before_execution_filters"
        ] += actionable_count
        if not edges:
            self.diagnostics["unresolved_episodes"] += 1
            return
        self.diagnostics["smallfish_source_edges"] += len(edges)
        edges.sort(key=lambda item: (-float(item.score), item.symbol))
        winner = edges[0]
        if self._funding_blackout(ts_event):
            self.diagnostics["funding_runway_rejections"] += 1
            return
        if (
            self.minute_index - self.last_entry_minute
            < self.config.cooldown_minutes
        ):
            self.diagnostics["cooldown_rejections"] += 1
            return

        self._trail_active = False
        self._trail_best = None
        before = int(self.diagnostics["entry_submissions"])
        self._submit_decision(winner, ts_event)
        if (
            int(self.diagnostics["entry_submissions"]) > before
            and self.current_scenario is not None
        ):
            self.current_scenario.update(
                {
                    "candidate": "candidate-51-smallfish-real-flow",
                    "external_source": "azseza/smallfish_",
                    "external_backtest_policy": (
                        "synthetic source book/tape rejected; real Binance observations"
                    ),
                    "source_bucket_minutes": int(
                        self.route_config.smallfish_bucket_minutes
                    ),
                    "management": (
                        "source range bracket + post-0.3R range trail + max hold"
                    ),
                }
            )

    def _clear_trade_state(self) -> None:
        super()._clear_trade_state()
        self._trail_active = False
        self._trail_best = None


__all__ = ["Candidate35Config", "Candidate35Strategy"]
