"""Causal one-slot adapter for the public Freqtrade ZaratustraV15 system."""
from __future__ import annotations
from dataclasses import dataclass, field
import math
from typing import Mapping, Sequence

Z15_STATE = "PUBLIC_ZARATUSTRA_V15_DI_OBV_MFI_BB"
SMA_OFFSET_STATE = Z15_STATE
UNRESOLVED = "UNRESOLVED"
_EPS = 1e-12
_PRIORITY = {"BTCUSDT": 0, "ETHUSDT": 1, "SOLUSDT": 2, "XRPUSDT": 3}

@dataclass(frozen=True, slots=True)
class BarObservation:
    ts_event: int
    open: float
    high: float
    low: float
    close: float
    volume: float

@dataclass(frozen=True, slots=True)
class FeatureObservation:
    observed_time_ns: int
    ready: bool = True
    flow_open_10s: float = math.nan
    notional_open_10s_burst: float = math.nan
    flow_60s: float = math.nan
    efficiency_60s: float = math.nan
    oi_change_15m: float = math.nan
    premium_z: float = math.nan

@dataclass(frozen=True, slots=True)
class RouteConfig:
    # execution-shell compatibility
    atr_period: int = 30
    min_impulse_atr_continuation: float = 0.20
    min_impulse_atr_reversal: float = 1.05
    min_response_atr: float = 0.08
    min_participation_ratio: float = 0.85
    min_route_score: float = 3.20
    ambiguity_score_gap: float = 0.10
    continuation_target_r: float = 2.0
    reversal_target_r: float = 1.65
    bucket_minutes: int = 5

    z15_di_period: int = 14
    z15_mfi_period: int = 14
    z15_bb_period: int = 20
    z15_bb_stdev: float = 2.0
    z15_atr_mode: str = "absolute"   # absolute | fraction | off
    z15_atr_threshold: float = 0.2
    z15_enable_di: bool = True
    z15_enable_bb: bool = True
    z15_source_leverage: float = 10.0
    z15_source_stoploss: float = 0.15
    z15_trailing_positive: float = 0.012
    z15_trailing_offset: float = 0.107
    z15_remote_target_r: float = 20.0

    # legacy compatibility
    sma_offset_period: int = 8
    sma_offset_low: float = 0.960
    sma_offset_high: float = 1.012
    sma_trend_fast: int = 20
    sma_trend_slow: int = 25
    sma_stop_min_fraction: float = 0.0075
    sma_stop_max_fraction: float = 0.1
    sma_stop_atr_buffer: float = 0.5
    sma_structural_lookback: int = 6
    sma_min_reward_r: float = 1.0

@dataclass(frozen=True, slots=True)
class RouteDecision:
    symbol: str
    state: str
    side: int
    score: float
    entry_reference: float
    stop_reference: float
    objective_reference: float
    episode_ts: int
    reasons: tuple[str, ...] = ()
    diagnostics: Mapping[str, float | int | str] = field(default_factory=dict)
    @property
    def actionable(self) -> bool:
        return self.side in (-1, 1) and self.state != UNRESOLVED

def _finite(x: float) -> bool:
    return math.isfinite(float(x))

def _aggregate_complete(bars: Sequence[BarObservation], minutes: int) -> list[BarObservation]:
    if not bars:
        return []
    minute_ns = 60_000_000_000
    phase = int(bars[-1].ts_event) % minute_ns
    groups: dict[int, list[tuple[int, BarObservation]]] = {}
    for bar in bars:
        ts = int(bar.ts_event)
        if ts % minute_ns != phase:
            continue
        ordinal = (ts - phase) // minute_ns
        groups.setdefault(ordinal // minutes, []).append((ordinal, bar))
    out: list[BarObservation] = []
    for values in groups.values():
        values.sort(key=lambda item: item[0])
        ords = [item[0] for item in values]
        if len(values) != minutes or ords[0] % minutes or ords[-1] % minutes != minutes - 1:
            continue
        if any(ords[i] != ords[i-1] + 1 for i in range(1, len(ords))):
            continue
        items = [item[1] for item in values]
        out.append(BarObservation(
            int(items[-1].ts_event), float(items[0].open),
            max(float(x.high) for x in items), min(float(x.low) for x in items),
            float(items[-1].close), sum(max(0.0, float(x.volume)) for x in items),
        ))
    out.sort(key=lambda x: x.ts_event)
    return out

def _sma(values: Sequence[float], period: int) -> list[float]:
    out=[math.nan]*len(values); total=0.0
    for i,v in enumerate(values):
        total += float(v)
        if i >= period: total -= float(values[i-period])
        if i >= period-1: out[i]=total/period
    return out

def _std(values: Sequence[float], period: int) -> list[float]:
    out=[math.nan]*len(values)
    for i in range(period-1, len(values)):
        sample=[float(v) for v in values[i-period+1:i+1]]
        mean=sum(sample)/period
        out[i]=math.sqrt(sum((v-mean)**2 for v in sample)/period)
    return out

def _wilder_indicators(candles: Sequence[BarObservation], period: int):
    n=len(candles)
    atr=[math.nan]*n; pdi=[math.nan]*n; mdi=[math.nan]*n; dx=[math.nan]*n; adx=[math.nan]*n
    if n <= period: return atr,pdi,mdi,dx,adx
    tr=[0.0]*n; pdm=[0.0]*n; mdm=[0.0]*n
    for i in range(1,n):
        c,p=candles[i],candles[i-1]
        up=float(c.high)-float(p.high); down=float(p.low)-float(c.low)
        pdm[i]=up if up>down and up>0 else 0.0
        mdm[i]=down if down>up and down>0 else 0.0
        tr[i]=max(float(c.high)-float(c.low),abs(float(c.high)-float(p.close)),abs(float(c.low)-float(p.close)))
    st=sum(tr[1:period+1]); sp=sum(pdm[1:period+1]); sm=sum(mdm[1:period+1])
    for i in range(period,n):
        if i>period:
            st=st-st/period+tr[i]; sp=sp-sp/period+pdm[i]; sm=sm-sm/period+mdm[i]
        atr[i]=st/period
        if st>_EPS:
            pdi[i]=100*sp/st; mdi[i]=100*sm/st
            den=pdi[i]+mdi[i]
            dx[i]=100*abs(pdi[i]-mdi[i])/den if den>_EPS else 0.0
    first_adx=period*2-1
    if n>first_adx:
        vals=[x for x in dx[period:first_adx+1] if _finite(x)]
        if len(vals)==period:
            adx[first_adx]=sum(vals)/period
            for i in range(first_adx+1,n):
                adx[i]=(adx[i-1]*(period-1)+dx[i])/period
    return atr,pdi,mdi,dx,adx

def _mfi(candles: Sequence[BarObservation], period: int) -> list[float]:
    n=len(candles); out=[math.nan]*n
    typical=[(float(c.high)+float(c.low)+float(c.close))/3 for c in candles]
    raw=[typical[i]*max(0.0,float(candles[i].volume)) for i in range(n)]
    for i in range(period,n):
        pos=neg=0.0
        for j in range(i-period+1,i+1):
            if typical[j] > typical[j-1]: pos += raw[j]
            elif typical[j] < typical[j-1]: neg += raw[j]
        if neg<=_EPS: out[i]=100.0 if pos>_EPS else 50.0
        else: out[i]=100.0-100.0/(1.0+pos/neg)
    return out

def _obv(candles: Sequence[BarObservation]) -> list[float]:
    out=[0.0]*len(candles)
    for i in range(1,len(candles)):
        if candles[i].close > candles[i-1].close: out[i]=out[i-1]+max(0.0,float(candles[i].volume))
        elif candles[i].close < candles[i-1].close: out[i]=out[i-1]-max(0.0,float(candles[i].volume))
        else: out[i]=out[i-1]
    return out

def _unresolved(symbol: str, reason: str, ts: int=0, diagnostics=None) -> RouteDecision:
    return RouteDecision(symbol,UNRESOLVED,0,0.0,math.nan,math.nan,math.nan,int(ts),(reason,),dict(diagnostics or {}))

def _condition_series(candles, config):
    typical=[(float(c.high)+float(c.low)+float(c.close))/3 for c in candles]
    mid=_sma(typical,config.z15_bb_period); sd=_std(typical,config.z15_bb_period)
    atr,pdi,mdi,dx,adx=_wilder_indicators(candles,config.z15_di_period)
    mfi=_mfi(candles,config.z15_mfi_period); obv=_obv(candles)
    long_di=[]; short_di=[]; long_bb=[]; short_bb=[]
    for i,c in enumerate(candles):
        ready=all(_finite(x[i]) for x in (atr,pdi,mdi,dx,adx,mfi,mid,sd))
        if not ready:
            long_di.append(False); short_di.append(False); long_bb.append(False); short_bb.append(False); continue
        if config.z15_atr_mode=="absolute": atr_ok=atr[i] < config.z15_atr_threshold
        elif config.z15_atr_mode=="fraction": atr_ok=atr[i]/max(float(c.close),_EPS) < config.z15_atr_threshold
        else: atr_ok=True
        long_di.append(bool(config.z15_enable_di and dx[i]>mdi[i] and adx[i]>mdi[i] and pdi[i]>mdi[i] and obv[i]>obv[i-1] and mfi[i]>50 and atr_ok))
        short_di.append(bool(config.z15_enable_di and dx[i]>pdi[i] and adx[i]>pdi[i] and mdi[i]>pdi[i] and obv[i]<obv[i-1] and mfi[i]<50 and atr_ok))
        upper=mid[i]+config.z15_bb_stdev*sd[i]; lower=mid[i]-config.z15_bb_stdev*sd[i]
        if i==0 or not all(_finite(x) for x in (mid[i-1],sd[i-1])):
            long_bb.append(False); short_bb.append(False)
        else:
            prev_upper=mid[i-1]+config.z15_bb_stdev*sd[i-1]; prev_lower=mid[i-1]-config.z15_bb_stdev*sd[i-1]
            long_bb.append(bool(config.z15_enable_bb and float(c.close)>upper and float(candles[i-1].close)<=prev_upper))
            short_bb.append(bool(config.z15_enable_bb and float(c.close)<lower and float(candles[i-1].close)>=prev_lower))
    return dict(mid=mid,sd=sd,atr=atr,pdi=pdi,mdi=mdi,dx=dx,adx=adx,mfi=mfi,obv=obv,
                long_di=long_di,short_di=short_di,long_bb=long_bb,short_bb=short_bb)

def _episode_start(candles, flags, index):
    if not flags[index]: return 0
    while index>0 and flags[index-1]: index-=1
    return int(candles[index].ts_event)

def classify_symbol(symbol: str, bars: Sequence[BarObservation], feature: FeatureObservation, config: RouteConfig=RouteConfig()) -> RouteDecision:
    if not bars: return _unresolved(symbol,"NO_MINUTE_BARS")
    latest=int(bars[-1].ts_event)
    if int(feature.observed_time_ns)>latest: return _unresolved(symbol,"FUTURE_FEATURE_REJECTED",latest)
    candles=_aggregate_complete(bars,config.bucket_minutes)
    minimum=max(config.z15_bb_period+2,config.z15_di_period*2+2,config.z15_mfi_period+2)
    if len(candles)<minimum: return _unresolved(symbol,"Z15_HISTORY_NOT_READY",latest,{"candles":len(candles),"minimum":minimum})
    s=_condition_series(candles,config); i=len(candles)-1
    long=bool(s["long_di"][i] or s["long_bb"][i]); short=bool(s["short_di"][i] or s["short_bb"][i])
    diag={k:float(s[k][i]) for k in ("atr","pdi","mdi","dx","adx","mfi","obv","mid","sd")}
    diag.update({"long_di":int(s["long_di"][i]),"short_di":int(s["short_di"][i]),
                 "long_bb":int(s["long_bb"][i]),"short_bb":int(s["short_bb"][i]),
                 "atr_mode":config.z15_atr_mode,"atr_threshold":config.z15_atr_threshold})
    if long==short: return _unresolved(symbol,"Z15_NO_SOURCE_ENTRY" if not long else "Z15_AMBIGUOUS_SOURCE_ENTRY",int(candles[i].ts_event),diag)
    side=1 if long else -1
    is_bb=bool(s["long_bb"][i] if side>0 else s["short_bb"][i])
    flags=(s["long_di"] if side>0 else s["short_di"])
    episode=int(candles[i].ts_event) if is_bb else _episode_start(candles,flags,i)
    entry=float(candles[i].close)
    stop_frac=config.z15_source_stoploss/max(config.z15_source_leverage,_EPS)
    stop=entry*(1-side*stop_frac)
    risk=abs(entry-stop)
    objective=entry+side*config.z15_remote_target_r*risk
    # Choose strongest simultaneous opportunity: crossing normalized by ATR, then DI dominance.
    upper=float(s["mid"][i])+config.z15_bb_stdev*float(s["sd"][i])
    lower=float(s["mid"][i])-config.z15_bb_stdev*float(s["sd"][i])
    bb_strength=max(0.0,(entry-upper)/max(float(s["atr"][i]),_EPS)) if side>0 else max(0.0,(lower-entry)/max(float(s["atr"][i]),_EPS))
    di_strength=max(0.0,(float(s["pdi"][i])-float(s["mdi"][i]))/10) if side>0 else max(0.0,(float(s["mdi"][i])-float(s["pdi"][i]))/10)
    score=10.0*int(is_bb)+bb_strength+di_strength+abs(float(s["mfi"][i])-50)/20
    diag.update({"source_tag":("Long" if side>0 else "Short")+(" Bollinger enter" if is_bb else " DI enter"),
                 "source_leverage":config.z15_source_leverage,"underlying_stop_fraction":stop_frac,
                 "source_trailing_offset":config.z15_trailing_offset,"source_trailing_positive":config.z15_trailing_positive,
                 "episode_kind":"bb_cross" if is_bb else "contiguous_di_state"})
    return RouteDecision(symbol,Z15_STATE,side,float(score),entry,stop,objective,episode,
        ("PUBLIC_ZARATUSTRA_V15_DI_OBV_MFI_OR_BB_CROSS","ONE_CAUSAL_EPISODE_ONE_ENTRY"),diag)

classify_sma_offset=classify_symbol

def route_universe(bars_by_symbol: Mapping[str,Sequence[BarObservation]], features_by_symbol: Mapping[str,FeatureObservation], config: RouteConfig=RouteConfig()):
    decisions={symbol:classify_symbol(symbol,bars,features_by_symbol.get(symbol,FeatureObservation(bars[-1].ts_event if bars else 0)),config)
               for symbol,bars in bars_by_symbol.items()}
    actionable=[d for d in decisions.values() if d.actionable]
    actionable.sort(key=lambda d:(-d.score,_PRIORITY.get(d.symbol,99),d.episode_ts))
    return (actionable[0] if actionable else None), decisions

def sma_offset_exit_ready(bars,config=RouteConfig()):
    return False,{"source_exit":0,"reason":"Z15_TRAILING_MANAGED_IN_STRATEGY"}

__all__=["BarObservation","FeatureObservation","RouteConfig","RouteDecision","Z15_STATE","SMA_OFFSET_STATE","UNRESOLVED","classify_symbol","classify_sma_offset","route_universe","sma_offset_exit_ready"]
