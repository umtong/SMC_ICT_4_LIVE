"""Execute Candidate 51's external ichiV1/ichiV2 source-family screen."""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys

from router import (
    BarObservation,
    FeatureObservation,
    ICHI_STATE,
    RouteConfig,
    classify_symbol,
    route_universe,
)

ROOT = Path("artifacts/candidate-51")
WORK = Path(".work/candidate-51-ichi-v9")
EVIDENCE = Path("research/candidate-51/evidence/v9-ichi")
NAMES = (
    "gist_long_deep_ema24",
    "freqle_long_deep_ema6",
    "adapted_long_ema24",
    "symmetric_ema24",
    "symmetric_ema6",
)
VARIANTS = {
    "gist_long_deep_ema24": {
        "short": False,
        "source_stop": True,
        "exit_ema": 24,
        "gain": 1.002,
    },
    "freqle_long_deep_ema6": {
        "short": False,
        "source_stop": True,
        "exit_ema": 6,
        "gain": 1.002,
    },
    "adapted_long_ema24": {
        "short": False,
        "source_stop": False,
        "exit_ema": 24,
        "gain": 1.002,
    },
    "symmetric_ema24": {
        "short": True,
        "source_stop": False,
        "exit_ema": 24,
        "gain": 1.002,
    },
    "symmetric_ema6": {
        "short": True,
        "source_stop": False,
        "exit_ema": 6,
        "gain": 1.002,
    },
}


def _acceleration(side: int, length5: int = 190, shift: float = 0.0) -> list[BarObservation]:
    bars: list[BarObservation] = []
    price = 100.0 + shift
    index = 0
    for candle in range(length5):
        if candle < 160:
            rate = side * 0.00015 + 0.00005 * math.sin(candle / 5.0)
        else:
            rate = side * (0.002 + 0.0006 * (candle - 160))
        target = max(1.0, price * (1.0 + rate))
        for minute in range(5):
            opened = price + (target - price) * minute / 5.0
            closed = price + (target - price) * (minute + 1) / 5.0
            wiggle = max(abs(closed - opened) * 0.1, 0.005)
            index += 1
            bars.append(
                BarObservation(
                    index * 60_000_000_000 - 1_000_000,
                    opened,
                    max(opened, closed) + wiggle,
                    min(opened, closed) - wiggle,
                    closed,
                    1_000.0 + index % 51,
                ),
            )
        price = target
    return bars


def test_contracts() -> None:
    long_config = RouteConfig(ichi_allow_short=False)
    long_bars = _acceleration(1)
    long = classify_symbol(
        "BTCUSDT",
        long_bars,
        FeatureObservation(long_bars[-1].ts_event),
        long_config,
    )
    assert long.actionable and long.state == ICHI_STATE and long.side == 1
    assert long.stop_reference < long.entry_reference < long.objective_reference
    extended = _acceleration(1, 191)
    long2 = classify_symbol(
        "BTCUSDT",
        extended,
        FeatureObservation(extended[-1].ts_event),
        long_config,
    )
    assert long2.actionable and long2.episode_ts == long.episode_ts

    short_config = RouteConfig(ichi_allow_short=True)
    short_bars = _acceleration(-1)
    short = classify_symbol(
        "BTCUSDT",
        short_bars,
        FeatureObservation(short_bars[-1].ts_event),
        short_config,
    )
    assert short.actionable and short.state == ICHI_STATE and short.side == -1
    assert short.objective_reference < short.entry_reference < short.stop_reference

    future = classify_symbol(
        "BTCUSDT",
        long_bars,
        FeatureObservation(long_bars[-1].ts_event + 1),
        long_config,
    )
    assert not future.actionable and "FUTURE_FEATURE_REJECTED" in future.reasons

    universe = {
        symbol: _acceleration(1 if index % 2 == 0 else -1, shift=float(index * 20))
        for index, symbol in enumerate(("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT"))
    }
    features = {
        symbol: FeatureObservation(series[-1].ts_event)
        for symbol, series in universe.items()
    }
    winner, decisions = route_universe(universe, features, short_config)
    assert winner is not None and winner.actionable
    assert sum(item.actionable for item in decisions.values()) == 4


def _strategy_config(base: dict, values: dict) -> dict:
    config = copy.deepcopy(base)
    for key in {
        "sma_offset_low",
        "sma_offset_high",
        "sma_stop_min_fraction",
        "sma_stop_max_fraction",
        "sma_stop_atr_buffer",
    }:
        config["strategy"].pop(key, None)
    config["strategy"].update(
        {
            "cooldown_minutes": 0,
            "max_hold_minutes": 720,
            "funding_flatten_minute": 60,
            "funding_blackout_before_minutes": -1,
            "funding_blackout_after_minutes": -1,
            "ichi_conversion_period": 20,
            "ichi_base_period": 60,
            "ichi_span_period": 120,
            "ichi_displacement": 30,
            "ichi_above_cloud_level": 1,
            "ichi_bullish_level": 6,
            "ichi_fan_shift": 3,
            "ichi_min_fan_gain": values["gain"],
            "ichi_exit_ema_period": values["exit_ema"],
            "ichi_allow_short": values["short"],
            "ichi_use_source_emergency_stop": values["source_stop"],
            "ichi_source_stoploss": 0.275,
            "ichi_stop_atr_buffer": 0.20,
            "ichi_emergency_target_fraction": 0.10,
            "ichi_roi_0": 0.059,
            "ichi_roi_10": 0.037,
            "ichi_roi_41": 0.012,
            "ichi_roi_114": 0.0,
        },
    )
    return config


def prepare() -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    base = json.loads(Path("research/candidate-51/config.json").read_text())
    manifest = {
        "family": "public_ichiV1_ichiV2_cloud_HA_EMA_fan",
        "sources": [
            {
                "gist": "akhil3417/fb96c0cfcd6ed565931a4fda8775599c",
                "result_claim": "vjaykrsna/3aa41ada83ea890721e27ccda02c1d64",
                "claimed_trades_93_days": 1056,
                "claimed_win_rate": 0.766,
                "claimed_profit_factor": 6.51,
            },
            {
                "repository": "remiotore/ccxt-freqtrade",
                "path": "strategies/ichi_v1.py",
            },
        ],
        "development_interval": ["2026-07-22", "2026-07-28"],
        "untouched_interval": ["2026-07-29", "2026-08-04"],
        "variants": VARIANTS,
        "router_sha256": hashlib.sha256(
            Path("research/candidate-51/router.py").read_bytes(),
        ).hexdigest(),
        "strategy_sha256": hashlib.sha256(
            Path("research/candidate-51/strategy.py").read_bytes(),
        ).hexdigest(),
    }
    (WORK / "variant_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
    )
    for name, values in VARIANTS.items():
        (WORK / f"{name}.json").write_text(
            json.dumps(_strategy_config(base, values), indent=2, sort_keys=True) + "\n",
        )


def run_variant(name: str, start: str, end: str, suffix: str) -> int:
    output = ROOT / f"ichi-v9-{name}-{suffix}"
    workspace = Path(f".work/candidate-51-ichi-v9-{name}-{suffix}")
    command = [
        sys.executable,
        "research/candidate-51/launch.py",
        "--config",
        str(WORK / f"{name}.json"),
        "--start",
        start,
        "--end",
        end,
        "--cache",
        ".cache/candidate-51-ichi-v9",
        "--output",
        str(output),
        "--workspace",
        str(workspace),
    ]
    environment = dict(os.environ)
    environment["PYTHONPATH"] = "research/candidate-51"
    return subprocess.run(command, env=environment, check=False).returncode


def _row(name: str) -> dict:
    root = ROOT / f"ichi-v9-{name}-development"
    metrics_path = root / "metrics.json"
    diagnostics_path = root / "strategy_diagnostics.json"
    if not metrics_path.is_file() or not diagnostics_path.is_file():
        return {"produced": False}
    metrics = json.loads(metrics_path.read_text())
    diagnostics = json.loads(diagnostics_path.read_text())
    return {
        "produced": True,
        "ending_nav": metrics.get("ending_nav"),
        "total_return": metrics.get("total_return"),
        "geometric_daily_growth": metrics.get("geometric_daily_growth"),
        "max_drawdown": metrics.get("max_drawdown"),
        "trades": metrics.get("trades"),
        "wins": metrics.get("wins"),
        "losses": metrics.get("losses"),
        "win_rate": metrics.get("win_rate"),
        "profit_factor": metrics.get("profit_factor"),
        "expectancy_usdt": metrics.get("expectancy_usdt"),
        "largest_winner_share": metrics.get("largest_winner_share"),
        "source_signals": diagnostics.get("source_signals_before_execution_filters"),
        "entries": diagnostics.get("entry_submissions"),
        "source_exits": diagnostics.get("ichi_source_exit_submissions"),
        "roi_exits": diagnostics.get("ichi_roi_exits"),
        "selected_symbols": diagnostics.get("selected_symbols"),
        "global_position_violations": diagnostics.get("global_position_violations"),
        "order_rejections": diagnostics.get("order_rejections"),
        "unresolved_reason_counts": diagnostics.get("unresolved_reason_counts"),
    }


def select() -> tuple[dict, str | None]:
    comparison = {name: _row(name) for name in NAMES}
    eligible = [
        name
        for name, row in comparison.items()
        if row.get("produced")
        and int(row.get("trades") or 0) >= 7
        and float(row.get("expectancy_usdt") or 0.0) > 0.0
        and float(row.get("geometric_daily_growth") or 0.0) > 0.0
        and float(row.get("max_drawdown") or 1.0) <= 0.20
        and int(row.get("global_position_violations") or 0) == 0
        and int(row.get("order_rejections") or 0) == 0
    ]
    eligible.sort(
        key=lambda name: (
            -float(comparison[name].get("geometric_daily_growth") or 0.0),
            -float(comparison[name].get("expectancy_usdt") or 0.0),
            -int(comparison[name].get("trades") or 0),
            name,
        ),
    )
    selected = eligible[0] if eligible else None
    decision = {
        "comparison": comparison,
        "eligible": eligible,
        "selected": selected,
        "family_status": "TEST_UNTOUCHED" if selected else "REJECT_OR_REDESIGN",
    }
    ROOT.mkdir(parents=True, exist_ok=True)
    (ROOT / "ichi-v9-development-comparison.json").write_text(
        json.dumps(decision, indent=2, sort_keys=True) + "\n",
    )
    print(json.dumps(decision, indent=2, sort_keys=True))
    return decision, selected


def assess_holdout(selected: str | None) -> dict:
    root = ROOT / "ichi-v9-selected-holdout"
    metrics_path = root / "metrics.json"
    diagnostics_path = root / "strategy_diagnostics.json"
    assessment: dict = {"variant": selected, "produced": False, "gate_pass": False}
    if selected and metrics_path.is_file() and diagnostics_path.is_file():
        metrics = json.loads(metrics_path.read_text())
        diagnostics = json.loads(diagnostics_path.read_text())
        checks = {
            "trades_at_least_days": int(metrics.get("trades") or 0) >= 7,
            "positive_growth": float(metrics.get("geometric_daily_growth") or 0.0) > 0.0,
            "positive_expectancy": float(metrics.get("expectancy_usdt") or 0.0) > 0.0,
            "drawdown_lte_20pct": float(metrics.get("max_drawdown") or 1.0) <= 0.20,
            "one_position": int(diagnostics.get("global_position_violations") or 0) == 0,
            "no_rejections": int(diagnostics.get("order_rejections") or 0) == 0,
        }
        assessment = {
            "variant": selected,
            "produced": True,
            **{
                key: metrics.get(key)
                for key in (
                    "ending_nav",
                    "total_return",
                    "geometric_daily_growth",
                    "max_drawdown",
                    "trades",
                    "wins",
                    "losses",
                    "win_rate",
                    "profit_factor",
                    "expectancy_usdt",
                )
            },
            "selected_symbols": diagnostics.get("selected_symbols"),
            "checks": checks,
            "gate_pass": all(checks.values()),
        }
    (ROOT / "ichi-v9-holdout-assessment.json").write_text(
        json.dumps(assessment, indent=2, sort_keys=True) + "\n",
    )
    print(json.dumps(assessment, indent=2, sort_keys=True))
    return assessment


def copy_evidence() -> None:
    if EVIDENCE.exists():
        shutil.rmtree(EVIDENCE)
    (EVIDENCE / "development").mkdir(parents=True)
    (EVIDENCE / "holdout").mkdir(parents=True)
    shutil.copy2(WORK / "variant_manifest.json", EVIDENCE / "variant_manifest.json")
    shutil.copy2(
        ROOT / "ichi-v9-development-comparison.json",
        EVIDENCE / "development/comparison.json",
    )
    shutil.copy2(
        ROOT / "ichi-v9-holdout-assessment.json",
        EVIDENCE / "holdout/assessment.json",
    )
    for name in NAMES:
        source = ROOT / f"ichi-v9-{name}-development"
        target = EVIDENCE / "development" / name
        if not source.is_dir():
            continue
        target.mkdir(parents=True)
        for filename in (
            "metrics.json",
            "strategy_diagnostics.json",
            "run.json",
            "data_manifest.json",
            "closed_scenarios.json",
        ):
            path = source / filename
            if path.is_file():
                shutil.copy2(path, target / filename)
    source = ROOT / "ichi-v9-selected-holdout"
    if source.is_dir():
        for filename in (
            "metrics.json",
            "strategy_diagnostics.json",
            "run.json",
            "data_manifest.json",
            "closed_scenarios.json",
        ):
            path = source / filename
            if path.is_file():
                shutil.copy2(path, EVIDENCE / "holdout" / filename)


def main() -> None:
    test_contracts()
    prepare()
    return_codes = {
        name: run_variant(name, "2026-07-22", "2026-07-28", "development")
        for name in NAMES
    }
    (WORK / "return_codes.json").write_text(
        json.dumps(return_codes, indent=2, sort_keys=True) + "\n",
    )
    _, selected = select()
    if selected:
        output = ROOT / "ichi-v9-selected-holdout"
        workspace = Path(".work/candidate-51-ichi-v9-selected-holdout")
        command = [
            sys.executable,
            "research/candidate-51/launch.py",
            "--config",
            str(WORK / f"{selected}.json"),
            "--start",
            "2026-07-29",
            "--end",
            "2026-08-04",
            "--cache",
            ".cache/candidate-51-ichi-v9",
            "--output",
            str(output),
            "--workspace",
            str(workspace),
        ]
        environment = dict(os.environ)
        environment["PYTHONPATH"] = "research/candidate-51"
        subprocess.run(command, env=environment, check=False)
    assess_holdout(selected)
    copy_evidence()


if __name__ == "__main__":
    main()
