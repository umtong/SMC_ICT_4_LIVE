
"""NautilusTrader execution adapter for the public Freqtrade ``el`` policy."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
import math

from router import EL_STATE, FeatureObservation, route_universe, source_conditions
from strategy_base import SYMBOLS
from strategy_base import Candidate35Config as _ExecutionConfig
from strategy_base import Candidate35Strategy as _ExecutionShell


class Candidate35Config(_ExecutionConfig, frozen=True):
    el_buy_ema_period: int = 12
    el_sell_ema_period: int = 72
    el_fast_ewo_period: int = 50
    el_slow_ewo_period: int = 200
    el_rsi_period: int = 14
    el_low_offset: float = 0.915
    el_high_offset: float = 1.008
    el_ewo_high: float = 4.428
    el_ewo_low: float = -12.383
    el_rsi_buy: float = 44.0
    el_allow_long: bool = True
    el_allow_short: bool = True
    el_source_leverage: float = 10.0
    el_source_stoploss: float = 0.242
    el_trailing_positive: float = 0.005
    el_trailing_offset: float = 0.030
    el_emergency_target_fraction: float = 0.05
    el_roi_0: float = 0.219
    el_roi_24: float = 0.087
    el_roi_67: float = 0.024
    el_roi_164: float = 0.0


class Candidate35Strategy(_ExecutionShell):
    """One global slot, one trade per contiguous source condition."""

    def __init__(self, config: Candidate35Config) -> None:
        super().__init__(config)
        self.route_config = replace(
            self.route_config,
            el_buy_ema_period=int(config.el_buy_ema_period),
            el_sell_ema_period=int(config.el_sell_ema_period),
            el_fast_ewo_period=int(config.el_fast_ewo_period),
            el_slow_ewo_period=int(config.el_slow_ewo_period),
            el_rsi_period=int(config.el_rsi_period),
            el_low_offset=float(config.el_low_offset),
            el_high_offset=float(config.el_high_offset),
            el_ewo_high=float(config.el_ewo_high),
            el_ewo_low=float(config.el_ewo_low),
            el_rsi_buy=float(config.el_rsi_buy),
            el_allow_long=bool(config.el_allow_long),
            el_allow_short=bool(config.el_allow_short),
            el_source_leverage=float(config.el_source_leverage),
            el_source_stoploss=float(config.el_source_stoploss),
            el_trailing_positive=float(config.el_trailing_positive),
            el_trailing_offset=float(config.el_trailing_offset),
            el_emergency_target_fraction=float(config.el_emergency_target_fraction),
        )
        self._roi_schedule = (
            (0, float(config.el_roi_0)),
            (24, float(config.el_roi_24)),
            (67, float(config.el_roi_67)),
            (164, float(config.el_roi_164)),
        )
        self.diagnostics.setdefault("source_signals_before_execution_filters", 0)
        self.diagnostics.setdefault("funding_runway_rejections", 0)
        self.diagnostics.setdefault("cooldown_rejections", 0)
        self.diagnostics.setdefault("used_episode_rejections", 0)
        self.diagnostics.setdefault("el_signal_exits", 0)
        self.diagnostics.setdefault("el_roi_exits", 0)
        self.diagnostics.setdefault("el_roi_ignored_by_entry_signal", 0)
        self.diagnostics.setdefault("el_trailing_activations", 0)
        self.diagnostics.setdefault("el_trailing_exits", 0)
        self.used_episode_keys: set[tuple[str, str, int]] = set()
        self._trail_active = False
        self._trail_best: float | None = None
        self._last_long_condition = False
        self._last_short_condition = False

    def _on_complete_universe_minute(self, ts_event: int) -> None:
        self.minute_index += 1
        self.diagnostics["complete_universe_minutes"] += 1
        self._record_equity(ts_event)

        open_symbols = [
            symbol
            for symbol in SYMBOLS
            if not self.portfolio.is_flat(self.instrument_ids[symbol])
        ]
        self.diagnostics["max_open_positions_observed"] = max(
            int(self.diagnostics["max_open_positions_observed"]),
            len(open_symbols),
        )
        if len(open_symbols) > 1:
            self.diagnostics["global_position_violations"] += 1
            for symbol in open_symbols:
                self.cancel_all_orders(self.instrument_ids[symbol])
                self.close_all_positions(self.instrument_ids[symbol])
            return
        if open_symbols:
            self.current_symbol = open_symbols[0]
            self._manage_open_position(ts_event)
            return
        if self.entry_pending:
            self.diagnostics["max_simultaneous_entry_intents"] = max(
                int(self.diagnostics["max_simultaneous_entry_intents"]), 1
            )
            if self.minute_index - self.entry_pending_minute > 2:
                assert self.current_symbol is not None
                self.cancel_all_orders(self.instrument_ids[self.current_symbol])
                self.diagnostics["entry_expirations"] += 1
                self._event(
                    "ENTRY_EXPIRED",
                    ts_event,
                    reason="NOT_FILLED_WITHIN_TWO_COMPLETE_MINUTES",
                )
                self._clear_trade_state()
            return
        if not (
            self.config.evaluation_start_ns
            <= ts_event
            <= self.config.evaluation_end_ns
        ):
            return

        moment = datetime.fromtimestamp(ts_event / 1_000_000_000, tz=timezone.utc)
        if (
            moment.minute % self.route_config.bucket_minutes
            != self.route_config.bucket_minutes - 1
        ):
            return
        required_bars = self.route_config.bucket_minutes * (
            self.route_config.el_slow_ewo_period + 5
        )
        if any(len(self.bars[symbol]) < required_bars for symbol in SYMBOLS):
            return

        features = {
            symbol: FeatureObservation(
                int(self.bars[symbol][-1].ts_event),
                ready=True,
            )
            for symbol in SYMBOLS
        }
        self.diagnostics["quarter_hour_decisions"] += 1
        _, decisions = route_universe(
            bars_by_symbol={
                symbol: tuple(self.bars[symbol])
                for symbol in SYMBOLS
            },
            features_by_symbol=features,
            config=self.route_config,
        )
        reason_counts = self.diagnostics.setdefault(
            "unresolved_reason_counts",
            {},
        )
        family_counts = self.diagnostics.setdefault(
            "actionable_family_counts",
            {},
        )
        for decision in decisions.values():
            counts = self.diagnostics["route_counts"]
            counts[decision.state] = int(counts.get(decision.state, 0)) + 1
            if decision.actionable:
                family_counts[decision.state] = (
                    int(family_counts.get(decision.state, 0)) + 1
                )
            else:
                for reason in decision.reasons:
                    reason_counts[reason] = int(reason_counts.get(reason, 0)) + 1

        actionable = [
            decision for decision in decisions.values() if decision.actionable
        ]
        self.diagnostics["source_signals_before_execution_filters"] += len(actionable)
        unused = []
        for decision in actionable:
            key = (decision.symbol, decision.state, int(decision.episode_ts))
            if key in self.used_episode_keys:
                self.diagnostics["used_episode_rejections"] += 1
            else:
                unused.append(decision)
        unused.sort(key=lambda item: (-item.score, item.symbol))
        winner = unused[0] if unused else None
        if winner is None:
            self.diagnostics["unresolved_episodes"] += 1
            return
        if self._funding_blackout(ts_event):
            self.diagnostics["funding_runway_rejections"] += 1
            return
        if (
            self.minute_index - self.last_entry_minute
            < self.config.cooldown_minutes
        ):
            self.diagnostics["cooldown_rejections"] += 1
            return

        self.used_episode_keys.add(
            (winner.symbol, winner.state, int(winner.episode_ts))
        )
        self._trail_active = False
        self._trail_best = None
        self._last_long_condition = winner.side > 0
        self._last_short_condition = winner.side < 0
        self._submit_decision(winner, ts_event)

    def _roi_profit_ratio(self, elapsed_minutes: int) -> float:
        result = self._roi_schedule[0][1]
        for minute, value in self._roi_schedule:
            if elapsed_minutes >= minute:
                result = value
            else:
                break
        return result

    def _source_signal_state(self) -> tuple[bool, bool]:
        if self.current_symbol is None:
            return False, False
        long_condition, short_condition, _ = source_conditions(
            tuple(self.bars[self.current_symbol]),
            self.route_config,
        )
        return long_condition, short_condition

    def _close_source_position(
        self,
        event_type: str,
        ts_event: int,
        **details: float | int | str,
    ) -> None:
        assert self.current_symbol is not None
        instrument_id = self.instrument_ids[self.current_symbol]
        self.cancel_all_orders(instrument_id)
        self.close_all_positions(instrument_id)
        self._event(event_type, ts_event, **details)

    def _manage_open_position(self, ts_event: int) -> None:
        if self.current_symbol is None:
            return
        scenario = self.current_scenario or {}
        if scenario.get("state") == EL_STATE:
            side = int(scenario.get("side", 0))
            entry = float(scenario.get("entry_reference", 0.0))
            bar = self.bars[self.current_symbol][-1]
            leverage = max(self.route_config.el_source_leverage, 1e-12)
            moment = datetime.fromtimestamp(ts_event / 1_000_000_000, tz=timezone.utc)
            complete_source_candle = (
                moment.minute % self.route_config.bucket_minutes
                == self.route_config.bucket_minutes - 1
            )
            if complete_source_candle:
                (
                    self._last_long_condition,
                    self._last_short_condition,
                ) = self._source_signal_state()
            long_condition = self._last_long_condition
            short_condition = self._last_short_condition
            if complete_source_candle:
                opposite_exit = short_condition if side > 0 else long_condition
                if opposite_exit:
                    self.diagnostics["el_signal_exits"] += 1
                    self._close_source_position(
                        "PUBLIC_EL_OPPOSITE_SIGNAL_EXIT",
                        ts_event,
                        long_condition=int(long_condition),
                        short_condition=int(short_condition),
                    )
                    return

            if side in (-1, 1) and math.isfinite(entry) and entry > 0.0:
                trail_activation = (
                    self.route_config.el_trailing_offset / leverage
                )
                trail_distance = (
                    self.route_config.el_trailing_positive / leverage
                )

                # Existing trailing stop is tested before incorporating this
                # minute's new favourable extreme, avoiding same-bar path guesses.
                if self._trail_active and self._trail_best is not None:
                    if side > 0:
                        trailing_stop = self._trail_best * (1.0 - trail_distance)
                        trailing_hit = float(bar.low) <= trailing_stop
                    else:
                        trailing_stop = self._trail_best * (1.0 + trail_distance)
                        trailing_hit = float(bar.high) >= trailing_stop
                    if trailing_hit:
                        self.diagnostics["el_trailing_exits"] += 1
                        self._close_source_position(
                            "PUBLIC_EL_TRAILING_EXIT",
                            ts_event,
                            trailing_stop=trailing_stop,
                            best_price=self._trail_best,
                            activation_fraction=trail_activation,
                            trail_fraction=trail_distance,
                        )
                        return

                elapsed = max(0, self.minute_index - self.position_open_minute)
                current_entry_signal = (
                    long_condition if side > 0 else short_condition
                )
                if not current_entry_signal:
                    source_roi = self._roi_profit_ratio(elapsed)
                    roi_fraction = source_roi / leverage
                    roi_target = entry * (1.0 + side * roi_fraction)
                    roi_hit = (
                        float(bar.high) >= roi_target
                        if side > 0
                        else float(bar.low) <= roi_target
                    )
                    if roi_hit:
                        self.diagnostics["el_roi_exits"] += 1
                        self._close_source_position(
                            "PUBLIC_EL_ROI_EXIT",
                            ts_event,
                            elapsed_minutes=elapsed,
                            source_roi_profit_ratio=source_roi,
                            underlying_roi_fraction=roi_fraction,
                            roi_target=roi_target,
                        )
                        return
                elif complete_source_candle:
                    self.diagnostics["el_roi_ignored_by_entry_signal"] += 1

                favourable = float(bar.high) if side > 0 else float(bar.low)
                move = side * (favourable - entry) / entry
                if not self._trail_active and move >= trail_activation:
                    self._trail_active = True
                    self._trail_best = favourable
                    self.diagnostics["el_trailing_activations"] += 1
                    self._event(
                        "PUBLIC_EL_TRAILING_ACTIVATED",
                        ts_event,
                        favourable_price=favourable,
                        activation_fraction=trail_activation,
                    )
                elif self._trail_active:
                    assert self._trail_best is not None
                    self._trail_best = (
                        max(self._trail_best, favourable)
                        if side > 0
                        else min(self._trail_best, favourable)
                    )
        super()._manage_open_position(ts_event)

    def _clear_trade_state(self) -> None:
        super()._clear_trade_state()
        self._trail_active = False
        self._trail_best = None
        self._last_long_condition = False
        self._last_short_condition = False


__all__ = ["Candidate35Config", "Candidate35Strategy"]
