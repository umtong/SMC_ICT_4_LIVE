from __future__ import annotations
import copy, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WORK=Path(".work/candidate-51-z15-v13")
ART=Path("artifacts/candidate-51")
EVID=ROOT/"evidence"/"v13-zaratustra15"
WORK.mkdir(parents=True,exist_ok=True); ART.mkdir(parents=True,exist_ok=True)
base=json.loads((ROOT/"config.json").read_text())
variants={
 "source_absolute_0p2":{"z15_atr_mode":"absolute","z15_atr_threshold":0.2,"z15_enable_di":True,"z15_enable_bb":True},
 "scaled_atr_0p20pct":{"z15_atr_mode":"fraction","z15_atr_threshold":0.0020,"z15_enable_di":True,"z15_enable_bb":True},
 "scaled_atr_0p35pct":{"z15_atr_mode":"fraction","z15_atr_threshold":0.0035,"z15_enable_di":True,"z15_enable_bb":True},
 "bb_cross_only":{"z15_atr_mode":"off","z15_atr_threshold":1.0,"z15_enable_di":False,"z15_enable_bb":True},
 "di_scaled_0p35pct":{"z15_atr_mode":"fraction","z15_atr_threshold":0.0035,"z15_enable_di":True,"z15_enable_bb":False},
}
legacy={"sma_offset_low","sma_offset_high","sma_stop_min_fraction","sma_stop_max_fraction","sma_stop_atr_buffer"}
common={
 "cooldown_minutes":0,"max_hold_minutes":4320,
 "funding_flatten_minute":60,"funding_blackout_before_minutes":-1,"funding_blackout_after_minutes":-1,
 "z15_di_period":14,"z15_mfi_period":14,"z15_bb_period":20,"z15_bb_stdev":2.0,
 "z15_source_leverage":10.0,"z15_source_stoploss":0.15,
 "z15_trailing_positive":0.012,"z15_trailing_offset":0.107,"z15_remote_target_r":20.0,
}
manifest={"family":"public_ZaratustraV15","source":"remiotore/ccxt-freqtrade/strategies/ZaratustraV15.py",
 "development":["2026-06-01","2026-06-14"],"untouched_continuous":["2026-06-15","2026-07-05"],
 "variants":variants,"selection":"highest positive post-cost geometric growth with >=1 independent trade/calendar day; otherwise diagnostic best"}
(WORK/"manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
for name,extra in variants.items():
 cfg=copy.deepcopy(base)
 for key in legacy: cfg["strategy"].pop(key,None)
 cfg["strategy"].update(common); cfg["strategy"].update(extra)
 (WORK/f"{name}.json").write_text(json.dumps(cfg,indent=2,sort_keys=True)+"\n")

def run(name,start,end,label):
 out=ART/f"z15-v13-{name}-{label}"
 workspace=Path(".work")/f"candidate-51-z15-v13-{name}-{label}"
 cmd=[sys.executable,str(ROOT/"launch.py"),"--config",str(WORK/f"{name}.json"),
      "--start",start,"--end",end,"--cache",".cache/candidate-51-z15-v13",
      "--output",str(out),"--workspace",str(workspace)]
 print("RUN",name,label,flush=True)
 status=subprocess.run(cmd,env={**__import__("os").environ,"PYTHONPATH":str(ROOT)},check=False).returncode
 return status,out

comparison={}
for name in variants:
 status,out=run(name,"2026-06-01","2026-06-14","development")
 mp,dp=out/"metrics.json",out/"strategy_diagnostics.json"
 row={"status":status,"produced":mp.is_file() and dp.is_file()}
 if row["produced"]:
  m=json.loads(mp.read_text()); d=json.loads(dp.read_text())
  for key in ("ending_nav","total_return","geometric_daily_growth","max_drawdown","trades","wins","losses","win_rate","profit_factor","expectancy_usdt","largest_winner_share"):
   row[key]=m.get(key)
  row.update({"source_signals":d.get("source_signals_before_execution_filters"),"entries":d.get("entry_submissions"),
   "trailing_activations":d.get("z15_trailing_activations"),"trailing_exits":d.get("z15_trailing_exits"),
   "selected_symbols":d.get("selected_symbols"),"route_counts":d.get("route_counts"),
   "global_position_violations":d.get("global_position_violations"),"order_rejections":d.get("order_rejections")})
 comparison[name]=row
eligible=[name for name,row in comparison.items() if row.get("produced")
          and int(row.get("trades") or 0)>=14 and float(row.get("geometric_daily_growth") or 0)>0
          and float(row.get("expectancy_usdt") or 0)>0 and float(row.get("max_drawdown") or 1)<=0.20
          and int(row.get("global_position_violations") or 0)==0 and int(row.get("order_rejections") or 0)==0]
pool=eligible or [name for name,row in comparison.items() if row.get("produced")]
pool.sort(key=lambda name:(-float(comparison[name].get("geometric_daily_growth") or -99),
                           -float(comparison[name].get("expectancy_usdt") or -1e30),
                           -int(comparison[name].get("trades") or 0),name))
selected=pool[0] if pool else None
decision={"comparison":comparison,"eligible":eligible,"selected":selected,
          "status":"TEST_UNTOUCHED" if eligible else "DIAGNOSTIC_ONLY"}
devout=ART/"z15-v13-development-comparison.json"; devout.write_text(json.dumps(decision,indent=2,sort_keys=True)+"\n")
print(json.dumps(decision,indent=2,sort_keys=True))
assessment={"variant":selected,"produced":False,"project_target_pass":False}
if selected:
 status,out=run(selected,"2026-06-15","2026-07-05","untouched-continuous")
 mp,dp=out/"metrics.json",out/"strategy_diagnostics.json"
 if mp.is_file() and dp.is_file():
  m=json.loads(mp.read_text()); d=json.loads(dp.read_text())
  checks={"trades_at_least_calendar_days":int(m.get("trades") or 0)>=21,
          "daily_growth_at_least_1pct":float(m.get("geometric_daily_growth") or 0)>=0.01,
          "positive_expectancy":float(m.get("expectancy_usdt") or 0)>0,
          "drawdown_lte_20pct":float(m.get("max_drawdown") or 1)<=0.20,
          "one_position":int(d.get("global_position_violations") or 0)==0,
          "no_order_rejections":int(d.get("order_rejections") or 0)==0}
  assessment={"variant":selected,"status":status,"produced":True,
   **{k:m.get(k) for k in ("ending_nav","total_return","geometric_daily_growth","max_drawdown","trades","wins","losses","win_rate","profit_factor","expectancy_usdt","largest_winner_share")},
   "source_signals":d.get("source_signals_before_execution_filters"),"entries":d.get("entry_submissions"),
   "trailing_activations":d.get("z15_trailing_activations"),"trailing_exits":d.get("z15_trailing_exits"),
   "selected_symbols":d.get("selected_symbols"),"route_counts":d.get("route_counts"),
   "checks":checks,"project_target_pass":all(checks.values())}
holdout=ART/"z15-v13-untouched-assessment.json"; holdout.write_text(json.dumps(assessment,indent=2,sort_keys=True)+"\n")
if EVID.exists(): __import__("shutil").rmtree(EVID)
(EVID/"development").mkdir(parents=True); (EVID/"untouched").mkdir(parents=True)
__import__("shutil").copy2(WORK/"manifest.json",EVID/"manifest.json")
__import__("shutil").copy2(devout,EVID/"development"/"comparison.json")
__import__("shutil").copy2(holdout,EVID/"untouched"/"assessment.json")
for name in variants:
 src=ART/f"z15-v13-{name}-development"; dst=EVID/"development"/name
 if src.is_dir():
  dst.mkdir()
  for f in ("metrics.json","strategy_diagnostics.json","run.json","data_manifest.json","closed_scenarios.json"):
   if (src/f).is_file(): __import__("shutil").copy2(src/f,dst/f)
if selected:
 src=ART/f"z15-v13-{selected}-untouched-continuous"
 if src.is_dir():
  for f in ("metrics.json","strategy_diagnostics.json","run.json","data_manifest.json","closed_scenarios.json"):
   if (src/f).is_file(): __import__("shutil").copy2(src/f,EVID/"untouched"/f)
print(json.dumps(assessment,indent=2,sort_keys=True))
