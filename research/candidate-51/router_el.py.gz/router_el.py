
"""Causal adapter for the public Freqtrade ``el`` futures strategy.

Source decision policy (5-minute completed candles):
- long when price is below EMA(12)*low_offset and either
  (SMA50-SMA200)/close is strongly positive with RSI(14) below its ceiling,
  or that oscillator is deeply negative;
- short when price is above EMA(72)*high_offset;
- opposite entry condition is the source exit signal.

The original strategy uses 10x leverage. Profit/stop/trailing ratios are
therefore translated to underlying-price distances before the project shell
sizes quantity from its strict 3% current-NAV loss budget.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Mapping, Sequence

EL_STATE = "PUBLIC_EL_SMAOFFSET_EWO"
SMA_OFFSET_STATE = EL_STATE
UNRESOLVED = "UNRESOLVED"
_EPS = 1e-12
_SYMBOL_PRIORITY = {"BTCUSDT": 0, "ETHUSDT": 1, "SOLUSDT": 2, "XRPUSDT": 3}


@dataclass(frozen=True, slots=True)
class BarObservation:
    ts_event: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True, slots=True)
class FeatureObservation:
    observed_time_ns: int
    ready: bool = True
    flow_open_10s: float = math.nan
    notional_open_10s_burst: float = math.nan
    flow_60s: float = math.nan
    efficiency_60s: float = math.nan
    oi_change_15m: float = math.nan
    premium_z: float = math.nan


@dataclass(frozen=True, slots=True)
class RouteConfig:
    # Compatibility fields expected by the shared Nautilus execution shell.
    atr_period: int = 30
    min_impulse_atr_continuation: float = 0.20
    min_impulse_atr_reversal: float = 1.05
    min_response_atr: float = 0.08
    min_participation_ratio: float = 0.85
    min_route_score: float = 3.20
    ambiguity_score_gap: float = 0.10
    continuation_target_r: float = 2.00
    reversal_target_r: float = 1.65

    bucket_minutes: int = 5
    el_buy_ema_period: int = 12
    el_sell_ema_period: int = 72
    el_fast_ewo_period: int = 50
    el_slow_ewo_period: int = 200
    el_rsi_period: int = 14
    el_low_offset: float = 0.915
    el_high_offset: float = 1.008
    el_ewo_high: float = 4.428
    el_ewo_low: float = -12.383
    el_rsi_buy: float = 44.0
    el_allow_long: bool = True
    el_allow_short: bool = True
    el_source_leverage: float = 10.0
    el_source_stoploss: float = 0.242
    el_trailing_positive: float = 0.005
    el_trailing_offset: float = 0.030
    el_emergency_target_fraction: float = 0.05

    # Legacy constructor compatibility.
    sma_offset_period: int = 8
    sma_offset_low: float = 0.960
    sma_offset_high: float = 1.012
    sma_trend_fast: int = 20
    sma_trend_slow: int = 25
    sma_stop_min_fraction: float = 0.0075
    sma_stop_max_fraction: float = 0.1000
    sma_stop_atr_buffer: float = 0.50
    sma_structural_lookback: int = 6
    sma_min_reward_r: float = 1.00


@dataclass(frozen=True, slots=True)
class RouteDecision:
    symbol: str
    state: str
    side: int
    score: float
    entry_reference: float
    stop_reference: float
    objective_reference: float
    episode_ts: int
    reasons: tuple[str, ...] = ()
    diagnostics: Mapping[str, float | int | str] = field(default_factory=dict)

    @property
    def actionable(self) -> bool:
        return self.side in (-1, 1) and self.state != UNRESOLVED


def _finite(value: float) -> bool:
    return math.isfinite(float(value))


def _aggregate_complete(
    bars: Sequence[BarObservation],
    bucket_minutes: int,
) -> list[BarObservation]:
    """Aggregate phase-aligned complete 1m bars; supports Binance's 1ms close."""
    if bucket_minutes <= 0:
        raise ValueError("bucket_minutes must be positive")
    if not bars:
        return []
    minute_ns = 60_000_000_000
    phase = int(bars[-1].ts_event) % minute_ns
    grouped: dict[int, list[tuple[int, BarObservation]]] = {}
    for bar in bars:
        timestamp = int(bar.ts_event)
        if timestamp % minute_ns != phase:
            continue
        ordinal = (timestamp - phase) // minute_ns
        grouped.setdefault(ordinal // bucket_minutes, []).append((ordinal, bar))
    output: list[BarObservation] = []
    for unordered in grouped.values():
        indexed = sorted(unordered, key=lambda item: item[0])
        if len(indexed) != bucket_minutes:
            continue
        ordinals = [item[0] for item in indexed]
        if ordinals[0] % bucket_minutes != 0:
            continue
        if ordinals[-1] % bucket_minutes != bucket_minutes - 1:
            continue
        if any(ordinals[i] - ordinals[i - 1] != 1 for i in range(1, len(ordinals))):
            continue
        items = [item[1] for item in indexed]
        output.append(
            BarObservation(
                ts_event=int(items[-1].ts_event),
                open=float(items[0].open),
                high=max(float(item.high) for item in items),
                low=min(float(item.low) for item in items),
                close=float(items[-1].close),
                volume=sum(max(0.0, float(item.volume)) for item in items),
            )
        )
    output.sort(key=lambda item: item.ts_event)
    return output


def _sma(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0:
        return result
    running = 0.0
    for index, raw in enumerate(values):
        running += float(raw)
        if index >= period:
            running -= float(values[index - period])
        if index >= period - 1:
            result[index] = running / period
    return result


def _ema(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0 or len(values) < period:
        return result
    current = sum(float(value) for value in values[:period]) / period
    result[period - 1] = current
    alpha = 2.0 / (period + 1.0)
    for index in range(period, len(values)):
        current = alpha * float(values[index]) + (1.0 - alpha) * current
        result[index] = current
    return result


def _rsi(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0 or len(values) <= period:
        return result
    gains = [0.0] * len(values)
    losses = [0.0] * len(values)
    for index in range(1, len(values)):
        change = float(values[index]) - float(values[index - 1])
        gains[index] = max(change, 0.0)
        losses[index] = max(-change, 0.0)
    average_gain = sum(gains[1 : period + 1]) / period
    average_loss = sum(losses[1 : period + 1]) / period

    def value(gain: float, loss: float) -> float:
        if loss <= _EPS:
            return 100.0 if gain > _EPS else 50.0
        return 100.0 - 100.0 / (1.0 + gain / loss)

    result[period] = value(average_gain, average_loss)
    for index in range(period + 1, len(values)):
        average_gain = (average_gain * (period - 1) + gains[index]) / period
        average_loss = (average_loss * (period - 1) + losses[index]) / period
        result[index] = value(average_gain, average_loss)
    return result


def _series(
    bars: Sequence[BarObservation],
    config: RouteConfig,
) -> tuple[list[BarObservation], dict[str, list[float]]]:
    candles = _aggregate_complete(bars, config.bucket_minutes)
    closes = [float(candle.close) for candle in candles]
    fast = _sma(closes, config.el_fast_ewo_period)
    slow = _sma(closes, config.el_slow_ewo_period)
    ewo = [
        (a - b) / max(abs(close), _EPS) * 100.0
        if all(_finite(value) for value in (a, b, close))
        else math.nan
        for a, b, close in zip(fast, slow, closes, strict=True)
    ]
    return candles, {
        "ema_buy": _ema(closes, config.el_buy_ema_period),
        "ema_sell": _ema(closes, config.el_sell_ema_period),
        "ewo": ewo,
        "rsi": _rsi(closes, config.el_rsi_period),
    }


def _conditions(
    candles: Sequence[BarObservation],
    indicators: Mapping[str, Sequence[float]],
    index: int,
    config: RouteConfig,
) -> tuple[bool, bool, dict[str, float | int | str]]:
    if index < 0 or index >= len(candles):
        return False, False, {}
    close = float(candles[index].close)
    volume = float(candles[index].volume)
    ema_buy = float(indicators["ema_buy"][index])
    ema_sell = float(indicators["ema_sell"][index])
    ewo = float(indicators["ewo"][index])
    rsi = float(indicators["rsi"][index])
    diagnostics: dict[str, float | int | str] = {
        "close": close,
        "volume": volume,
        "ema_buy": ema_buy,
        "ema_sell": ema_sell,
        "ewo": ewo,
        "rsi": rsi,
    }
    if not all(_finite(value) for value in (close, volume, ema_buy, ema_sell, ewo, rsi)):
        return False, False, diagnostics
    discount = close < ema_buy * config.el_low_offset
    long_positive = discount and ewo > config.el_ewo_high and rsi < config.el_rsi_buy
    long_negative = discount and ewo < config.el_ewo_low
    long_ok = bool(config.el_allow_long and volume > 0.0 and (long_positive or long_negative))
    short_ok = bool(
        config.el_allow_short
        and volume > 0.0
        and close > ema_sell * config.el_high_offset
    )
    diagnostics.update(
        {
            "discount": int(discount),
            "long_positive_ewo": int(long_positive),
            "long_negative_ewo": int(long_negative),
            "long_condition": int(long_ok),
            "short_condition": int(short_ok),
        }
    )
    return long_ok, short_ok, diagnostics


def _episode_start(
    candles: Sequence[BarObservation],
    indicators: Mapping[str, Sequence[float]],
    side: int,
    config: RouteConfig,
) -> int:
    index = len(candles) - 1
    current = _conditions(candles, indicators, index, config)
    active = current[0] if side > 0 else current[1]
    if not active:
        return 0
    while index > 0:
        prior = _conditions(candles, indicators, index - 1, config)
        prior_active = prior[0] if side > 0 else prior[1]
        if not prior_active:
            break
        index -= 1
    return int(candles[index].ts_event)


def _unresolved(
    symbol: str,
    reason: str,
    episode_ts: int = 0,
    diagnostics: Mapping[str, float | int | str] | None = None,
) -> RouteDecision:
    return RouteDecision(
        symbol=symbol,
        state=UNRESOLVED,
        side=0,
        score=0.0,
        entry_reference=math.nan,
        stop_reference=math.nan,
        objective_reference=math.nan,
        episode_ts=int(episode_ts),
        reasons=(reason,),
        diagnostics=dict(diagnostics or {}),
    )


def classify_symbol(
    symbol: str,
    bars: Sequence[BarObservation],
    feature: FeatureObservation,
    config: RouteConfig = RouteConfig(),
) -> RouteDecision:
    if not bars:
        return _unresolved(symbol, "NO_MINUTE_BARS")
    latest_ts = int(bars[-1].ts_event)
    if int(feature.observed_time_ns) > latest_ts:
        return _unresolved(symbol, "FUTURE_FEATURE_REJECTED", latest_ts)
    candles, indicators = _series(bars, config)
    minimum = max(
        config.el_slow_ewo_period + 2,
        config.el_sell_ema_period + 2,
        config.el_rsi_period + 2,
    )
    if len(candles) < minimum:
        return _unresolved(
            symbol,
            "EL_HISTORY_NOT_READY",
            latest_ts,
            {"five_minute_candles": len(candles), "minimum": minimum},
        )
    index = len(candles) - 1
    long_ok, short_ok, diagnostics = _conditions(candles, indicators, index, config)
    if long_ok == short_ok:
        reason = "EL_NO_SOURCE_ENTRY" if not long_ok else "EL_CONFLICTING_SOURCE_ENTRY"
        return _unresolved(symbol, reason, int(candles[index].ts_event), diagnostics)

    side = 1 if long_ok else -1
    entry = float(candles[index].close)
    leverage = max(float(config.el_source_leverage), _EPS)
    stop_fraction = float(config.el_source_stoploss) / leverage
    if side > 0:
        stop = entry * (1.0 - stop_fraction)
        objective = entry * (1.0 + config.el_emergency_target_fraction)
        score = (
            max(0.0, config.el_rsi_buy - float(diagnostics["rsi"])) / 10.0
            + abs(float(diagnostics["ewo"])) / 10.0
            + max(
                0.0,
                float(diagnostics["ema_buy"]) * config.el_low_offset / entry - 1.0,
            )
            * 100.0
        )
        tag = "ewo_smaoffset_long"
    else:
        stop = entry * (1.0 + stop_fraction)
        objective = entry * (1.0 - config.el_emergency_target_fraction)
        score = (
            max(
                0.0,
                entry / (float(diagnostics["ema_sell"]) * config.el_high_offset) - 1.0,
            )
            * 100.0
            + max(0.0, float(diagnostics["ewo"])) / 10.0
        )
        tag = "ema_offset_short"

    episode_ts = _episode_start(candles, indicators, side, config)
    diagnostics.update(
        {
            "source_tag": tag,
            "source_leverage": leverage,
            "source_stoploss_profit_ratio": config.el_source_stoploss,
            "underlying_stop_fraction": stop_fraction,
            "source_trailing_positive": config.el_trailing_positive,
            "source_trailing_offset": config.el_trailing_offset,
            "episode_start": episode_ts,
        }
    )
    return RouteDecision(
        symbol=symbol,
        state=EL_STATE,
        side=side,
        score=float(score),
        entry_reference=entry,
        stop_reference=stop,
        objective_reference=objective,
        episode_ts=episode_ts,
        reasons=(
            "PUBLIC_EL_SMAOFFSET_EWO_ENTRY",
            "SOURCE_10X_MANAGEMENT_CONVERTED_TO_UNDERLYING_DISTANCE",
        ),
        diagnostics=diagnostics,
    )


classify_sma_offset = classify_symbol


def source_conditions(
    bars: Sequence[BarObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[bool, bool, dict[str, float | int | str]]:
    candles, indicators = _series(bars, config)
    if not candles:
        return False, False, {"reason": "NO_COMPLETE_5M_CANDLE"}
    return _conditions(candles, indicators, len(candles) - 1, config)


def route_universe(
    bars_by_symbol: Mapping[str, Sequence[BarObservation]],
    features_by_symbol: Mapping[str, FeatureObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[RouteDecision | None, dict[str, RouteDecision]]:
    decisions = {
        symbol: classify_symbol(
            symbol,
            bars,
            features_by_symbol.get(
                symbol,
                FeatureObservation(bars[-1].ts_event if bars else 0, ready=True),
            ),
            config,
        )
        for symbol, bars in bars_by_symbol.items()
    }
    actionable = [decision for decision in decisions.values() if decision.actionable]
    actionable.sort(
        key=lambda item: (
            -float(item.score),
            _SYMBOL_PRIORITY.get(item.symbol, 99),
            item.symbol,
        )
    )
    return (actionable[0] if actionable else None), decisions


def sma_offset_exit_ready(
    bars: Sequence[BarObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[bool, dict[str, float | int | str]]:
    long_condition, short_condition, diagnostics = source_conditions(bars, config)
    diagnostics = dict(diagnostics)
    diagnostics.update(
        {
            "long_source_condition": int(long_condition),
            "short_source_condition": int(short_condition),
        }
    )
    return bool(long_condition or short_condition), diagnostics


__all__ = [
    "BarObservation",
    "FeatureObservation",
    "RouteConfig",
    "RouteDecision",
    "EL_STATE",
    "SMA_OFFSET_STATE",
    "UNRESOLVED",
    "classify_symbol",
    "classify_sma_offset",
    "route_universe",
    "source_conditions",
    "sma_offset_exit_ready",
]
