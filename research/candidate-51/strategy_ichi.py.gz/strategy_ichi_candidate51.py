"""NautilusTrader execution adapter for the public ichiV1/ichiV2 family."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from router import FeatureObservation, ICHI_STATE, ichi_exit_ready, route_universe
from strategy_base import SYMBOLS
from strategy_base import Candidate35Config as _ExecutionConfig
from strategy_base import Candidate35Strategy as _ExecutionShell


class Candidate35Config(_ExecutionConfig, frozen=True):
    ichi_conversion_period: int = 20
    ichi_base_period: int = 60
    ichi_span_period: int = 120
    ichi_displacement: int = 30
    ichi_above_cloud_level: int = 1
    ichi_bullish_level: int = 6
    ichi_fan_shift: int = 3
    ichi_min_fan_gain: float = 1.002
    ichi_exit_ema_period: int = 24
    ichi_allow_short: bool = False
    ichi_use_source_emergency_stop: bool = False
    ichi_source_stoploss: float = 0.275
    ichi_stop_atr_buffer: float = 0.20
    ichi_emergency_target_fraction: float = 0.10
    ichi_roi_0: float = 0.059
    ichi_roi_10: float = 0.037
    ichi_roi_41: float = 0.012
    ichi_roi_114: float = 0.0


class Candidate35Strategy(_ExecutionShell):
    """One four-symbol slot with source episodes, ROI, and EMA-cross exits."""

    def __init__(self, config: Candidate35Config) -> None:
        super().__init__(config)
        self.route_config = replace(
            self.route_config,
            ichi_conversion_period=int(config.ichi_conversion_period),
            ichi_base_period=int(config.ichi_base_period),
            ichi_span_period=int(config.ichi_span_period),
            ichi_displacement=int(config.ichi_displacement),
            ichi_above_cloud_level=int(config.ichi_above_cloud_level),
            ichi_bullish_level=int(config.ichi_bullish_level),
            ichi_fan_shift=int(config.ichi_fan_shift),
            ichi_min_fan_gain=float(config.ichi_min_fan_gain),
            ichi_exit_ema_period=int(config.ichi_exit_ema_period),
            ichi_allow_short=bool(config.ichi_allow_short),
            ichi_use_source_emergency_stop=bool(config.ichi_use_source_emergency_stop),
            ichi_source_stoploss=float(config.ichi_source_stoploss),
            ichi_stop_atr_buffer=float(config.ichi_stop_atr_buffer),
            ichi_emergency_target_fraction=float(config.ichi_emergency_target_fraction),
        )
        self._roi_schedule = (
            (0, float(config.ichi_roi_0)),
            (10, float(config.ichi_roi_10)),
            (41, float(config.ichi_roi_41)),
            (114, float(config.ichi_roi_114)),
        )
        self.diagnostics.setdefault("source_signals_before_execution_filters", 0)
        self.diagnostics.setdefault("funding_runway_rejections", 0)
        self.diagnostics.setdefault("cooldown_rejections", 0)
        self.diagnostics.setdefault("used_episode_rejections", 0)
        self.diagnostics.setdefault("ichi_source_exit_submissions", 0)
        self.diagnostics.setdefault("ichi_roi_exits", 0)
        self.used_episode_keys: set[tuple[str, str, int]] = set()

    def _on_complete_universe_minute(self, ts_event: int) -> None:
        self.minute_index += 1
        self.diagnostics["complete_universe_minutes"] += 1
        self._record_equity(ts_event)
        open_symbols = [
            symbol
            for symbol in SYMBOLS
            if not self.portfolio.is_flat(self.instrument_ids[symbol])
        ]
        self.diagnostics["max_open_positions_observed"] = max(
            int(self.diagnostics["max_open_positions_observed"]),
            len(open_symbols),
        )
        if len(open_symbols) > 1:
            self.diagnostics["global_position_violations"] += 1
            for symbol in open_symbols:
                self.cancel_all_orders(self.instrument_ids[symbol])
                self.close_all_positions(self.instrument_ids[symbol])
            return
        if open_symbols:
            self.current_symbol = open_symbols[0]
            self._manage_open_position(ts_event)
            return
        if self.entry_pending:
            self.diagnostics["max_simultaneous_entry_intents"] = max(
                int(self.diagnostics["max_simultaneous_entry_intents"]), 1,
            )
            if self.minute_index - self.entry_pending_minute > 2:
                assert self.current_symbol is not None
                self.cancel_all_orders(self.instrument_ids[self.current_symbol])
                self.diagnostics["entry_expirations"] += 1
                self._event(
                    "ENTRY_EXPIRED",
                    ts_event,
                    reason="NOT_FILLED_WITHIN_TWO_COMPLETE_MINUTES",
                )
                self._clear_trade_state()
            return
        if not (self.config.evaluation_start_ns <= ts_event <= self.config.evaluation_end_ns):
            return
        moment = datetime.fromtimestamp(ts_event / 1_000_000_000, tz=timezone.utc)
        if moment.minute % self.route_config.bucket_minutes != self.route_config.bucket_minutes - 1:
            return
        required_bars = self.route_config.bucket_minutes * max(
            100,
            self.route_config.ichi_span_period + self.route_config.ichi_displacement + 2,
            self.route_config.atr_period + 3,
        )
        if any(len(self.bars[symbol]) < required_bars for symbol in SYMBOLS):
            return

        features = {
            symbol: FeatureObservation(int(self.bars[symbol][-1].ts_event), ready=True)
            for symbol in SYMBOLS
        }
        self.diagnostics["quarter_hour_decisions"] += 1
        _, decisions = route_universe(
            bars_by_symbol={symbol: tuple(self.bars[symbol]) for symbol in SYMBOLS},
            features_by_symbol=features,
            config=self.route_config,
        )
        reason_counts = self.diagnostics.setdefault("unresolved_reason_counts", {})
        family_counts = self.diagnostics.setdefault("actionable_family_counts", {})
        for decision in decisions.values():
            counts = self.diagnostics["route_counts"]
            counts[decision.state] = int(counts.get(decision.state, 0)) + 1
            if decision.actionable:
                family_counts[decision.state] = int(family_counts.get(decision.state, 0)) + 1
            else:
                for reason in decision.reasons:
                    reason_counts[reason] = int(reason_counts.get(reason, 0)) + 1

        actionable = [decision for decision in decisions.values() if decision.actionable]
        self.diagnostics["source_signals_before_execution_filters"] += len(actionable)
        unused = []
        for decision in actionable:
            key = (decision.symbol, decision.state, int(decision.episode_ts))
            if key in self.used_episode_keys:
                self.diagnostics["used_episode_rejections"] += 1
            else:
                unused.append(decision)
        unused.sort(key=lambda item: (-item.score, item.symbol))
        winner = unused[0] if unused else None
        if winner is None:
            self.diagnostics["unresolved_episodes"] += 1
            return
        if self._funding_blackout(ts_event):
            self.diagnostics["funding_runway_rejections"] += 1
            return
        if self.minute_index - self.last_entry_minute < self.config.cooldown_minutes:
            self.diagnostics["cooldown_rejections"] += 1
            return
        self.used_episode_keys.add((winner.symbol, winner.state, int(winner.episode_ts)))
        self._submit_decision(winner, ts_event)

    def _roi_fraction(self, elapsed_minutes: int) -> float:
        result = self._roi_schedule[0][1]
        for minute, value in self._roi_schedule:
            if elapsed_minutes >= minute:
                result = value
            else:
                break
        return result

    def _manage_open_position(self, ts_event: int) -> None:
        if self.current_symbol is None:
            return
        scenario = self.current_scenario or {}
        if scenario.get("state") == ICHI_STATE:
            side = int(scenario.get("side", 0))
            entry = float(scenario.get("entry_reference", 0.0))
            bar = self.bars[self.current_symbol][-1]
            if side in (-1, 1) and entry > 0.0:
                moment = datetime.fromtimestamp(ts_event / 1_000_000_000, tz=timezone.utc)
                if moment.minute % self.route_config.bucket_minutes == self.route_config.bucket_minutes - 1:
                    source_exit, details = ichi_exit_ready(
                        tuple(self.bars[self.current_symbol]),
                        side,
                        self.route_config,
                    )
                    if source_exit:
                        instrument_id = self.instrument_ids[self.current_symbol]
                        self.cancel_all_orders(instrument_id)
                        self.close_all_positions(instrument_id)
                        self.diagnostics["ichi_source_exit_submissions"] += 1
                        self._event("PUBLIC_ICHI_EMA_CROSS_EXIT", ts_event, **details)
                        return

                elapsed = max(0, self.minute_index - self.position_open_minute)
                roi_fraction = self._roi_fraction(elapsed)
                target = entry * (1.0 + side * roi_fraction)
                hit = (
                    float(bar.high) >= target if side > 0
                    else float(bar.low) <= target
                )
                if hit:
                    instrument_id = self.instrument_ids[self.current_symbol]
                    self.cancel_all_orders(instrument_id)
                    self.close_all_positions(instrument_id)
                    self.diagnostics["ichi_roi_exits"] += 1
                    self._event(
                        "PUBLIC_ICHI_ROI_EXIT",
                        ts_event,
                        elapsed_minutes=elapsed,
                        roi_fraction=roi_fraction,
                        target=target,
                    )
                    return
        super()._manage_open_position(ts_event)


__all__ = ["Candidate35Config", "Candidate35Strategy"]
