"""NautilusTrader one-slot execution wrapper for public ZaratustraV15."""
from __future__ import annotations
from dataclasses import replace
from datetime import datetime, timezone
from router import FeatureObservation, Z15_STATE, route_universe
from strategy_base import SYMBOLS
from strategy_base import Candidate35Config as _ExecutionConfig
from strategy_base import Candidate35Strategy as _ExecutionShell

class Candidate35Config(_ExecutionConfig, frozen=True):
    z15_di_period: int = 14
    z15_mfi_period: int = 14
    z15_bb_period: int = 20
    z15_bb_stdev: float = 2.0
    z15_atr_mode: str = "absolute"
    z15_atr_threshold: float = 0.2
    z15_enable_di: bool = True
    z15_enable_bb: bool = True
    z15_source_leverage: float = 10.0
    z15_source_stoploss: float = 0.15
    z15_trailing_positive: float = 0.012
    z15_trailing_offset: float = 0.107
    z15_remote_target_r: float = 20.0

class Candidate35Strategy(_ExecutionShell):
    def __init__(self, config: Candidate35Config) -> None:
        super().__init__(config)
        self.route_config=replace(self.route_config,
            z15_di_period=int(config.z15_di_period),z15_mfi_period=int(config.z15_mfi_period),
            z15_bb_period=int(config.z15_bb_period),z15_bb_stdev=float(config.z15_bb_stdev),
            z15_atr_mode=str(config.z15_atr_mode),z15_atr_threshold=float(config.z15_atr_threshold),
            z15_enable_di=bool(config.z15_enable_di),z15_enable_bb=bool(config.z15_enable_bb),
            z15_source_leverage=float(config.z15_source_leverage),z15_source_stoploss=float(config.z15_source_stoploss),
            z15_trailing_positive=float(config.z15_trailing_positive),z15_trailing_offset=float(config.z15_trailing_offset),
            z15_remote_target_r=float(config.z15_remote_target_r))
        for key in ("source_signals_before_execution_filters","used_episode_rejections","z15_trailing_activations","z15_trailing_exits"):
            self.diagnostics.setdefault(key,0)
        self.used_episode_keys:set[tuple[str,str,int]]=set()
        self._trail_active=False
        self._trail_best:float|None=None

    def _on_complete_universe_minute(self, ts_event:int)->None:
        self.minute_index+=1
        self.diagnostics["complete_universe_minutes"]+=1
        self._record_equity(ts_event)
        open_symbols=[s for s in SYMBOLS if not self.portfolio.is_flat(self.instrument_ids[s])]
        self.diagnostics["max_open_positions_observed"]=max(int(self.diagnostics["max_open_positions_observed"]),len(open_symbols))
        if len(open_symbols)>1:
            self.diagnostics["global_position_violations"]+=1
            for s in open_symbols:
                self.cancel_all_orders(self.instrument_ids[s]); self.close_all_positions(self.instrument_ids[s])
            return
        if open_symbols:
            self.current_symbol=open_symbols[0]; self._manage_open_position(ts_event); return
        if self.entry_pending:
            self.diagnostics["max_simultaneous_entry_intents"]=max(int(self.diagnostics["max_simultaneous_entry_intents"]),1)
            if self.minute_index-self.entry_pending_minute>2:
                assert self.current_symbol is not None
                self.cancel_all_orders(self.instrument_ids[self.current_symbol])
                self.diagnostics["entry_expirations"]+=1
                self._event("ENTRY_EXPIRED",ts_event,reason="NOT_FILLED_WITHIN_TWO_COMPLETE_MINUTES")
                self._clear_trade_state()
            return
        if not (self.config.evaluation_start_ns<=ts_event<=self.config.evaluation_end_ns): return
        moment=datetime.fromtimestamp(ts_event/1_000_000_000,tz=timezone.utc)
        if moment.minute%self.route_config.bucket_minutes!=self.route_config.bucket_minutes-1: return
        required=self.route_config.bucket_minutes*max(self.route_config.z15_bb_period+5,self.route_config.z15_di_period*2+5,self.route_config.z15_mfi_period+5)
        if any(len(self.bars[s])<required for s in SYMBOLS): return
        features={s:FeatureObservation(int(self.bars[s][-1].ts_event),ready=True) for s in SYMBOLS}
        self.diagnostics["quarter_hour_decisions"]+=1
        _,decisions=route_universe({s:tuple(self.bars[s]) for s in SYMBOLS},features,self.route_config)
        reasons=self.diagnostics.setdefault("unresolved_reason_counts",{})
        families=self.diagnostics.setdefault("actionable_family_counts",{})
        for d in decisions.values():
            counts=self.diagnostics["route_counts"]; counts[d.state]=int(counts.get(d.state,0))+1
            if d.actionable: families[d.state]=int(families.get(d.state,0))+1
            else:
                for reason in d.reasons: reasons[reason]=int(reasons.get(reason,0))+1
        actionable=[d for d in decisions.values() if d.actionable]
        self.diagnostics["source_signals_before_execution_filters"]+=len(actionable)
        unused=[]
        for d in actionable:
            key=(d.symbol,d.state,int(d.episode_ts))
            if key in self.used_episode_keys: self.diagnostics["used_episode_rejections"]+=1
            else: unused.append(d)
        unused.sort(key=lambda d:(-d.score,d.symbol))
        winner=unused[0] if unused else None
        if winner is None:
            self.diagnostics["unresolved_episodes"]+=1; return
        if self._funding_blackout(ts_event): return
        if self.minute_index-self.last_entry_minute<self.config.cooldown_minutes: return
        self.used_episode_keys.add((winner.symbol,winner.state,int(winner.episode_ts)))
        self._trail_active=False; self._trail_best=None
        self._submit_decision(winner,ts_event)

    def _manage_open_position(self,ts_event:int)->None:
        if self.current_symbol is None: return
        scenario=self.current_scenario or {}
        if scenario.get("state")==Z15_STATE:
            side=int(scenario.get("side",0)); entry=float(scenario.get("entry_reference",0.0))
            bar=self.bars[self.current_symbol][-1]
            if side in (-1,1) and entry>0:
                activation=self.route_config.z15_trailing_offset/max(self.route_config.z15_source_leverage,1e-12)
                distance=self.route_config.z15_trailing_positive/max(self.route_config.z15_source_leverage,1e-12)
                if self._trail_active and self._trail_best is not None:
                    stop=self._trail_best*(1-side*distance)
                    hit=float(bar.low)<=stop if side>0 else float(bar.high)>=stop
                    if hit:
                        iid=self.instrument_ids[self.current_symbol]
                        self.cancel_all_orders(iid); self.close_all_positions(iid)
                        self.diagnostics["z15_trailing_exits"]+=1
                        self._event("PUBLIC_Z15_TRAILING_EXIT",ts_event,trailing_stop=stop,best_price=self._trail_best)
                        return
                favourable=float(bar.high) if side>0 else float(bar.low)
                move=side*(favourable-entry)/entry
                if not self._trail_active and move>=activation:
                    self._trail_active=True; self._trail_best=favourable
                    self.diagnostics["z15_trailing_activations"]+=1
                    self._event("PUBLIC_Z15_TRAILING_ACTIVATED",ts_event,favourable_price=favourable)
                elif self._trail_active:
                    assert self._trail_best is not None
                    self._trail_best=max(self._trail_best,favourable) if side>0 else min(self._trail_best,favourable)
        super()._manage_open_position(ts_event)

    def _clear_trade_state(self)->None:
        super()._clear_trade_state(); self._trail_active=False; self._trail_best=None

__all__=["Candidate35Config","Candidate35Strategy"]
