"""Smallfish signal-fusion adapter over real Binance aggTrades/bookDepth features.

This ports the public 13-category signal fusion and source profile geometry from
azseza/smallfish_, but deliberately does not reproduce its synthetic order book
or synthetic trade tape.  Candidate 05's checksum-verified Binance aggregates
provide the observable flow and depth state.  Every decision is causal and
NautilusTrader owns fills, fees, orders, positions, liquidation and NAV.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Mapping, Sequence

SMALLFISH_STATE = "PUBLIC_SMALLFISH_REAL_FLOW_FUSION"
SMA_OFFSET_STATE = SMALLFISH_STATE
UNRESOLVED = "UNRESOLVED"
_EPS = 1e-12
_SYMBOL_PRIORITY = {"BTCUSDT": 0, "ETHUSDT": 1, "SOLUSDT": 2, "XRPUSDT": 3}


@dataclass(frozen=True, slots=True)
class BarObservation:
    ts_event: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True, slots=True)
class FeatureObservation:
    observed_time_ns: int
    ready: bool = True
    flow_15s: float = math.nan
    flow_60s: float = math.nan
    flow_open_10s: float = math.nan
    flow_3m: float = math.nan
    notional_60s: float = math.nan
    notional_burst: float = math.nan
    notional_open_10s_burst: float = math.nan
    trade_count_60s: float = math.nan
    trade_count_burst: float = math.nan
    trade_vwap_60s: float = math.nan
    ret_60s_bps: float = math.nan
    path_60s_bps: float = math.nan
    efficiency_60s: float = math.nan
    flow_price_alignment_60s: float = math.nan
    absorption_60s: float = math.nan
    depth_snapshot_age_seconds: float = math.nan
    depth_imbalance_1: float = math.nan
    depth_imbalance_2: float = math.nan
    depth_imbalance_delta_1: float = math.nan
    bid_depth_change_1_1m: float = math.nan
    ask_depth_change_1_1m: float = math.nan
    bid_depth_change_1_5m: float = math.nan
    ask_depth_change_1_5m: float = math.nan


@dataclass(frozen=True, slots=True)
class RouteConfig:
    # Compatibility fields consumed by the common execution shell.
    atr_period: int = 30
    min_impulse_atr_continuation: float = 0.20
    min_impulse_atr_reversal: float = 1.05
    min_response_atr: float = 0.08
    min_participation_ratio: float = 0.85
    min_route_score: float = 3.20
    ambiguity_score_gap: float = 0.10
    continuation_target_r: float = 2.00
    reversal_target_r: float = 1.65

    # Public Smallfish source policy and explicit real-data adaptation.
    smallfish_bucket_minutes: int = 5
    smallfish_ema_fast: int = 3
    smallfish_ema_slow: int = 8
    smallfish_range_period: int = 20
    smallfish_vwap_period: int = 20
    smallfish_alpha: float = 4.0
    smallfish_enter_confidence: float = 0.58
    smallfish_exit_confidence: float = 0.30
    smallfish_min_signals: int = 3
    smallfish_signal_threshold: float = 0.10
    smallfish_prt_cancel_threshold: float = 0.60
    smallfish_prt_max_move_fraction: float = 0.50
    smallfish_sl_range_mult: float = 1.00
    smallfish_tp_range_mult: float = 2.50
    smallfish_min_stop_fraction: float = 0.0010
    smallfish_min_target_fraction: float = 0.0025
    smallfish_min_reward_r: float = 1.20
    smallfish_trail_pct: float = 0.20
    smallfish_trail_activation_r: float = 0.30
    smallfish_max_hold_candles: int = 12
    smallfish_opposite_exit_confidence: float = 0.65

    # Relative-volatility regime gates for real minute data.
    smallfish_low_mvr: float = 0.65
    smallfish_high_mvr: float = 1.50
    smallfish_extreme_mvr: float = 4.00

    # Public source weights: OBI/PRT/UMOM; LTB/SWEEP/ICE; VWAP/REGIME;
    # CVD/TPS/LIQ/MVR/ABS.
    smallfish_w_obi: float = 0.22
    smallfish_w_prt: float = 0.10
    smallfish_w_umom: float = 0.15
    smallfish_w_ltb: float = 0.08
    smallfish_w_sweep: float = 0.05
    smallfish_w_ice: float = 0.03
    smallfish_w_vwap: float = 0.05
    smallfish_w_regime: float = 0.02
    smallfish_w_cvd: float = 0.07
    smallfish_w_tps: float = 0.05
    smallfish_w_liq: float = 0.06
    smallfish_w_mvr: float = 0.06
    smallfish_w_absorb: float = 0.06

    # Legacy adapter compatibility.
    bucket_minutes: int = 5
    sma_offset_period: int = 8
    sma_offset_low: float = 0.960
    sma_offset_high: float = 1.012
    sma_trend_fast: int = 20
    sma_trend_slow: int = 25
    sma_stop_min_fraction: float = 0.0075
    sma_stop_max_fraction: float = 0.1000
    sma_stop_atr_buffer: float = 0.50
    sma_structural_lookback: int = 6
    sma_min_reward_r: float = 1.00


@dataclass(frozen=True, slots=True)
class RouteDecision:
    symbol: str
    state: str
    side: int
    score: float
    entry_reference: float
    stop_reference: float
    objective_reference: float
    episode_ts: int
    reasons: tuple[str, ...] = ()
    diagnostics: Mapping[str, float | int | str] = field(default_factory=dict)

    @property
    def actionable(self) -> bool:
        return self.side in (-1, 1) and self.state != UNRESOLVED


def _finite(value: float) -> bool:
    return math.isfinite(float(value))


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def _sigmoid(value: float) -> float:
    value = max(-60.0, min(60.0, float(value)))
    return 1.0 / (1.0 + math.exp(-value))


def _unresolved(
    symbol: str,
    reason: str,
    episode_ts: int = 0,
    diagnostics: Mapping[str, float | int | str] | None = None,
) -> RouteDecision:
    return RouteDecision(
        symbol=symbol,
        state=UNRESOLVED,
        side=0,
        score=0.0,
        entry_reference=math.nan,
        stop_reference=math.nan,
        objective_reference=math.nan,
        episode_ts=int(episode_ts),
        reasons=(reason,),
        diagnostics=dict(diagnostics or {}),
    )


def _aggregate_complete(
    bars: Sequence[BarObservation],
    bucket_minutes: int,
) -> list[BarObservation]:
    if bucket_minutes <= 0:
        raise ValueError("bucket_minutes must be positive")
    if not bars:
        return []
    minute_ns = 60_000_000_000
    phase = int(bars[-1].ts_event) % minute_ns
    grouped: dict[int, list[tuple[int, BarObservation]]] = {}
    for bar in bars:
        timestamp = int(bar.ts_event)
        if timestamp % minute_ns != phase:
            continue
        ordinal = (timestamp - phase) // minute_ns
        grouped.setdefault(ordinal // bucket_minutes, []).append((ordinal, bar))
    output: list[BarObservation] = []
    for unordered in grouped.values():
        indexed = sorted(unordered, key=lambda item: item[0])
        if len(indexed) != bucket_minutes:
            continue
        ordinals = [item[0] for item in indexed]
        if ordinals[0] % bucket_minutes != 0:
            continue
        if ordinals[-1] % bucket_minutes != bucket_minutes - 1:
            continue
        if any(
            ordinals[index] - ordinals[index - 1] != 1
            for index in range(1, len(ordinals))
        ):
            continue
        items = [item[1] for item in indexed]
        output.append(
            BarObservation(
                ts_event=int(items[-1].ts_event),
                open=float(items[0].open),
                high=max(float(item.high) for item in items),
                low=min(float(item.low) for item in items),
                close=float(items[-1].close),
                volume=sum(max(0.0, float(item.volume)) for item in items),
            )
        )
    output.sort(key=lambda item: item.ts_event)
    return output


def _ema(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0 or len(values) < period:
        return result
    current = sum(float(value) for value in values[:period]) / period
    result[period - 1] = current
    alpha = 2.0 / (period + 1.0)
    for index in range(period, len(values)):
        current = alpha * float(values[index]) + (1.0 - alpha) * current
        result[index] = current
    return result


def _weighted_vwap(candles: Sequence[BarObservation], period: int) -> float:
    if len(candles) < period:
        return math.nan
    window = candles[-period:]
    total_volume = sum(max(0.0, float(candle.volume)) for candle in window)
    if total_volume <= _EPS:
        return sum(float(candle.close) for candle in window) / len(window)
    return sum(
        float(candle.close) * max(0.0, float(candle.volume))
        for candle in window
    ) / total_volume


def _range_state(
    candles: Sequence[BarObservation],
    period: int,
) -> tuple[float, float, float]:
    if len(candles) < max(period + 1, 4):
        return math.nan, math.nan, math.nan
    window = candles[-period:]
    ranges = [
        max(float(candle.high) - float(candle.low), _EPS)
        for candle in window
    ]
    average_range = sum(ranges) / len(ranges)
    returns = [
        math.log(float(candles[index].close) / float(candles[index - 1].close))
        for index in range(1, len(candles))
        if float(candles[index - 1].close) > 0.0
    ]
    if len(returns) < 4:
        return average_range, math.nan, math.nan
    short = returns[-min(3, len(returns)):]
    long = returns[-min(period, len(returns)):]
    short_rv = math.sqrt(sum(value * value for value in short))
    long_rv = math.sqrt(sum(value * value for value in long))
    mvr = short_rv / max(long_rv * math.sqrt(len(short) / len(long)), _EPS)
    return average_range, short_rv, mvr


def _source_scores(
    candles: Sequence[BarObservation],
    feature: FeatureObservation,
    config: RouteConfig,
) -> tuple[dict[str, float], dict[str, float | int | str]]:
    closes = [float(candle.close) for candle in candles]
    ema_fast = _ema(closes, config.smallfish_ema_fast)
    ema_slow = _ema(closes, config.smallfish_ema_slow)
    if not (_finite(ema_fast[-1]) and _finite(ema_slow[-1])):
        return {}, {"ready": 0, "reason": "EMA_NOT_READY"}

    average_range, short_rv, mvr = _range_state(
        candles, config.smallfish_range_period
    )
    if not all(_finite(value) for value in (average_range, short_rv, mvr)):
        return {}, {"ready": 0, "reason": "RANGE_STATE_NOT_READY"}

    flow_60s = float(feature.flow_60s)
    flow_15s = (
        float(feature.flow_15s)
        if _finite(feature.flow_15s)
        else flow_60s
    )
    flow_3m = (
        float(feature.flow_3m)
        if _finite(feature.flow_3m)
        else flow_60s
    )
    depth = float(feature.depth_imbalance_1)
    depth_delta = (
        float(feature.depth_imbalance_delta_1)
        if _finite(feature.depth_imbalance_delta_1)
        else 0.0
    )
    buy_sell_ratio = _clamp((flow_60s + 1.0) / 2.0)
    ret_bps = (
        float(feature.ret_60s_bps)
        if _finite(feature.ret_60s_bps)
        else math.log(closes[-1] / closes[-2]) * 10_000.0
    )
    path_bps = (
        max(abs(float(feature.path_60s_bps)), abs(ret_bps), 1e-6)
        if _finite(feature.path_60s_bps)
        else max(abs(ret_bps), 1e-6)
    )
    efficiency = (
        _clamp(float(feature.efficiency_60s))
        if _finite(feature.efficiency_60s)
        else _clamp(abs(ret_bps) / path_bps)
    )
    notional_burst = (
        max(0.0, float(feature.notional_burst))
        if _finite(feature.notional_burst)
        else 1.0
    )
    opening_burst = (
        max(0.0, float(feature.notional_open_10s_burst))
        if _finite(feature.notional_open_10s_burst)
        else notional_burst
    )
    trade_count_burst = (
        max(0.0, float(feature.trade_count_burst))
        if _finite(feature.trade_count_burst)
        else 1.0
    )
    trade_rate = (
        max(0.0, float(feature.trade_count_60s)) / 60.0
        if _finite(feature.trade_count_60s)
        else 1.0
    )
    bid_change_1m = (
        float(feature.bid_depth_change_1_1m)
        if _finite(feature.bid_depth_change_1_1m)
        else 0.0
    )
    ask_change_1m = (
        float(feature.ask_depth_change_1_1m)
        if _finite(feature.ask_depth_change_1_1m)
        else 0.0
    )
    bid_change_5m = (
        float(feature.bid_depth_change_1_5m)
        if _finite(feature.bid_depth_change_1_5m)
        else bid_change_1m
    )
    ask_change_5m = (
        float(feature.ask_depth_change_1_5m)
        if _finite(feature.ask_depth_change_1_5m)
        else ask_change_1m
    )
    absorption = (
        _clamp(float(feature.absorption_60s))
        if _finite(feature.absorption_60s)
        else _clamp(abs(flow_60s) * (1.0 - efficiency))
    )

    # Relative realized-volatility regime over actual minute candles.
    if mvr < config.smallfish_low_mvr:
        vol_regime = 0.0
        regime_name = "low"
    elif mvr < config.smallfish_high_mvr:
        vol_regime = 0.5
        regime_name = "normal"
    elif mvr < config.smallfish_extreme_mvr:
        vol_regime = 1.0
        regime_name = "high"
    else:
        vol_regime = -1.0
        regime_name = "extreme"

    # 1) OBI — exact public formula, with real depth imbalance and its delta.
    spread_penalty = max(
        (float(feature.depth_snapshot_age_seconds) - 60.0) / 60.0,
        0.0,
    ) if _finite(feature.depth_snapshot_age_seconds) else 0.0
    micro_pressure = flow_15s
    obi_long = _clamp(
        0.5 * (depth + 0.6 * depth_delta + 0.2 * micro_pressure)
        - 0.15 * spread_penalty
    )
    obi_short = _clamp(
        0.5 * (-depth - 0.6 * depth_delta - 0.2 * micro_pressure)
        - 0.15 * spread_penalty
    )

    # 2) PRT — source cancellation logic mapped to real depth depletion.
    cancel_ask = _clamp(-ask_change_1m)
    cancel_bid = _clamp(-bid_change_1m)
    move_fraction = abs(ret_bps) / path_bps
    prt_long = 0.0
    prt_short = 0.0
    threshold = config.smallfish_prt_cancel_threshold
    if (
        cancel_ask > threshold
        and move_fraction < config.smallfish_prt_max_move_fraction
    ):
        intensity = (cancel_ask - threshold) / max(1.0 - threshold, _EPS)
        prt_long = _clamp(_sigmoid(3.0 * intensity) - 0.3)
    if (
        cancel_bid > threshold
        and move_fraction < config.smallfish_prt_max_move_fraction
    ):
        intensity = (cancel_bid - threshold) / max(1.0 - threshold, _EPS)
        prt_short = _clamp(_sigmoid(3.0 * intensity) - 0.3)

    # 3) UMOM — exact public momentum/flow confirmation formula.
    momentum_bps = (
        (float(ema_fast[-1]) - float(ema_slow[-1]))
        / max(float(ema_slow[-1]), _EPS)
        * 10_000.0
    )
    flow_confirm = 1.0
    if momentum_bps > 0.0 and buy_sell_ratio > 0.55:
        flow_confirm = 1.3
    elif momentum_bps < 0.0 and buy_sell_ratio < 0.45:
        flow_confirm = 1.3
    elif (
        (momentum_bps > 0.0 and buy_sell_ratio < 0.40)
        or (momentum_bps < 0.0 and buy_sell_ratio > 0.60)
    ):
        flow_confirm = 0.5
    umom_long = _clamp(
        (_sigmoid(2.0 * momentum_bps) - 0.5)
        * 2.0
        * flow_confirm
    )
    umom_short = _clamp(
        (_sigmoid(-2.0 * momentum_bps) - 0.5)
        * 2.0
        * flow_confirm
    )

    # 4-6) Whale burst / sweep / absorption-wall proxies from real flow+depth.
    burst_excess = max(max(notional_burst, opening_burst) - 1.0, 0.0)
    buy_burst = burst_excess * max(flow_15s, 0.0)
    sell_burst = burst_excess * max(-flow_15s, 0.0)
    total_burst = buy_burst + sell_burst
    if total_burst > _EPS:
        magnitude = _sigmoid(total_burst * 0.1) * 2.0
        ltb_long = _clamp(buy_burst / total_burst * magnitude)
        ltb_short = _clamp(sell_burst / total_burst * magnitude)
    else:
        ltb_long = ltb_short = 0.0
    sweep_up = _clamp(
        max(flow_15s, 0.0)
        * max(-ask_change_1m, -ask_change_5m, 0.0)
        * max(opening_burst, 1.0)
    )
    sweep_down = _clamp(
        max(-flow_15s, 0.0)
        * max(-bid_change_1m, -bid_change_5m, 0.0)
        * max(opening_burst, 1.0)
    )
    ice_absorb = _clamp(
        -flow_60s * absorption * 2.0,
        -1.0,
        1.0,
    )
    ice_long = _clamp(ice_absorb)
    ice_short = _clamp(-ice_absorb)

    # 7) VWAP deviation — public regime switch, normalized by actual range.
    vwap = _weighted_vwap(candles, config.smallfish_vwap_period)
    deviation_units = (
        (closes[-1] - vwap) / max(average_range, _EPS) * 5.0
    )
    if vol_regime < 0.0:
        vwap_long = vwap_short = 0.0
    else:
        mean_revert_strength = (
            1.0 if vol_regime <= 0.25
            else 0.5 if vol_regime <= 0.75
            else -0.3
        )
        norm_dev = deviation_units / 5.0
        vwap_long = _clamp(
            _sigmoid(2.0 * (-norm_dev * mean_revert_strength)) - 0.3
        )
        vwap_short = _clamp(
            _sigmoid(2.0 * (norm_dev * mean_revert_strength)) - 0.3
        )

    # 8) Regime activity modifier from actual trade count.
    activity_gate = _clamp(trade_rate / 5.0)
    if vol_regime < 0.0:
        regime_long = regime_short = 0.0
    elif vol_regime <= 0.25:
        regime_long, regime_short = 0.3 * activity_gate, 0.1 * activity_gate
    elif vol_regime <= 0.75:
        regime_long = regime_short = 0.5 * activity_gate
    else:
        regime_long = regime_short = 0.7 * activity_gate

    # 9) CVD — public acceleration/direction/divergence logic using flow horizons.
    cvd_accel = flow_15s - flow_3m
    cvd_norm = flow_3m
    divergence = (
        1.0 if ret_bps < -0.5 and cvd_norm > 0.1
        else -1.0 if ret_bps > 0.5 and cvd_norm < -0.1
        else 0.0
    )
    if trade_rate < 0.5:
        cvd_long = cvd_short = 0.0
    else:
        raw_cvd_long = _sigmoid(5.0 * cvd_accel) - 0.5
        raw_cvd_short = _sigmoid(-5.0 * cvd_accel) - 0.5
        if cvd_norm > 0.05 and raw_cvd_long > 0.0:
            raw_cvd_long *= 1.3
        elif cvd_norm < -0.05 and raw_cvd_short > 0.0:
            raw_cvd_short *= 1.3
        if divergence > 0.0:
            raw_cvd_long += 0.2
        elif divergence < 0.0:
            raw_cvd_short += 0.2
        cvd_long = _clamp(raw_cvd_long * 2.0)
        cvd_short = _clamp(raw_cvd_short * 2.0)

    # 10) TPS — exact public urgency gate using real count burst.
    if trade_count_burst < 1.5:
        tps_long = tps_short = 0.0
    else:
        urgency = _clamp((trade_count_burst - 1.5) / 1.5)
        if buy_sell_ratio > 0.55:
            tps_long = _clamp(
                urgency * _clamp((buy_sell_ratio - 0.55) / 0.15)
            )
            tps_short = 0.0
        elif buy_sell_ratio < 0.45:
            tps_short = _clamp(
                urgency * _clamp((0.45 - buy_sell_ratio) / 0.15)
            )
            tps_long = 0.0
        else:
            tps_long = tps_short = 0.0

    # 11) LIQ — preserve public directional wall logic; real raw depth size is
    # unavailable in the compact feature file, so activity/depth change gates it.
    thin_intensity = _clamp(
        max(abs(bid_change_1m), abs(ask_change_1m), abs(depth_delta))
    )
    liq_long = _clamp(
        thin_intensity * _clamp(depth) * (1.2 if depth > 0.1 else 1.0)
    )
    liq_short = _clamp(
        thin_intensity * _clamp(-depth) * (1.2 if depth < -0.1 else 1.0)
    )

    # 12) MVR — public breakout-follow/chop-fade policy.
    if mvr > config.smallfish_high_mvr:
        intensity = _clamp((mvr - config.smallfish_high_mvr) / 2.0)
        if momentum_bps > 0.0:
            mvr_long = _clamp(_sigmoid(2.0 * momentum_bps) * intensity)
            mvr_short = 0.0
        else:
            mvr_short = _clamp(_sigmoid(-2.0 * momentum_bps) * intensity)
            mvr_long = 0.0
    elif mvr < config.smallfish_low_mvr:
        intensity = _clamp(
            (config.smallfish_low_mvr - mvr)
            / max(config.smallfish_low_mvr, _EPS)
        )
        if momentum_bps > 0.5:
            mvr_long = 0.0
            mvr_short = _clamp(
                _sigmoid(2.0 * momentum_bps) * intensity * 0.5
            )
        elif momentum_bps < -0.5:
            mvr_long = _clamp(
                _sigmoid(-2.0 * momentum_bps) * intensity * 0.5
            )
            mvr_short = 0.0
        else:
            mvr_long = mvr_short = 0.0
    else:
        mvr_long = mvr_short = 0.0

    # 13) ABS — public absorption direction, real absorption_60s input.
    if move_fraction >= config.smallfish_prt_max_move_fraction:
        absorb_long = absorb_short = 0.0
    else:
        abs_intensity = _sigmoid(absorption * 10.0) - 0.5
        if abs_intensity < 0.05:
            absorb_long = absorb_short = 0.0
        elif buy_sell_ratio < 0.45:
            absorb_long = _clamp(abs_intensity * 2.0)
            absorb_short = 0.0
        elif buy_sell_ratio > 0.55:
            absorb_short = _clamp(abs_intensity * 2.0)
            absorb_long = 0.0
        else:
            absorb_long = absorb_short = 0.0

    scores = {
        "obi_long": obi_long,
        "obi_short": obi_short,
        "prt_long": prt_long,
        "prt_short": prt_short,
        "umom_long": umom_long,
        "umom_short": umom_short,
        "ltb_long": ltb_long,
        "ltb_short": ltb_short,
        "sweep_long": sweep_up,
        "sweep_short": sweep_down,
        "ice_long": ice_long,
        "ice_short": ice_short,
        "vwap_long": vwap_long,
        "vwap_short": vwap_short,
        "regime_long": regime_long,
        "regime_short": regime_short,
        "cvd_long": cvd_long,
        "cvd_short": cvd_short,
        "tps_long": tps_long,
        "tps_short": tps_short,
        "liq_long": liq_long,
        "liq_short": liq_short,
        "mvr_long": mvr_long,
        "mvr_short": mvr_short,
        "absorb_long": absorb_long,
        "absorb_short": absorb_short,
    }
    diagnostics: dict[str, float | int | str] = {
        "ready": 1,
        "flow_15s": flow_15s,
        "flow_60s": flow_60s,
        "flow_3m": flow_3m,
        "depth_imbalance_1": depth,
        "depth_delta": depth_delta,
        "buy_sell_ratio": buy_sell_ratio,
        "ret_60s_bps": ret_bps,
        "path_60s_bps": path_bps,
        "efficiency_60s": efficiency,
        "notional_burst": notional_burst,
        "opening_burst": opening_burst,
        "trade_count_burst": trade_count_burst,
        "trade_rate": trade_rate,
        "average_range": average_range,
        "momentum_bps": momentum_bps,
        "mvr": mvr,
        "vol_regime": vol_regime,
        "vol_regime_name": regime_name,
        "rolling_vwap": vwap,
        "vwap_deviation_units": deviation_units,
        "absorption": absorption,
        "cancel_ask_proxy": cancel_ask,
        "cancel_bid_proxy": cancel_bid,
    }
    for name, value in scores.items():
        diagnostics[name] = value
    return scores, diagnostics


def _weighted_meta(
    scores: Mapping[str, float],
    config: RouteConfig,
) -> tuple[float, float]:
    long_score = (
        config.smallfish_w_obi * scores["obi_long"]
        + config.smallfish_w_prt * scores["prt_long"]
        + config.smallfish_w_umom * scores["umom_long"]
        + config.smallfish_w_ltb * scores["ltb_long"]
        + config.smallfish_w_sweep * scores["sweep_long"]
        + config.smallfish_w_ice * scores["ice_long"]
        + config.smallfish_w_vwap * scores["vwap_long"]
        + config.smallfish_w_regime * scores["regime_long"]
        + config.smallfish_w_cvd * scores["cvd_long"]
        + config.smallfish_w_tps * scores["tps_long"]
        + config.smallfish_w_liq * scores["liq_long"]
        + config.smallfish_w_mvr * scores["mvr_long"]
        + config.smallfish_w_absorb * scores["absorb_long"]
    )
    short_score = (
        config.smallfish_w_obi * scores["obi_short"]
        + config.smallfish_w_prt * scores["prt_short"]
        + config.smallfish_w_umom * scores["umom_short"]
        + config.smallfish_w_ltb * scores["ltb_short"]
        + config.smallfish_w_sweep * scores["sweep_short"]
        + config.smallfish_w_ice * scores["ice_short"]
        + config.smallfish_w_vwap * scores["vwap_short"]
        + config.smallfish_w_regime * scores["regime_short"]
        + config.smallfish_w_cvd * scores["cvd_short"]
        + config.smallfish_w_tps * scores["tps_short"]
        + config.smallfish_w_liq * scores["liq_short"]
        + config.smallfish_w_mvr * scores["mvr_short"]
        + config.smallfish_w_absorb * scores["absorb_short"]
    )
    return long_score, short_score


def _agreement(
    scores: Mapping[str, float],
    side: int,
    threshold: float,
) -> int:
    suffix = "long" if side > 0 else "short"
    categories = (
        "obi", "prt", "umom", "ltb", "sweep", "ice", "vwap",
        "regime", "cvd", "tps", "liq", "mvr", "absorb",
    )
    return sum(
        float(scores[f"{name}_{suffix}"]) > threshold
        for name in categories
    )


def classify_symbol(
    symbol: str,
    bars: Sequence[BarObservation],
    feature: FeatureObservation,
    config: RouteConfig = RouteConfig(),
) -> RouteDecision:
    if not bars:
        return _unresolved(symbol, "NO_MINUTE_BARS")
    latest_ts = int(bars[-1].ts_event)
    if int(feature.observed_time_ns) > latest_ts:
        return _unresolved(symbol, "FUTURE_FEATURE_REJECTED", latest_ts)
    if not feature.ready:
        return _unresolved(symbol, "SMALLFISH_FEATURE_NOT_READY", latest_ts)

    candles = _aggregate_complete(bars, config.smallfish_bucket_minutes)
    minimum = max(
        config.smallfish_ema_slow + 2,
        config.smallfish_range_period + 2,
        config.smallfish_vwap_period + 2,
    )
    if len(candles) < minimum:
        return _unresolved(
            symbol,
            "SMALLFISH_HISTORY_NOT_READY",
            latest_ts,
            {"candles": len(candles), "minimum": minimum},
        )

    scores, diagnostics = _source_scores(candles, feature, config)
    if not scores:
        return _unresolved(
            symbol,
            "SMALLFISH_SOURCE_STATE_NOT_READY",
            candles[-1].ts_event,
            diagnostics,
        )
    if float(diagnostics["vol_regime"]) < 0.0:
        return _unresolved(
            symbol,
            "SMALLFISH_EXTREME_VOL_NO_TRADE",
            candles[-1].ts_event,
            diagnostics,
        )

    meta_long, meta_short = _weighted_meta(scores, config)
    raw = meta_long - meta_short
    if abs(raw) <= 1e-8:
        diagnostics.update(
            {"meta_long": meta_long, "meta_short": meta_short, "raw": raw}
        )
        return _unresolved(
            symbol,
            "SMALLFISH_META_DEADBAND",
            candles[-1].ts_event,
            diagnostics,
        )
    side = 1 if raw > 0.0 else -1
    confidence = _sigmoid(config.smallfish_alpha * abs(raw))
    agreement = _agreement(
        scores, side, config.smallfish_signal_threshold
    )
    diagnostics.update(
        {
            "meta_long": meta_long,
            "meta_short": meta_short,
            "raw": raw,
            "side": side,
            "confidence": confidence,
            "agreement": agreement,
            "required_agreement": config.smallfish_min_signals,
        }
    )
    if agreement < config.smallfish_min_signals:
        return _unresolved(
            symbol,
            "SMALLFISH_SIGNAL_AGREEMENT_GATE",
            candles[-1].ts_event,
            diagnostics,
        )
    if confidence < config.smallfish_enter_confidence:
        return _unresolved(
            symbol,
            "SMALLFISH_CONFIDENCE_GATE",
            candles[-1].ts_event,
            diagnostics,
        )

    entry = float(candles[-1].close)
    average_range = float(diagnostics["average_range"])
    stop_distance = max(
        average_range * config.smallfish_sl_range_mult,
        entry * config.smallfish_min_stop_fraction,
    )
    target_distance = max(
        average_range * config.smallfish_tp_range_mult,
        entry * config.smallfish_min_target_fraction,
    )
    stop = entry - side * stop_distance
    objective = entry + side * target_distance
    reward_r = target_distance / max(stop_distance, _EPS)
    diagnostics.update(
        {
            "entry": entry,
            "stop_distance": stop_distance,
            "target_distance": target_distance,
            "reward_r": reward_r,
            "source_profile": (
                f"sl={config.smallfish_sl_range_mult:.3f}range;"
                f"tp={config.smallfish_tp_range_mult:.3f}range;"
                f"signals={config.smallfish_min_signals};"
                f"C={config.smallfish_enter_confidence:.3f}"
            ),
            "external_source": "azseza/smallfish_",
            "feature_policy": "REAL_BINANCE_AGGTRADES_BOOKDEPTH_NOT_SYNTHETIC",
        }
    )
    if reward_r < config.smallfish_min_reward_r:
        return _unresolved(
            symbol,
            "SMALLFISH_INSUFFICIENT_REWARD_SPACE",
            candles[-1].ts_event,
            diagnostics,
        )
    return RouteDecision(
        symbol=symbol,
        state=SMALLFISH_STATE,
        side=side,
        score=confidence * 10.0 + reward_r + abs(raw),
        entry_reference=entry,
        stop_reference=stop,
        objective_reference=objective,
        episode_ts=int(candles[-1].ts_event),
        reasons=(
            "PUBLIC_SMALLFISH_13_SIGNAL_FUSION",
            "REAL_BINANCE_FLOW_AND_DEPTH_ADAPTATION",
            "SOURCE_RANGE_STOP_TARGET_AND_SIGNAL_AGREEMENT",
        ),
        diagnostics=diagnostics,
    )


classify_sma_offset = classify_symbol


def route_universe(
    bars_by_symbol: Mapping[str, Sequence[BarObservation]],
    features_by_symbol: Mapping[str, FeatureObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[RouteDecision | None, dict[str, RouteDecision]]:
    decisions = {
        symbol: classify_symbol(
            symbol,
            bars,
            features_by_symbol.get(
                symbol,
                FeatureObservation(
                    bars[-1].ts_event if bars else 0,
                    ready=False,
                ),
            ),
            config,
        )
        for symbol, bars in bars_by_symbol.items()
    }
    actionable = [decision for decision in decisions.values() if decision.actionable]
    actionable.sort(
        key=lambda item: (
            -float(item.score),
            _SYMBOL_PRIORITY.get(item.symbol, 99),
        )
    )
    return (actionable[0] if actionable else None), decisions


def sma_offset_exit_ready(
    bars: Sequence[BarObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[bool, dict[str, float | int | str]]:
    del bars, config
    return False, {"reason": "SMALLFISH_MANAGEMENT_OWNED_BY_STRATEGY"}


__all__ = [
    "BarObservation",
    "FeatureObservation",
    "RouteConfig",
    "RouteDecision",
    "SMALLFISH_STATE",
    "SMA_OFFSET_STATE",
    "UNRESOLVED",
    "classify_symbol",
    "classify_sma_offset",
    "route_universe",
    "sma_offset_exit_ready",
]
