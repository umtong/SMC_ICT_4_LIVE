
"""Causal adapter for the public Winner15m futures strategy.

The source is a dual-direction 15-minute trend/impulse policy:
EMA(10)/EMA(30), MACD(12,26,9), ROC(3), ADX(14), and current volume
relative to SMA(20). Only completed candles are used, and each contiguous
condition is one independent causal episode.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Mapping, Sequence

WINNER_STATE = "PUBLIC_WINNER15M_TREND_IMPULSE"
SMA_OFFSET_STATE = WINNER_STATE
UNRESOLVED = "UNRESOLVED"
_EPS = 1e-12
_SYMBOL_PRIORITY = {"BTCUSDT": 0, "ETHUSDT": 1, "SOLUSDT": 2, "XRPUSDT": 3}


@dataclass(frozen=True, slots=True)
class BarObservation:
    ts_event: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True, slots=True)
class FeatureObservation:
    observed_time_ns: int
    ready: bool = True
    flow_open_10s: float = math.nan
    notional_open_10s_burst: float = math.nan
    flow_60s: float = math.nan
    efficiency_60s: float = math.nan
    oi_change_15m: float = math.nan
    premium_z: float = math.nan


@dataclass(frozen=True, slots=True)
class RouteConfig:
    atr_period: int = 30
    min_impulse_atr_continuation: float = 0.20
    min_impulse_atr_reversal: float = 1.05
    min_response_atr: float = 0.08
    min_participation_ratio: float = 0.85
    min_route_score: float = 3.20
    ambiguity_score_gap: float = 0.10
    continuation_target_r: float = 2.00
    reversal_target_r: float = 1.65

    bucket_minutes: int = 15
    winner_fast_ema_period: int = 10
    winner_slow_ema_period: int = 30
    winner_macd_fast: int = 12
    winner_macd_slow: int = 26
    winner_macd_signal: int = 9
    winner_roc_period: int = 3
    winner_adx_period: int = 14
    winner_volume_period: int = 20
    winner_roc_threshold: float = 0.10
    winner_adx_threshold: float = 18.0
    winner_volume_ratio_threshold: float = 1.0
    winner_allow_long: bool = True
    winner_allow_short: bool = True
    winner_source_leverage: float = 1.0
    winner_source_stoploss: float = 0.025
    winner_trailing_positive: float = 0.005
    winner_trailing_offset: float = 0.018
    winner_emergency_target_fraction: float = 0.12

    sma_offset_period: int = 8
    sma_offset_low: float = 0.960
    sma_offset_high: float = 1.012
    sma_trend_fast: int = 20
    sma_trend_slow: int = 25
    sma_stop_min_fraction: float = 0.0075
    sma_stop_max_fraction: float = 0.1000
    sma_stop_atr_buffer: float = 0.50
    sma_structural_lookback: int = 6
    sma_min_reward_r: float = 1.00


@dataclass(frozen=True, slots=True)
class RouteDecision:
    symbol: str
    state: str
    side: int
    score: float
    entry_reference: float
    stop_reference: float
    objective_reference: float
    episode_ts: int
    reasons: tuple[str, ...] = ()
    diagnostics: Mapping[str, float | int | str] = field(default_factory=dict)

    @property
    def actionable(self) -> bool:
        return self.side in (-1, 1) and self.state != UNRESOLVED


def _finite(value: float) -> bool:
    return math.isfinite(float(value))


def _aggregate_complete(
    bars: Sequence[BarObservation],
    bucket_minutes: int,
) -> list[BarObservation]:
    if bucket_minutes <= 0:
        raise ValueError("bucket_minutes must be positive")
    if not bars:
        return []
    minute_ns = 60_000_000_000
    phase = int(bars[-1].ts_event) % minute_ns
    grouped: dict[int, list[tuple[int, BarObservation]]] = {}
    for bar in bars:
        timestamp = int(bar.ts_event)
        if timestamp % minute_ns != phase:
            continue
        ordinal = (timestamp - phase) // minute_ns
        grouped.setdefault(ordinal // bucket_minutes, []).append((ordinal, bar))
    output: list[BarObservation] = []
    for unordered in grouped.values():
        indexed = sorted(unordered, key=lambda item: item[0])
        if len(indexed) != bucket_minutes:
            continue
        ordinals = [item[0] for item in indexed]
        if ordinals[0] % bucket_minutes != 0:
            continue
        if ordinals[-1] % bucket_minutes != bucket_minutes - 1:
            continue
        if any(ordinals[i] - ordinals[i - 1] != 1 for i in range(1, len(ordinals))):
            continue
        items = [item[1] for item in indexed]
        output.append(
            BarObservation(
                ts_event=int(items[-1].ts_event),
                open=float(items[0].open),
                high=max(float(item.high) for item in items),
                low=min(float(item.low) for item in items),
                close=float(items[-1].close),
                volume=sum(max(0.0, float(item.volume)) for item in items),
            )
        )
    output.sort(key=lambda item: item.ts_event)
    return output


def _sma(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0:
        return result
    running = 0.0
    for index, raw in enumerate(values):
        running += float(raw)
        if index >= period:
            running -= float(values[index - period])
        if index >= period - 1:
            result[index] = running / period
    return result


def _ema(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0 or len(values) < period:
        return result
    current = sum(float(value) for value in values[:period]) / period
    result[period - 1] = current
    alpha = 2.0 / (period + 1.0)
    for index in range(period, len(values)):
        current = alpha * float(values[index]) + (1.0 - alpha) * current
        result[index] = current
    return result


def _ema_finite(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0:
        return result
    finite = [index for index, value in enumerate(values) if _finite(value)]
    if len(finite) < period:
        return result
    start = finite[0]
    if finite[:period] != list(range(start, start + period)):
        return result
    end = start + period
    current = sum(float(values[i]) for i in range(start, end)) / period
    result[end - 1] = current
    alpha = 2.0 / (period + 1.0)
    for index in range(end, len(values)):
        raw = float(values[index])
        if not _finite(raw):
            continue
        current = alpha * raw + (1.0 - alpha) * current
        result[index] = current
    return result


def _macd(
    values: Sequence[float],
    fast: int,
    slow: int,
    signal: int,
) -> tuple[list[float], list[float]]:
    fast_ema = _ema(values, fast)
    slow_ema = _ema(values, slow)
    line = [
        a - b if _finite(a) and _finite(b) else math.nan
        for a, b in zip(fast_ema, slow_ema, strict=True)
    ]
    return line, _ema_finite(line, signal)


def _adx(
    candles: Sequence[BarObservation],
    period: int,
) -> list[float]:
    size = len(candles)
    result = [math.nan] * size
    if period <= 0 or size <= period * 2:
        return result
    tr = [0.0] * size
    plus_dm = [0.0] * size
    minus_dm = [0.0] * size
    for index in range(1, size):
        current = candles[index]
        previous = candles[index - 1]
        up = float(current.high) - float(previous.high)
        down = float(previous.low) - float(current.low)
        plus_dm[index] = up if up > down and up > 0.0 else 0.0
        minus_dm[index] = down if down > up and down > 0.0 else 0.0
        prior_close = float(previous.close)
        tr[index] = max(
            float(current.high) - float(current.low),
            abs(float(current.high) - prior_close),
            abs(float(current.low) - prior_close),
        )

    smoothed_tr = sum(tr[1 : period + 1])
    smoothed_plus = sum(plus_dm[1 : period + 1])
    smoothed_minus = sum(minus_dm[1 : period + 1])
    dx = [math.nan] * size
    for index in range(period, size):
        if index > period:
            smoothed_tr = smoothed_tr - smoothed_tr / period + tr[index]
            smoothed_plus = (
                smoothed_plus - smoothed_plus / period + plus_dm[index]
            )
            smoothed_minus = (
                smoothed_minus - smoothed_minus / period + minus_dm[index]
            )
        if smoothed_tr <= _EPS:
            continue
        plus_di = 100.0 * smoothed_plus / smoothed_tr
        minus_di = 100.0 * smoothed_minus / smoothed_tr
        denominator = plus_di + minus_di
        if denominator > _EPS:
            dx[index] = 100.0 * abs(plus_di - minus_di) / denominator
    seed_start = period
    seed_end = period * 2
    seed = [value for value in dx[seed_start:seed_end] if _finite(value)]
    if len(seed) < period:
        return result
    current_adx = sum(seed) / period
    result[seed_end - 1] = current_adx
    for index in range(seed_end, size):
        if not _finite(dx[index]):
            continue
        current_adx = (
            current_adx * (period - 1) + float(dx[index])
        ) / period
        result[index] = current_adx
    return result


def _series(
    bars: Sequence[BarObservation],
    config: RouteConfig,
) -> tuple[list[BarObservation], dict[str, list[float]]]:
    candles = _aggregate_complete(bars, config.bucket_minutes)
    closes = [float(candle.close) for candle in candles]
    volumes = [float(candle.volume) for candle in candles]
    macd, signal = _macd(
        closes,
        config.winner_macd_fast,
        config.winner_macd_slow,
        config.winner_macd_signal,
    )
    roc = [math.nan] * len(closes)
    for index in range(config.winner_roc_period, len(closes)):
        prior = closes[index - config.winner_roc_period]
        if abs(prior) > _EPS:
            roc[index] = (closes[index] / prior - 1.0) * 100.0
    volume_sma = _sma(volumes, config.winner_volume_period)
    volume_ratio = [
        volume / average
        if _finite(average) and average > _EPS
        else math.nan
        for volume, average in zip(volumes, volume_sma, strict=True)
    ]
    return candles, {
        "ema_fast": _ema(closes, config.winner_fast_ema_period),
        "ema_slow": _ema(closes, config.winner_slow_ema_period),
        "macd": macd,
        "macd_signal": signal,
        "roc": roc,
        "adx": _adx(candles, config.winner_adx_period),
        "volume_ratio": volume_ratio,
    }


def _conditions(
    candles: Sequence[BarObservation],
    indicators: Mapping[str, Sequence[float]],
    index: int,
    config: RouteConfig,
) -> tuple[bool, bool, dict[str, float | int | str]]:
    if index < 0 or index >= len(candles):
        return False, False, {}
    values = {
        "close": float(candles[index].close),
        "volume": float(candles[index].volume),
        "ema_fast": float(indicators["ema_fast"][index]),
        "ema_slow": float(indicators["ema_slow"][index]),
        "macd": float(indicators["macd"][index]),
        "macd_signal": float(indicators["macd_signal"][index]),
        "roc": float(indicators["roc"][index]),
        "adx": float(indicators["adx"][index]),
        "volume_ratio": float(indicators["volume_ratio"][index]),
    }
    if not all(_finite(value) for value in values.values()):
        return False, False, values
    long_ok = bool(
        config.winner_allow_long
        and values["ema_fast"] > values["ema_slow"]
        and values["macd"] > values["macd_signal"]
        and values["roc"] > config.winner_roc_threshold
        and values["adx"] > config.winner_adx_threshold
        and values["volume_ratio"] > config.winner_volume_ratio_threshold
        and values["volume"] > 0.0
    )
    short_ok = bool(
        config.winner_allow_short
        and values["ema_fast"] < values["ema_slow"]
        and values["macd"] < values["macd_signal"]
        and values["roc"] < -config.winner_roc_threshold
        and values["adx"] > config.winner_adx_threshold
        and values["volume_ratio"] > config.winner_volume_ratio_threshold
        and values["volume"] > 0.0
    )
    values["long_condition"] = int(long_ok)
    values["short_condition"] = int(short_ok)
    return long_ok, short_ok, values


def _episode_start(
    candles: Sequence[BarObservation],
    indicators: Mapping[str, Sequence[float]],
    side: int,
    config: RouteConfig,
) -> int:
    index = len(candles) - 1
    current = _conditions(candles, indicators, index, config)
    active = current[0] if side > 0 else current[1]
    if not active:
        return 0
    while index > 0:
        prior = _conditions(candles, indicators, index - 1, config)
        prior_active = prior[0] if side > 0 else prior[1]
        if not prior_active:
            break
        index -= 1
    return int(candles[index].ts_event)


def _unresolved(
    symbol: str,
    reason: str,
    episode_ts: int = 0,
    diagnostics: Mapping[str, float | int | str] | None = None,
) -> RouteDecision:
    return RouteDecision(
        symbol=symbol,
        state=UNRESOLVED,
        side=0,
        score=0.0,
        entry_reference=math.nan,
        stop_reference=math.nan,
        objective_reference=math.nan,
        episode_ts=int(episode_ts),
        reasons=(reason,),
        diagnostics=dict(diagnostics or {}),
    )


def classify_symbol(
    symbol: str,
    bars: Sequence[BarObservation],
    feature: FeatureObservation,
    config: RouteConfig = RouteConfig(),
) -> RouteDecision:
    if not bars:
        return _unresolved(symbol, "NO_MINUTE_BARS")
    latest_ts = int(bars[-1].ts_event)
    if int(feature.observed_time_ns) > latest_ts:
        return _unresolved(symbol, "FUTURE_FEATURE_REJECTED", latest_ts)
    candles, indicators = _series(bars, config)
    minimum = max(
        config.winner_slow_ema_period + config.winner_macd_signal + 3,
        config.winner_adx_period * 2 + 3,
        config.winner_volume_period + 3,
    )
    if len(candles) < minimum:
        return _unresolved(
            symbol,
            "WINNER_HISTORY_NOT_READY",
            latest_ts,
            {"fifteen_minute_candles": len(candles), "minimum": minimum},
        )
    index = len(candles) - 1
    long_ok, short_ok, diagnostics = _conditions(
        candles,
        indicators,
        index,
        config,
    )
    if long_ok == short_ok:
        reason = (
            "WINNER_NO_SOURCE_ENTRY"
            if not long_ok
            else "WINNER_CONFLICTING_SOURCE_ENTRY"
        )
        return _unresolved(
            symbol,
            reason,
            int(candles[index].ts_event),
            diagnostics,
        )

    side = 1 if long_ok else -1
    entry = float(candles[index].close)
    leverage = max(config.winner_source_leverage, _EPS)
    stop_fraction = config.winner_source_stoploss / leverage
    if side > 0:
        stop = entry * (1.0 - stop_fraction)
        objective = entry * (1.0 + config.winner_emergency_target_fraction)
        score = (
            max(0.0, float(diagnostics["roc"]) - config.winner_roc_threshold)
            + max(0.0, float(diagnostics["adx"]) - config.winner_adx_threshold)
            / 10.0
            + max(
                0.0,
                float(diagnostics["volume_ratio"])
                - config.winner_volume_ratio_threshold,
            )
            + max(
                0.0,
                float(diagnostics["ema_fast"])
                / max(float(diagnostics["ema_slow"]), _EPS)
                - 1.0,
            )
            * 100.0
        )
        tag = "L"
    else:
        stop = entry * (1.0 + stop_fraction)
        objective = entry * (1.0 - config.winner_emergency_target_fraction)
        score = (
            max(0.0, -float(diagnostics["roc"]) - config.winner_roc_threshold)
            + max(0.0, float(diagnostics["adx"]) - config.winner_adx_threshold)
            / 10.0
            + max(
                0.0,
                float(diagnostics["volume_ratio"])
                - config.winner_volume_ratio_threshold,
            )
            + max(
                0.0,
                1.0
                - float(diagnostics["ema_fast"])
                / max(float(diagnostics["ema_slow"]), _EPS),
            )
            * 100.0
        )
        tag = "S"
    episode_ts = _episode_start(candles, indicators, side, config)
    diagnostics.update(
        {
            "source_tag": tag,
            "source_leverage": leverage,
            "source_stoploss_profit_ratio": config.winner_source_stoploss,
            "underlying_stop_fraction": stop_fraction,
            "source_trailing_positive": config.winner_trailing_positive,
            "source_trailing_offset": config.winner_trailing_offset,
            "episode_start": episode_ts,
        }
    )
    return RouteDecision(
        symbol=symbol,
        state=WINNER_STATE,
        side=side,
        score=float(score),
        entry_reference=entry,
        stop_reference=stop,
        objective_reference=objective,
        episode_ts=episode_ts,
        reasons=(
            "PUBLIC_WINNER15M_EMA_MACD_ROC_ADX_VOLUME_ENTRY",
            "ONE_CONTIGUOUS_SOURCE_CONDITION_ONE_EPISODE",
        ),
        diagnostics=diagnostics,
    )


classify_sma_offset = classify_symbol


def route_universe(
    bars_by_symbol: Mapping[str, Sequence[BarObservation]],
    features_by_symbol: Mapping[str, FeatureObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[RouteDecision | None, dict[str, RouteDecision]]:
    decisions = {
        symbol: classify_symbol(
            symbol,
            bars,
            features_by_symbol.get(
                symbol,
                FeatureObservation(
                    bars[-1].ts_event if bars else 0,
                    ready=True,
                ),
            ),
            config,
        )
        for symbol, bars in bars_by_symbol.items()
    }
    actionable = [decision for decision in decisions.values() if decision.actionable]
    actionable.sort(
        key=lambda item: (
            -float(item.score),
            _SYMBOL_PRIORITY.get(item.symbol, 99),
            item.symbol,
        )
    )
    return (actionable[0] if actionable else None), decisions


def sma_offset_exit_ready(
    bars: Sequence[BarObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[bool, dict[str, float | int | str]]:
    del bars, config
    return False, {
        "source_exit": 0,
        "reason": "WINNER15M_USES_ROI_TRAILING_AND_STOP_ONLY",
    }


__all__ = [
    "BarObservation",
    "FeatureObservation",
    "RouteConfig",
    "RouteDecision",
    "WINNER_STATE",
    "SMA_OFFSET_STATE",
    "UNRESOLVED",
    "classify_symbol",
    "classify_sma_offset",
    "route_universe",
    "sma_offset_exit_ready",
]
