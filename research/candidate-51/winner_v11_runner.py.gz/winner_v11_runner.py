
#!/usr/bin/env python3
"""Run, select and persist the Candidate 51 public Winner15m family."""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
BASE_CONFIG = ROOT / "config.json"
WORK = REPO / ".work" / "candidate-51-winner-v11"
CACHE = REPO / ".cache" / "candidate-51-winner-v11"
ARTIFACTS = REPO / "artifacts" / "candidate-51"
EVIDENCE = ROOT / "evidence" / "v11-winner15m"
DEVELOPMENT = ("2026-07-22", "2026-07-28")
HOLDOUT = ("2026-07-29", "2026-08-04")

VARIANTS: dict[str, dict[str, Any]] = {
    "source_exact": {
        "winner_roc_threshold": 0.10,
        "winner_adx_threshold": 18.0,
        "winner_volume_ratio_threshold": 1.0,
        "winner_allow_long": True,
        "winner_allow_short": True,
    },
    "source_long_only": {
        "winner_roc_threshold": 0.10,
        "winner_adx_threshold": 18.0,
        "winner_volume_ratio_threshold": 1.0,
        "winner_allow_long": True,
        "winner_allow_short": False,
    },
    "source_short_only": {
        "winner_roc_threshold": 0.10,
        "winner_adx_threshold": 18.0,
        "winner_volume_ratio_threshold": 1.0,
        "winner_allow_long": False,
        "winner_allow_short": True,
    },
    "dense_impulse": {
        "winner_roc_threshold": 0.05,
        "winner_adx_threshold": 15.0,
        "winner_volume_ratio_threshold": 0.85,
        "winner_allow_long": True,
        "winner_allow_short": True,
    },
    "strict_impulse": {
        "winner_roc_threshold": 0.20,
        "winner_adx_threshold": 22.0,
        "winner_volume_ratio_threshold": 1.20,
        "winner_allow_long": True,
        "winner_allow_short": True,
    },
}


def dump(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def run_launch(name: str, config: Path, start: str, end: str, suffix: str) -> int:
    output = ARTIFACTS / f"winner-v11-{name}-{suffix}"
    workspace = REPO / ".work" / f"candidate-51-winner-v11-{name}-{suffix}"
    command = [
        sys.executable,
        str(ROOT / "launch.py"),
        "--config",
        str(config),
        "--start",
        start,
        "--end",
        end,
        "--cache",
        str(CACHE),
        "--output",
        str(output),
        "--workspace",
        str(workspace),
    ]
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(ROOT)
    completed = subprocess.run(command, cwd=REPO, env=environment, check=False)
    return int(completed.returncode)


def result_row(root: Path) -> dict[str, Any]:
    metrics_path = root / "metrics.json"
    diagnostics_path = root / "strategy_diagnostics.json"
    if not metrics_path.is_file() or not diagnostics_path.is_file():
        return {"produced": False}
    metrics = json.loads(metrics_path.read_text())
    diagnostics = json.loads(diagnostics_path.read_text())
    return {
        "produced": True,
        "ending_nav": metrics.get("ending_nav"),
        "total_return": metrics.get("total_return"),
        "geometric_daily_growth": metrics.get("geometric_daily_growth"),
        "max_drawdown": metrics.get("max_drawdown"),
        "trades": metrics.get("trades"),
        "wins": metrics.get("wins"),
        "losses": metrics.get("losses"),
        "win_rate": metrics.get("win_rate"),
        "profit_factor": metrics.get("profit_factor"),
        "expectancy_usdt": metrics.get("expectancy_usdt"),
        "largest_winner_share": metrics.get("largest_winner_share"),
        "source_signals": diagnostics.get("source_signals_before_execution_filters"),
        "entries": diagnostics.get("entry_submissions"),
        "roi_exits": diagnostics.get("winner_roi_exits"),
        "trailing_activations": diagnostics.get("winner_trailing_activations"),
        "trailing_exits": diagnostics.get("winner_trailing_exits"),
        "used_episode_rejections": diagnostics.get("used_episode_rejections"),
        "selected_symbols": diagnostics.get("selected_symbols"),
        "route_counts": diagnostics.get("route_counts"),
        "unresolved_reason_counts": diagnostics.get("unresolved_reason_counts"),
        "global_position_violations": diagnostics.get("global_position_violations"),
        "order_rejections": diagnostics.get("order_rejections"),
    }


def eligible(row: dict[str, Any], calendar_days: int) -> bool:
    return bool(
        row.get("produced")
        and int(row.get("trades") or 0) >= calendar_days
        and float(row.get("expectancy_usdt") or 0.0) > 0.0
        and float(row.get("geometric_daily_growth") or 0.0) > 0.0
        and float(row.get("max_drawdown") or 1.0) <= 0.20
        and int(row.get("global_position_violations") or 0) == 0
        and int(row.get("order_rejections") or 0) == 0
    )


def copy_compact(source: Path, target: Path) -> None:
    if not source.is_dir():
        return
    target.mkdir(parents=True, exist_ok=True)
    for filename in (
        "metrics.json",
        "strategy_diagnostics.json",
        "run.json",
        "data_manifest.json",
        "closed_scenarios.json",
    ):
        path = source / filename
        if path.is_file():
            shutil.copy2(path, target / filename)


def main() -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    source = json.loads(BASE_CONFIG.read_text())
    legacy = {
        "sma_offset_low",
        "sma_offset_high",
        "sma_stop_min_fraction",
        "sma_stop_max_fraction",
        "sma_stop_atr_buffer",
    }
    common = {
        "cooldown_minutes": 0,
        "max_hold_minutes": 720,
        "funding_flatten_minute": 60,
        "funding_blackout_before_minutes": -1,
        "funding_blackout_after_minutes": -1,
        "winner_fast_ema_period": 10,
        "winner_slow_ema_period": 30,
        "winner_macd_fast": 12,
        "winner_macd_slow": 26,
        "winner_macd_signal": 9,
        "winner_roc_period": 3,
        "winner_adx_period": 14,
        "winner_volume_period": 20,
        "winner_source_leverage": 1.0,
        "winner_source_stoploss": 0.025,
        "winner_trailing_positive": 0.005,
        "winner_trailing_offset": 0.018,
        "winner_emergency_target_fraction": 0.12,
        "winner_roi_0": 0.08,
        "winner_roi_480": 0.05,
        "winner_roi_1440": 0.03,
        "winner_roi_4320": 0.0,
    }
    manifest = {
        "family": "public_Winner15m_EMA_MACD_ROC_ADX_volume",
        "source": {
            "repository": "win-boom/BTCquant",
            "path": "user_data/strategies/winner_strat.py",
            "claimed_league_trades": 86943,
            "claimed_win_rate": 0.615,
            "claimed_cagr": 0.682,
            "claimed_profit_factor": 1.15,
            "claimed_average_duration_minutes": 279,
            "source_stoploss": -0.025,
            "source_trailing_positive": 0.005,
            "source_trailing_offset": 0.018,
            "source_statement": (
                "27.6% annual, Sharpe 3.23, 65.8% win rate, "
                "all 6 sliding windows profitable"
            ),
        },
        "development_interval": list(DEVELOPMENT),
        "untouched_interval": list(HOLDOUT),
        "variants": VARIANTS,
        "selection_rule": (
            "at least one independent completed trade per calendar day, "
            "positive post-cost expectancy and geometric growth, "
            "max drawdown <=20%, no one-slot or order integrity violation"
        ),
        "final_project_gate": (
            "holdout geometric daily growth >=1%, at least one independent "
            "completed trade per calendar day, positive expectancy, max drawdown <=20%"
        ),
        "router_sha256": hashlib.sha256((ROOT / "router.py").read_bytes()).hexdigest(),
        "strategy_sha256": hashlib.sha256((ROOT / "strategy.py").read_bytes()).hexdigest(),
    }
    dump(WORK / "variant_manifest.json", manifest)

    configs: dict[str, Path] = {}
    statuses: dict[str, int] = {}
    for name, values in VARIANTS.items():
        config = copy.deepcopy(source)
        for key in legacy:
            config["strategy"].pop(key, None)
        config["strategy"].update(common)
        config["strategy"].update(values)
        config_path = WORK / f"{name}.json"
        dump(config_path, config)
        configs[name] = config_path
        statuses[name] = run_launch(
            name,
            config_path,
            DEVELOPMENT[0],
            DEVELOPMENT[1],
            "development",
        )

    comparison = {
        name: result_row(ARTIFACTS / f"winner-v11-{name}-development")
        for name in VARIANTS
    }
    qualified = [
        name for name, row in comparison.items() if eligible(row, 7)
    ]
    qualified.sort(
        key=lambda name: (
            -float(comparison[name].get("geometric_daily_growth") or 0.0),
            -float(comparison[name].get("expectancy_usdt") or 0.0),
            -int(comparison[name].get("trades") or 0),
            name,
        )
    )
    selected = qualified[0] if qualified else None
    development_decision = {
        "statuses": statuses,
        "comparison": comparison,
        "eligible": qualified,
        "selected": selected,
        "family_status": "TEST_UNTOUCHED" if selected else "REJECT_OR_REDESIGN",
    }
    dump(
        ARTIFACTS / "winner-v11-development-comparison.json",
        development_decision,
    )

    holdout_assessment: dict[str, Any] = {
        "variant": selected,
        "produced": False,
        "validation_gate_pass": False,
        "project_target_pass": False,
    }
    if selected is not None:
        holdout_status = run_launch(
            selected,
            configs[selected],
            HOLDOUT[0],
            HOLDOUT[1],
            "holdout",
        )
        row = result_row(ARTIFACTS / f"winner-v11-{selected}-holdout")
        checks = {
            "independent_trades_at_least_calendar_days": int(row.get("trades") or 0) >= 7,
            "positive_post_cost_growth": float(row.get("geometric_daily_growth") or 0.0) > 0.0,
            "positive_expectancy": float(row.get("expectancy_usdt") or 0.0) > 0.0,
            "max_drawdown_lte_20pct": float(row.get("max_drawdown") or 1.0) <= 0.20,
            "no_global_position_violation": int(row.get("global_position_violations") or 0) == 0,
            "no_order_rejection": int(row.get("order_rejections") or 0) == 0,
        }
        project_checks = {
            **checks,
            "daily_geometric_growth_at_least_1pct": (
                float(row.get("geometric_daily_growth") or 0.0) >= 0.01
            ),
        }
        holdout_assessment = {
            "variant": selected,
            "status": holdout_status,
            **row,
            "checks": checks,
            "project_checks": project_checks,
            "validation_gate_pass": all(checks.values()),
            "project_target_pass": all(project_checks.values()),
        }
    dump(
        ARTIFACTS / "winner-v11-holdout-assessment.json",
        holdout_assessment,
    )

    if EVIDENCE.exists():
        shutil.rmtree(EVIDENCE)
    (EVIDENCE / "development").mkdir(parents=True, exist_ok=True)
    (EVIDENCE / "holdout").mkdir(parents=True, exist_ok=True)
    shutil.copy2(WORK / "variant_manifest.json", EVIDENCE / "variant_manifest.json")
    shutil.copy2(
        ARTIFACTS / "winner-v11-development-comparison.json",
        EVIDENCE / "development" / "comparison.json",
    )
    shutil.copy2(
        ARTIFACTS / "winner-v11-holdout-assessment.json",
        EVIDENCE / "holdout" / "assessment.json",
    )
    for name in VARIANTS:
        copy_compact(
            ARTIFACTS / f"winner-v11-{name}-development",
            EVIDENCE / "development" / name,
        )
    if selected is not None:
        copy_compact(
            ARTIFACTS / f"winner-v11-{selected}-holdout",
            EVIDENCE / "holdout",
        )
    print(json.dumps(
        {
            "development": development_decision,
            "holdout": holdout_assessment,
        },
        indent=2,
        sort_keys=True,
    ))


if __name__ == "__main__":
    main()
