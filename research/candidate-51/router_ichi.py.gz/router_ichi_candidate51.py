"""Candidate 51 adapter for the public ichiV1/ichiV2 Freqtrade family.

The public policy is reused at decision level: a 5-minute Ichimoku cloud,
Heikin-Ashi open trend ribbon, EMA fan acceleration, staged ROI, and an EMA
cross exit.  The exact long-only source is available, plus an explicitly
predeclared symmetric futures adaptation.  Continuous source conditions are
one causal episode, so repeated bars cannot inflate the independent trade
count.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Mapping, Sequence

ICHI_STATE = "PUBLIC_ICHI_V1_FAN_CLOUD_TREND"
SMA_OFFSET_STATE = ICHI_STATE  # compatibility with the reused execution shell
UNRESOLVED = "UNRESOLVED"
_EPS = 1e-12
_SYMBOL_PRIORITY = {"BTCUSDT": 0, "ETHUSDT": 1, "SOLUSDT": 2, "XRPUSDT": 3}


@dataclass(frozen=True, slots=True)
class BarObservation:
    ts_event: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True, slots=True)
class FeatureObservation:
    observed_time_ns: int
    ready: bool = True
    flow_open_10s: float = math.nan
    notional_open_10s_burst: float = math.nan
    flow_60s: float = math.nan
    efficiency_60s: float = math.nan
    oi_change_15m: float = math.nan
    premium_z: float = math.nan


@dataclass(frozen=True, slots=True)
class RouteConfig:
    # Compatibility fields consumed by strategy_base.Candidate35Strategy.
    atr_period: int = 30
    min_impulse_atr_continuation: float = 0.20
    min_impulse_atr_reversal: float = 1.05
    min_response_atr: float = 0.08
    min_participation_ratio: float = 0.85
    min_route_score: float = 3.20
    ambiguity_score_gap: float = 0.10
    continuation_target_r: float = 2.00
    reversal_target_r: float = 1.65

    bucket_minutes: int = 5
    ichi_conversion_period: int = 20
    ichi_base_period: int = 60
    ichi_span_period: int = 120
    ichi_displacement: int = 30
    ichi_above_cloud_level: int = 1
    ichi_bullish_level: int = 6
    ichi_fan_shift: int = 3
    ichi_min_fan_gain: float = 1.002
    ichi_exit_ema_period: int = 24
    ichi_allow_short: bool = False
    ichi_use_source_emergency_stop: bool = False
    ichi_source_stoploss: float = 0.275
    ichi_stop_atr_buffer: float = 0.20
    ichi_emergency_target_fraction: float = 0.10

    # Legacy adapter fields accepted by shared configuration code.
    sma_offset_period: int = 8
    sma_offset_low: float = 0.960
    sma_offset_high: float = 1.012
    sma_trend_fast: int = 20
    sma_trend_slow: int = 25
    sma_stop_min_fraction: float = 0.0075
    sma_stop_max_fraction: float = 0.1000
    sma_stop_atr_buffer: float = 0.50
    sma_structural_lookback: int = 6
    sma_min_reward_r: float = 1.00


@dataclass(frozen=True, slots=True)
class RouteDecision:
    symbol: str
    state: str
    side: int
    score: float
    entry_reference: float
    stop_reference: float
    objective_reference: float
    episode_ts: int
    reasons: tuple[str, ...] = ()
    diagnostics: Mapping[str, float | int | str] = field(default_factory=dict)

    @property
    def actionable(self) -> bool:
        return self.side in (-1, 1) and self.state != UNRESOLVED


def _finite(value: float) -> bool:
    return math.isfinite(float(value))


def _aggregate_complete(
    bars: Sequence[BarObservation],
    bucket_minutes: int,
) -> list[BarObservation]:
    if bucket_minutes <= 0:
        raise ValueError("bucket_minutes must be positive")
    if not bars:
        return []
    minute_ns = 60_000_000_000
    phase = int(bars[-1].ts_event) % minute_ns
    grouped: dict[int, list[tuple[int, BarObservation]]] = {}
    for bar in bars:
        timestamp = int(bar.ts_event)
        if timestamp % minute_ns != phase:
            continue
        ordinal = (timestamp - phase) // minute_ns
        grouped.setdefault(ordinal // bucket_minutes, []).append((ordinal, bar))
    output: list[BarObservation] = []
    for unordered in grouped.values():
        indexed = sorted(unordered, key=lambda item: item[0])
        if len(indexed) != bucket_minutes:
            continue
        ordinals = [item[0] for item in indexed]
        if ordinals[0] % bucket_minutes != 0:
            continue
        if ordinals[-1] % bucket_minutes != bucket_minutes - 1:
            continue
        if any(ordinals[i] - ordinals[i - 1] != 1 for i in range(1, len(ordinals))):
            continue
        items = [item[1] for item in indexed]
        output.append(
            BarObservation(
                ts_event=int(items[-1].ts_event),
                open=float(items[0].open),
                high=max(float(item.high) for item in items),
                low=min(float(item.low) for item in items),
                close=float(items[-1].close),
                volume=sum(max(0.0, float(item.volume)) for item in items),
            ),
        )
    output.sort(key=lambda item: item.ts_event)
    return output


def _ema(values: Sequence[float], period: int) -> list[float]:
    result = [math.nan] * len(values)
    if period <= 0 or len(values) < period:
        return result
    current = sum(float(value) for value in values[:period]) / period
    result[period - 1] = current
    alpha = 2.0 / (period + 1.0)
    for index in range(period, len(values)):
        current = alpha * float(values[index]) + (1.0 - alpha) * current
        result[index] = current
    return result


def _heikin_ashi(candles: Sequence[BarObservation]) -> tuple[list[float], list[float], list[float]]:
    opens: list[float] = []
    highs: list[float] = []
    lows: list[float] = []
    previous_open = math.nan
    previous_close = math.nan
    for index, candle in enumerate(candles):
        raw_open = float(candle.open)
        raw_high = float(candle.high)
        raw_low = float(candle.low)
        raw_close = float(candle.close)
        ha_close = (raw_open + raw_high + raw_low + raw_close) / 4.0
        ha_open = (
            (raw_open + raw_close) / 2.0
            if index == 0
            else (previous_open + previous_close) / 2.0
        )
        opens.append(ha_open)
        highs.append(max(raw_high, ha_open, ha_close))
        lows.append(min(raw_low, ha_open, ha_close))
        previous_open = ha_open
        previous_close = ha_close
    return opens, highs, lows


def _rolling_mid(highs: Sequence[float], lows: Sequence[float], period: int) -> list[float]:
    output = [math.nan] * len(highs)
    if period <= 0:
        return output
    for index in range(period - 1, len(highs)):
        output[index] = (
            max(float(value) for value in highs[index - period + 1 : index + 1])
            + min(float(value) for value in lows[index - period + 1 : index + 1])
        ) / 2.0
    return output


def _atr(candles: Sequence[BarObservation], period: int) -> list[float]:
    output = [math.nan] * len(candles)
    if period <= 0 or len(candles) <= period:
        return output
    true_ranges = [0.0] * len(candles)
    true_ranges[0] = float(candles[0].high) - float(candles[0].low)
    for index in range(1, len(candles)):
        previous_close = float(candles[index - 1].close)
        true_ranges[index] = max(
            float(candles[index].high) - float(candles[index].low),
            abs(float(candles[index].high) - previous_close),
            abs(float(candles[index].low) - previous_close),
        )
    current = sum(true_ranges[1 : period + 1]) / period
    output[period] = current
    for index in range(period + 1, len(candles)):
        current = (current * (period - 1) + true_ranges[index]) / period
        output[index] = current
    return output


def _state(candles: Sequence[BarObservation], config: RouteConfig) -> dict[str, list[float]]:
    closes = [float(candle.close) for candle in candles]
    ha_open, ha_high, ha_low = _heikin_ashi(candles)
    periods = (1, 3, 6, 12, 24, 48, 72, 96)
    close_trends = {
        period: (closes[:] if period == 1 else _ema(closes, period))
        for period in periods
    }
    open_trends = {
        period: (ha_open[:] if period == 1 else _ema(ha_open, period))
        for period in periods
    }
    tenkan = _rolling_mid(ha_high, ha_low, config.ichi_conversion_period)
    kijun = _rolling_mid(ha_high, ha_low, config.ichi_base_period)
    leading_a = [
        (a + b) / 2.0 if _finite(a) and _finite(b) else math.nan
        for a, b in zip(tenkan, kijun, strict=True)
    ]
    leading_b = _rolling_mid(ha_high, ha_low, config.ichi_span_period)
    shift = max(0, config.ichi_displacement - 1)
    span_a = [math.nan] * len(candles)
    span_b = [math.nan] * len(candles)
    for index in range(shift, len(candles)):
        span_a[index] = leading_a[index - shift]
        span_b[index] = leading_b[index - shift]
    fan = [
        fast / slow if _finite(fast) and _finite(slow) and abs(slow) > _EPS else math.nan
        for fast, slow in zip(close_trends[12], close_trends[96], strict=True)
    ]
    fan_gain = [math.nan] * len(candles)
    for index in range(1, len(candles)):
        if _finite(fan[index]) and _finite(fan[index - 1]) and abs(fan[index - 1]) > _EPS:
            fan_gain[index] = fan[index] / fan[index - 1]
    result: dict[str, list[float]] = {
        "close": closes,
        "span_a": span_a,
        "span_b": span_b,
        "fan": fan,
        "fan_gain": fan_gain,
        "atr": _atr(candles, max(2, config.atr_period)),
    }
    for period in periods:
        result[f"close_{period}"] = close_trends[period]
        result[f"open_{period}"] = open_trends[period]
    return result


def _signal_at(
    state: Mapping[str, Sequence[float]],
    index: int,
    side: int,
    config: RouteConfig,
) -> bool:
    if index < max(1, config.ichi_fan_shift):
        return False
    close = float(state["close"][index])
    span_a = float(state["span_a"][index])
    span_b = float(state["span_b"][index])
    fan = float(state["fan"][index])
    fan_gain = float(state["fan_gain"][index])
    required = (close, span_a, span_b, fan, fan_gain)
    if not all(_finite(value) for value in required):
        return False

    cloud_periods = (1, 3, 6, 12, 24, 48, 72, 96)
    above_level = max(1, min(config.ichi_above_cloud_level, len(cloud_periods)))
    bullish_level = max(1, min(config.ichi_bullish_level, len(cloud_periods)))
    selected_cloud = cloud_periods[:above_level]
    selected_trend = cloud_periods[:bullish_level]
    if side > 0:
        cloud_ok = all(
            float(state[f"close_{period}"][index]) > span_a
            and float(state[f"close_{period}"][index]) > span_b
            for period in selected_cloud
        )
        trend_ok = all(
            _finite(state[f"close_{period}"][index])
            and _finite(state[f"open_{period}"][index])
            and float(state[f"close_{period}"][index]) > float(state[f"open_{period}"][index])
            for period in selected_trend
        )
        fan_ok = fan > 1.0 and fan_gain >= config.ichi_min_fan_gain
        acceleration = all(
            _finite(state["fan"][index - shift])
            and fan > float(state["fan"][index - shift])
            for shift in range(1, config.ichi_fan_shift + 1)
        )
        return cloud_ok and trend_ok and fan_ok and acceleration

    if not config.ichi_allow_short:
        return False
    cloud_ok = all(
        float(state[f"close_{period}"][index]) < span_a
        and float(state[f"close_{period}"][index]) < span_b
        for period in selected_cloud
    )
    trend_ok = all(
        _finite(state[f"close_{period}"][index])
        and _finite(state[f"open_{period}"][index])
        and float(state[f"close_{period}"][index]) < float(state[f"open_{period}"][index])
        for period in selected_trend
    )
    reciprocal = 1.0 / max(fan, _EPS)
    previous_fan = float(state["fan"][index - 1])
    reciprocal_gain = (
        previous_fan / fan
        if _finite(previous_fan) and fan > _EPS
        else math.nan
    )
    fan_ok = fan < 1.0 and _finite(reciprocal_gain) and reciprocal_gain >= config.ichi_min_fan_gain
    acceleration = all(
        _finite(state["fan"][index - shift])
        and reciprocal > 1.0 / max(float(state["fan"][index - shift]), _EPS)
        for shift in range(1, config.ichi_fan_shift + 1)
    )
    return cloud_ok and trend_ok and fan_ok and acceleration


def _episode_start(
    candles: Sequence[BarObservation],
    state: Mapping[str, Sequence[float]],
    side: int,
    config: RouteConfig,
) -> int:
    index = len(candles) - 1
    if not _signal_at(state, index, side, config):
        return 0
    while index > 0 and _signal_at(state, index - 1, side, config):
        index -= 1
    return int(candles[index].ts_event)


def _unresolved(
    symbol: str,
    reason: str,
    episode_ts: int = 0,
    diagnostics: Mapping[str, float | int | str] | None = None,
) -> RouteDecision:
    return RouteDecision(
        symbol=symbol,
        state=UNRESOLVED,
        side=0,
        score=0.0,
        entry_reference=math.nan,
        stop_reference=math.nan,
        objective_reference=math.nan,
        episode_ts=int(episode_ts),
        reasons=(reason,),
        diagnostics=dict(diagnostics or {}),
    )


def classify_symbol(
    symbol: str,
    bars: Sequence[BarObservation],
    feature: FeatureObservation,
    config: RouteConfig = RouteConfig(),
) -> RouteDecision:
    if not bars:
        return _unresolved(symbol, "NO_MINUTE_BARS")
    latest_ts = int(bars[-1].ts_event)
    if int(feature.observed_time_ns) > latest_ts:
        return _unresolved(symbol, "FUTURE_FEATURE_REJECTED", latest_ts)
    candles = _aggregate_complete(bars, config.bucket_minutes)
    minimum = max(
        100,
        config.ichi_span_period + config.ichi_displacement,
        config.atr_period + 2,
    )
    if len(candles) < minimum:
        return _unresolved(
            symbol,
            "ICHI_HISTORY_NOT_READY",
            latest_ts,
            {"five_minute_candles": len(candles), "minimum": minimum},
        )
    state = _state(candles, config)
    index = len(candles) - 1
    long_ok = _signal_at(state, index, 1, config)
    short_ok = _signal_at(state, index, -1, config)
    values: dict[str, float | int | str] = {
        "five_minute_candles": len(candles),
        "close": float(state["close"][index]),
        "span_a": float(state["span_a"][index]),
        "span_b": float(state["span_b"][index]),
        "fan_magnitude": float(state["fan"][index]),
        "fan_magnitude_gain": float(state["fan_gain"][index]),
        "ema_exit": float(state[f"close_{config.ichi_exit_ema_period}"][index]),
        "atr": float(state["atr"][index]),
        "long_condition": int(long_ok),
        "short_condition": int(short_ok),
    }
    if long_ok == short_ok:
        reason = "ICHI_NO_SOURCE_ENTRY" if not long_ok else "ICHI_AMBIGUOUS_SOURCE_ENTRY"
        return _unresolved(symbol, reason, candles[index].ts_event, values)

    side = 1 if long_ok else -1
    entry = float(state["close"][index])
    atr = float(state["atr"][index])
    exit_ema = float(state[f"close_{config.ichi_exit_ema_period}"][index])
    if config.ichi_use_source_emergency_stop:
        stop = entry * (1.0 - side * config.ichi_source_stoploss)
        stop_mode = "source_emergency_27_5pct"
    else:
        stop = exit_ema - side * config.ichi_stop_atr_buffer * atr
        stop_mode = f"ema_{config.ichi_exit_ema_period}_invalidation"
    objective = entry * (1.0 + side * config.ichi_emergency_target_fraction)
    valid = stop < entry < objective if side > 0 else objective < entry < stop
    if not valid:
        values.update({"computed_stop": stop, "computed_objective": objective})
        return _unresolved(symbol, "ICHI_INVALID_RISK_GEOMETRY", candles[index].ts_event, values)

    fan = float(state["fan"][index])
    gain = float(state["fan_gain"][index])
    cloud_edge = max(float(state["span_a"][index]), float(state["span_b"][index])) if side > 0 else min(float(state["span_a"][index]), float(state["span_b"][index]))
    trend_distance = side * (entry - cloud_edge) / max(entry, _EPS)
    fan_strength = (fan - 1.0) if side > 0 else (1.0 / max(fan, _EPS) - 1.0)
    source_gain = gain if side > 0 else float(state["fan"][index - 1]) / max(fan, _EPS)
    score = 100.0 * max(0.0, trend_distance) + 100.0 * max(0.0, fan_strength) + 1_000.0 * max(0.0, source_gain - 1.0)
    episode_ts = _episode_start(candles, state, side, config)
    values.update({
        "source_tag": "ichi_long" if side > 0 else "ichi_short_symmetric",
        "stop_mode": stop_mode,
        "source_stoploss": config.ichi_source_stoploss,
        "source_fan_gain_threshold": config.ichi_min_fan_gain,
        "episode_start": episode_ts,
        "reward_r_at_emergency_target": abs(objective - entry) / max(abs(entry - stop), _EPS),
    })
    reasons = [
        "PUBLIC_ICHI_V1_CLOUD_HA_TREND_AND_FAN_ACCELERATION",
        "CONTINUOUS_SOURCE_CONDITION_IS_ONE_CAUSAL_EPISODE",
    ]
    if side < 0:
        reasons.append("PREDECLARED_SYMMETRIC_FUTURES_ADAPTATION")
    if not config.ichi_use_source_emergency_stop:
        reasons.append("SOURCE_EMA_EXIT_USED_AS_PLANNED_INVALIDATION")
    return RouteDecision(
        symbol=symbol,
        state=ICHI_STATE,
        side=side,
        score=float(score),
        entry_reference=entry,
        stop_reference=float(stop),
        objective_reference=float(objective),
        episode_ts=episode_ts,
        reasons=tuple(reasons),
        diagnostics=values,
    )


classify_sma_offset = classify_symbol


def route_universe(
    bars_by_symbol: Mapping[str, Sequence[BarObservation]],
    features_by_symbol: Mapping[str, FeatureObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[RouteDecision | None, dict[str, RouteDecision]]:
    decisions = {
        symbol: classify_symbol(
            symbol,
            bars,
            features_by_symbol.get(
                symbol,
                FeatureObservation(bars[-1].ts_event if bars else 0, ready=True),
            ),
            config,
        )
        for symbol, bars in bars_by_symbol.items()
    }
    actionable = [decision for decision in decisions.values() if decision.actionable]
    actionable.sort(
        key=lambda item: (
            -float(item.score),
            _SYMBOL_PRIORITY.get(item.symbol, 99),
            item.symbol,
        ),
    )
    return (actionable[0] if actionable else None), decisions


def ichi_exit_ready(
    bars: Sequence[BarObservation],
    side: int,
    config: RouteConfig = RouteConfig(),
) -> tuple[bool, dict[str, float | int | str]]:
    candles = _aggregate_complete(bars, config.bucket_minutes)
    period = config.ichi_exit_ema_period
    if len(candles) < period + 2 or side not in (-1, 1):
        return False, {"source_exit": 0, "reason": "ICHI_EXIT_HISTORY_NOT_READY"}
    closes = [float(candle.close) for candle in candles]
    ema = _ema(closes, period)
    previous = len(candles) - 2
    current = len(candles) - 1
    if not all(_finite(value) for value in (ema[previous], ema[current])):
        return False, {"source_exit": 0, "reason": "ICHI_EXIT_EMA_NOT_READY"}
    if side > 0:
        crossed = closes[previous] >= ema[previous] and closes[current] < ema[current]
    else:
        crossed = closes[previous] <= ema[previous] and closes[current] > ema[current]
    return crossed, {
        "source_exit": int(crossed),
        "side": side,
        "previous_close": closes[previous],
        "current_close": closes[current],
        "previous_ema": float(ema[previous]),
        "current_ema": float(ema[current]),
        "ema_period": period,
    }


def sma_offset_exit_ready(
    bars: Sequence[BarObservation],
    config: RouteConfig = RouteConfig(),
) -> tuple[bool, dict[str, float | int | str]]:
    del bars, config
    return False, {"source_exit": 0, "reason": "ICHI_SIDE_REQUIRED"}


__all__ = [
    "BarObservation", "FeatureObservation", "RouteConfig", "RouteDecision",
    "ICHI_STATE", "SMA_OFFSET_STATE", "UNRESOLVED", "classify_symbol",
    "classify_sma_offset", "route_universe", "ichi_exit_ready",
    "sma_offset_exit_ready",
]
