from __future__ import annotations

import unittest

from v20_impact_math import (
    ImpactDebitLedger,
    impact_adjusted_ledger,
    solve_risk_quantity,
)


class ImpactMathTests(unittest.TestCase):
    def test_fixed_point_respects_risk_budget(self) -> None:
        result = solve_risk_quantity(
            risk_budget=3000.0,
            entry=30000.0,
            stop=29800.0,
            taker_fee=0.0007,
            base_impact=10.0,
            atr=120.0,
            liquidity_notional=25_000_000.0,
        )
        self.assertIsNotNone(result)
        assert result is not None
        self.assertLessEqual(result.quantity * result.per_unit_loss, 3000.01)
        self.assertGreaterEqual(result.impact_per_side, 10.0)

    def test_larger_order_has_larger_impact(self) -> None:
        small = solve_risk_quantity(
            risk_budget=1000.0,
            entry=30000.0,
            stop=29800.0,
            taker_fee=0.0007,
            base_impact=1.0,
            atr=120.0,
            liquidity_notional=25_000_000.0,
        )
        large = solve_risk_quantity(
            risk_budget=5000.0,
            entry=30000.0,
            stop=29800.0,
            taker_fee=0.0007,
            base_impact=1.0,
            atr=120.0,
            liquidity_notional=25_000_000.0,
        )
        assert small is not None and large is not None
        self.assertGreater(large.impact_per_side, small.impact_per_side)

    def test_live_ledger_is_idempotent_and_depletes_next_nav(self) -> None:
        ledger = ImpactDebitLedger()
        first = ledger.debit(
            key="ENTRY:1",
            role="ENTRY",
            ts_ns=1,
            quantity=10.0,
            impact_per_unit=5.0,
        )
        duplicate = ledger.debit(
            key="ENTRY:1",
            role="ENTRY",
            ts_ns=1,
            quantity=10.0,
            impact_per_unit=5.0,
        )
        second = ledger.debit(
            key="EXIT:1",
            role="EXIT",
            ts_ns=2,
            quantity=10.0,
            impact_per_unit=7.0,
        )
        self.assertEqual(first, 50.0)
        self.assertEqual(duplicate, 0.0)
        self.assertEqual(second, 70.0)
        self.assertEqual(ledger.cumulative_debit, 120.0)
        self.assertEqual(ledger.adjusted_equity(100_000.0), 99_880.0)
        self.assertAlmostEqual(
            ledger.adjusted_equity(100_000.0) * 0.03,
            2_996.4,
        )

    def test_post_run_reconstruction_uses_open_and_close_times(self) -> None:
        result = impact_adjusted_ledger(
            starting_nav=100_000.0,
            ending_nav=101_000.0,
            daily_nav={"2023-01-01": 101_000.0},
            equity_curve=[
                {"ts_ns": 1, "equity": 100_000.0},
                {"ts_ns": 3, "equity": 101_000.0},
            ],
            trades=[
                {
                    "actual_entry_qty": 10.0,
                    "opened_ts_ns": 1,
                    "closed_ts_ns": 3,
                    "expected_entry_impact": 5.0,
                    "expected_exit_impact": 7.0,
                },
            ],
            tick_max_drawdown=0.0,
        )
        self.assertEqual(result["impact_adjustment_total"], 120.0)
        self.assertEqual(result["impact_event_count"], 2)
        self.assertEqual(result["impact_adjusted_ending_nav"], 100_880.0)


if __name__ == "__main__":
    unittest.main()
