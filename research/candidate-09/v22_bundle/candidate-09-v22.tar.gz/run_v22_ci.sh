#!/usr/bin/env bash
set -euo pipefail

root=research/candidate-09
out="$root/evidence/latest"
diag="$root/diagnostics/v22-gate-long"

cp "$root/state_engine_v22_direct.py" "$root/state_engine.py"
cp "$root/data_loader_v22.py" "$root/data_loader.py"
cp "$root/run_v22_direct.py" "$root/run.py"
cp "$root/config_v22.json" "$root/config.json"
cp "$root/tests_v22/test_state_engine_v22.py" "$root/tests/test_state_engine.py"
cp "$root/tests_v22/test_data_loader_v22.py" "$root/tests/test_data_loader_v22.py"
cp "$root/tests_v22/test_run_v22_contract.py" "$root/tests/test_run_v22_contract.py"
rm -f \
  "$root/tests/test_state_engine_v17.py" \
  "$root/tests/test_run_v18_contract.py" \
  "$root/tests/test_run_v19_contract.py" \
  "$root/tests/test_run_v20_contract.py" \
  "$root/tests/test_run_v21_contract.py"

cmp -s "$root/state_engine.py" "$root/state_engine_v22_direct.py"
cmp -s "$root/data_loader.py" "$root/data_loader_v22.py"
cmp -s "$root/run.py" "$root/run_v22_direct.py"
cmp -s "$root/config.json" "$root/config_v22.json"
grep -q 'open-interest position-reduction exhaustion reversal' "$root/state_engine.py"
grep -q '"oi-rise"' "$root/run.py"
grep -q 'create_time plus one completed minute' "$root/data_loader.py"

rm -rf "$out" "$diag"
mkdir -p "$out" "$diag"
sha256sum \
  "$root/archive/v4/state_engine.py" \
  "$root/state_engine_v10_direct.py" \
  "$root/state_engine_v13_direct.py" \
  "$root/state_engine_v14_direct.py" \
  "$root/state_engine_v17_direct.py" \
  "$root/state_engine_v18_direct.py" \
  "$root/state_engine_v22_direct.py" \
  "$root/data_loader_v22.py" \
  "$root/run_v22_direct.py" \
  "$root/nautilus_strategy.py" \
  "$root/config_v22.json" \
  "$root/tests_v22/test_state_engine_v22.py" \
  "$root/tests_v22/test_data_loader_v22.py" \
  "$root/tests_v22/test_run_v22_contract.py" > "$diag/source_sha256.txt"

set +e
smc4 doctor > "$diag/doctor.log" 2>&1; doctor=$?
(
  cd "$root"
  python -m compileall -q .
) > "$diag/compile.log" 2>&1; compile=$?
(
  cd "$root"
  python -m unittest discover -s tests -p 'test_*.py' -v
) > "$diag/tests.log" 2>&1; tests=$?
gate=99
if [[ $doctor == 0 && $compile == 0 && $tests == 0 ]]; then
  python "$root/run.py" gate \
    --config "$root/config.json" \
    --cache "$SMC4_DATA_ROOT" \
    --output "$out" \
    --auto-long > "$diag/gate.log" 2>&1
  gate=$?
else
  echo 'gate not run because prerequisite failed' > "$diag/gate.log"
fi
set -e

DOCTOR=$doctor COMPILE=$compile TESTS=$tests GATE=$gate python - <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import os
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

root = Path('research/candidate-09')
out = root / 'evidence/latest'
diag = root / 'diagnostics/v22-gate-long'
codes = {key.lower(): int(os.environ[key]) for key in ('DOCTOR', 'COMPILE', 'TESTS', 'GATE')}
failure = next((name for name, value in codes.items() if value != 0), None)
summary_path = out / 'summary.json'
summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}

payload = {
    'candidate_generation': 'v22-oi-position-reduction-exhaustion',
    'classification': 'IMPLEMENTATION_ERROR' if failure else 'EXECUTED',
    'economic_status': summary.get('status'),
    'codes': codes,
    'first_failure': failure,
    'economic_logic_changed': True,
    'new_state_family': (
        'completed five-minute OI anomaly, aligned price and taker-flow impulse, '
        'failed price progress, and pre-shock auction-edge reclaim'
    ),
    'single_variable_controls': ['no-oi', 'oi-rise', 'no-stall'],
    'unchanged_contracts': [
        'fixed BTC weeks',
        '2022-01-01 through 2025-01-01 exclusive long interval',
        'full composite execution cost',
        'minimum net reward-to-risk 1.2',
        'full-account NAV and 3% planned-loss sizing',
        'NautilusTrader execution and accounting',
    ],
    'metric_causality': 'Binance create_time plus one completed minute before strategy availability',
    'strategy_parameter_search_performed': False,
    'run_id': os.environ.get('GITHUB_RUN_ID'),
    'trigger_sha': os.environ.get('GITHUB_SHA'),
    'full_artifact_name': f"candidate-09-v22-{os.environ.get('GITHUB_RUN_ID')}",
}
diag.mkdir(parents=True, exist_ok=True)
(diag / 'diagnostic.json').write_text(json.dumps(payload, indent=2, sort_keys=True) + '\n')

if not summary_path.exists():
    out.mkdir(parents=True, exist_ok=True)
    summary = {
        'candidate': 'candidate-09-v22',
        'status': 'IMPLEMENTATION_ERROR',
        'first_failure': failure,
        'codes': codes,
    }
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')

events_path = out / 'events.jsonl'
event_types: Counter[str] = Counter()
reasons: Counter[str] = Counter()
next_states: Counter[str] = Counter()
run_event_counts: Counter[str] = Counter()
event_rows = 0
events_sha = hashlib.sha256()
if events_path.exists():
    with events_path.open('rb') as raw:
        for line in raw:
            events_sha.update(line)
            event_rows += 1
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            event_types[str(row.get('event_type'))] += 1
            reasons[str(row.get('reason_code'))] += 1
            next_states[str(row.get('next_state'))] += 1
            run_event_counts[str(row.get('run_id'))] += 1
positioning_reasons = {
    key: value for key, value in reasons.items()
    if any(token in key for token in ('OI_', 'POSITION_', 'PULSE_', 'EQUILIBRIUM_', 'STALLED_'))
}
event_summary = {
    'rows': event_rows,
    'bytes': events_path.stat().st_size if events_path.exists() else 0,
    'sha256': events_sha.hexdigest() if events_path.exists() else None,
    'event_type_counts': dict(event_types.most_common()),
    'reason_code_counts': dict(reasons.most_common()),
    'positioning_state_reason_counts': dict(sorted(positioning_reasons.items())),
    'next_state_counts': dict(next_states.most_common()),
    'run_event_counts': dict(run_event_counts.most_common()),
}
(out / 'event_summary.json').write_text(json.dumps(event_summary, indent=2, sort_keys=True) + '\n')

trades_path = out / 'trades.csv'
groups: dict[str, list[dict[str, str]]] = defaultdict(list)
reason_counts: Counter[str] = Counter()
if trades_path.exists():
    with trades_path.open(newline='', encoding='utf-8') as handle:
        for row in csv.DictReader(handle):
            groups[str(row.get('run_id', 'unknown'))].append(row)
            reason_counts[str(row.get('reason_code'))] += 1
trade_groups = {}
for run_id, rows in sorted(groups.items()):
    pnls = [float(row['net_pnl']) for row in rows]
    rs = [float(row['realized_r']) for row in rows if row.get('realized_r') not in (None, '')]
    trade_groups[run_id] = {
        'trades': len(rows),
        'wins': sum(value > 0 for value in pnls),
        'losses': sum(value < 0 for value in pnls),
        'net_pnl': sum(pnls),
        'mean_realized_r': mean(rs) if rs else None,
    }
(out / 'trade_summary.json').write_text(json.dumps({
    'groups': trade_groups,
    'reason_code_counts': dict(reason_counts.most_common()),
}, indent=2, sort_keys=True) + '\n')

compact_files = {}
for name in ('summary.json', 'REPORT.md', 'outcomes.csv', 'trades.csv', 'fills.csv',
             'run.json', 'data_manifest.json', 'event_summary.json', 'trade_summary.json'):
    path = out / name
    if path.exists():
        compact_files[name] = {
            'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        }
(out / 'compact_manifest.json').write_text(json.dumps({
    'workflow_run_id': os.environ.get('GITHUB_RUN_ID'),
    'trigger_sha': os.environ.get('GITHUB_SHA'),
    'artifact_name': f"candidate-09-v22-{os.environ.get('GITHUB_RUN_ID')}",
    'full_events': event_summary,
    'committable_files': compact_files,
}, indent=2, sort_keys=True) + '\n')

for path in diag.glob('*.log'):
    lines = path.read_text(errors='replace').splitlines()
    path.write_text('\n'.join(lines[-4500:]) + ('\n' if lines else ''))
PY

exit 0
