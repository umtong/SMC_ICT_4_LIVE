"""Causal auction-episode action and geometry research.

This module intentionally does not filter an existing trading policy.  It starts
from pre-existing auction boundaries, observes what price and aggressor flow do
at those boundaries, then enumerates mutually exclusive executable actions:

* failed auction: penetration, reclaim, local control transfer and optional retest;
* accepted auction: close outside, hold, local response and optional retest;
* abstention is represented by leaving all actions unselected later.

Every emitted action fixes entry, invalidation, objective and order expiry using
only information available at emission.  Limit entries are labelled only after a
causal future fill; they are never treated as if entry happened at signal time.
Future bars are used solely by the offline first-passage labeler.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, timedelta
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import pandas as pd


NS_PER_MINUTE = 60_000_000_000
SOURCE_TIMEFRAMES = (15, 60)
OBJECTIVE_TIMEFRAMES = (5, 15, 60)
PIVOT_SPANS: dict[int, tuple[int, ...]] = {
    5: (2, 4),
    15: (2, 4),
    60: (2,),
}
MAKER_FEE_RATE = 0.0002
TAKER_FEE_RATE = 0.0005
ENTRY_SLIPPAGE_TICKS = 2
STOP_SLIPPAGE_TICKS = 2
LIMIT_TRADE_THROUGH_TICKS = 1

CAUSAL_STRUCTURE_POLICY = (
    "CAUSAL_AUCTION:WICK_PIVOTS_ARE_CONFIRMED_ONLY_AFTER_THE_RIGHT_HAND_SPAN_"
    "CLOSES_AND_A_SOURCE_BOUNDARY_MUST_EXIST_BEFORE_ITS_INTERACTION_BAR"
)
ACTION_POLICY = (
    "CAUSAL_AUCTION:FAILED_AND_ACCEPTED_AUCTIONS_OWN_DISTINCT_ACTIONS;EACH_ACTION_"
    "FIXES_ENTRY_INVALIDATION_OBJECTIVE_AND_EXPIRY_BEFORE_FUTURE_LABELS"
)
LIMIT_FILL_POLICY = (
    "CONSERVATIVE_EXECUTION:POST_ONLY_LIMIT_REQUIRES_ONE_TICK_TRADE_THROUGH;STOP_"
    "ON_FILL_BAR_IS_STOP_FIRST;TARGET_ON_FILL_BAR_IS_NOT_CREDITED"
)


@dataclass(frozen=True, slots=True)
class Contract:
    tick_size: float


CONTRACTS: dict[str, Contract] = {
    "BTCUSDT": Contract(0.1),
    "ETHUSDT": Contract(0.01),
    "SOLUSDT": Contract(0.001),
    "XRPUSDT": Contract(0.0001),
}


@dataclass(slots=True)
class PivotLevel:
    level_id: str
    symbol: str
    side: str  # HIGH or LOW
    timeframe_minutes: int
    span: int
    price: float
    lower: float
    upper: float
    event_time_ns: int
    observed_time_ns: int
    observed_index_1m: int
    strength_ratio: float
    defense_count: int
    first_touch_index_1m: int | None = None
    retired_as_source: bool = False

    @property
    def source_kind(self) -> str:
        return f"{self.timeframe_minutes}M_PIVOT_{self.side}"


@dataclass(frozen=True, slots=True)
class Objective:
    objective_id: str
    kind: str
    timeframe_minutes: int
    price: float
    strength_ratio: float


@dataclass(frozen=True, slots=True)
class ActionSpec:
    action_id: str
    episode_id: str
    symbol: str
    event_type: str
    decision_stage: str
    side: str
    emission_index: int
    emission_time_ns: int
    entry_style: str
    entry: float
    stop: float
    target: float
    entry_expiry_minutes: int
    source_level_id: str
    source_kind: str
    source_timeframe_minutes: int
    source_span: int
    source_price: float
    source_lower: float
    source_upper: float
    source_strength_ratio: float
    source_defense_count: int
    source_age_minutes: float
    objective_id: str
    objective_kind: str
    objective_timeframe_minutes: int
    objective_strength_ratio: float
    interaction_time_ns: int
    feature_values: dict[str, Any]


@dataclass(slots=True)
class EpisodeContext:
    episode_id: str
    boundary: PivotLevel
    interaction_index: int
    interaction_time_ns: int
    interaction_extreme: float
    approach: dict[str, float]
    emitted: set[tuple[str, str, str]] = field(default_factory=set)


@dataclass(frozen=True, slots=True)
class LabelResult:
    fill_state: str
    outcome: str
    fill_index: int | None
    fill_time_ns: int | None
    resolution_index: int | None
    resolution_time_ns: int | None
    entry_wait_minutes: float | None
    holding_minutes: float | None
    target_net_r: float
    stop_net_r: float
    net_r: float | None
    mfe_r: float | None
    mae_r: float | None


def _stable_id(*parts: Any) -> str:
    raw = "|".join(str(part) for part in parts)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def _time_ns(index: pd.DatetimeIndex, position: int) -> int:
    return int(index[position].value)


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default


def _median(values: Sequence[float], default: float) -> float:
    finite = [float(value) for value in values if math.isfinite(float(value))]
    return float(np.median(finite)) if finite else default


def _resample_flow(frame: pd.DataFrame, minutes: int) -> pd.DataFrame:
    work = frame.copy()
    work.index = pd.DatetimeIndex(work.pop("open_time_dt")) + pd.Timedelta(minutes=1)
    aggregation = {
        "open": "first",
        "high": "max",
        "low": "min",
        "close": "last",
        "volume": "sum",
        "quote_volume": "sum",
        "count": "sum",
        "taker_buy_volume": "sum",
        "taker_buy_quote_volume": "sum",
    }
    output = work.resample(
        f"{minutes}min",
        label="right",
        closed="right",
        origin="epoch",
    ).agg(aggregation)
    output = output.dropna(subset=["open", "high", "low", "close"])
    output["count"] = output["count"].astype("int64")
    return output


def prepare_one_minute(frame: pd.DataFrame, tick_size: float) -> pd.DataFrame:
    data = frame.copy()
    data.index = pd.DatetimeIndex(data.pop("open_time_dt")) + pd.Timedelta(minutes=1)
    data = data.sort_index()
    quote = data["quote_volume"].astype(float).clip(lower=0.0)
    count = data["count"].astype(float).clip(lower=1.0)
    signed_quote = 2.0 * data["taker_buy_quote_volume"].astype(float) - quote
    body = data["close"].astype(float) - data["open"].astype(float)
    price_range = (data["high"] - data["low"]).astype(float).clip(lower=tick_size)
    log_close = np.log(data["close"].astype(float).clip(lower=tick_size))
    trade_size = quote / count

    prior_quote = quote.shift(1).rolling(60, min_periods=30).median().clip(lower=1e-12)
    prior_abs_delta = signed_quote.abs().shift(1).rolling(60, min_periods=30).median().clip(lower=1e-12)
    prior_abs_body = body.abs().shift(1).rolling(60, min_periods=30).median().clip(lower=tick_size)
    prior_range = price_range.shift(1).rolling(60, min_periods=30).median().clip(lower=tick_size)
    prior_trade_size = trade_size.shift(1).rolling(60, min_periods=30).median().clip(lower=1e-12)

    data["signed_quote"] = signed_quote
    data["delta_share"] = signed_quote / quote.replace(0.0, np.nan)
    data["body"] = body
    data["price_range"] = price_range
    data["close_location"] = (data["close"] - data["low"]) / price_range
    data["activity_ratio"] = quote / prior_quote
    data["delta_ratio"] = signed_quote.abs() / prior_abs_delta
    data["body_ratio"] = body.abs() / prior_abs_body
    data["range_ratio"] = price_range / prior_range
    data["trade_size_ratio"] = trade_size / prior_trade_size
    data["impact_per_activity"] = data["body_ratio"] / data["activity_ratio"].clip(lower=1e-12)
    data["prior_range_1m"] = prior_range
    for minutes in (3, 5, 15, 30, 60):
        data[f"return_{minutes}m"] = log_close.diff(minutes)
        q = quote.rolling(minutes, min_periods=minutes).sum()
        d = signed_quote.rolling(minutes, min_periods=minutes).sum()
        data[f"delta_share_{minutes}m"] = d / q.replace(0.0, np.nan)
        data[f"activity_{minutes}m"] = q / prior_quote.rolling(minutes, min_periods=1).sum().clip(lower=1e-12)
    return data.replace([np.inf, -np.inf], np.nan)


def detect_pivots(
    symbol: str,
    one_minute: pd.DataFrame,
    aggregates: dict[int, pd.DataFrame],
    tick_size: float,
) -> list[PivotLevel]:
    output: list[PivotLevel] = []
    one_index = one_minute.index
    histories: dict[tuple[int, str], list[PivotLevel]] = {}
    for timeframe in OBJECTIVE_TIMEFRAMES:
        bars = aggregates[timeframe]
        ranges = (bars["high"] - bars["low"]).astype(float)
        prior_atr = ranges.shift(1).rolling(20, min_periods=5).median()
        for span in PIVOT_SPANS[timeframe]:
            if len(bars) < 2 * span + 1:
                continue
            highs = bars["high"].to_numpy(dtype=float)
            lows = bars["low"].to_numpy(dtype=float)
            for center in range(span, len(bars) - span):
                window_high = highs[center - span : center + span + 1]
                window_low = lows[center - span : center + span + 1]
                observed_pos = center + span
                observed_time = bars.index[observed_pos]
                observed_1m = int(one_index.searchsorted(observed_time, side="left"))
                if observed_1m >= len(one_index):
                    continue
                atr = _finite(prior_atr.iloc[observed_pos], max(tick_size, ranges.iloc[center]))
                width = max(2.0 * tick_size, 0.06 * atr)
                for side in ("HIGH", "LOW"):
                    if side == "HIGH":
                        unique = highs[center] == window_high.max() and int((window_high == highs[center]).sum()) == 1
                        if not unique:
                            continue
                        prominence = min(
                            highs[center] - window_low[:span].min(),
                            highs[center] - window_low[span + 1 :].min(),
                        )
                        price = highs[center]
                    else:
                        unique = lows[center] == window_low.min() and int((window_low == lows[center]).sum()) == 1
                        if not unique:
                            continue
                        prominence = min(
                            window_high[:span].max() - lows[center],
                            window_high[span + 1 :].max() - lows[center],
                        )
                        price = lows[center]
                    strength = prominence / max(atr, tick_size)
                    key = (timeframe, side)
                    prior_levels = histories.setdefault(key, [])
                    tolerance = max(4.0 * tick_size, 0.18 * atr)
                    defense_count = 1 + sum(
                        1
                        for item in prior_levels[-24:]
                        if item.observed_time_ns < int(observed_time.value)
                        and abs(item.price - price) <= tolerance
                    )
                    level_id = (
                        f"{symbol}:{timeframe}m:{side}:c{center}:s{span}:"
                        f"{int(observed_time.value)}"
                    )
                    level = PivotLevel(
                        level_id=level_id,
                        symbol=symbol,
                        side=side,
                        timeframe_minutes=timeframe,
                        span=span,
                        price=float(price),
                        lower=float(price - width),
                        upper=float(price + width),
                        event_time_ns=int(bars.index[center].value),
                        observed_time_ns=int(observed_time.value),
                        observed_index_1m=observed_1m,
                        strength_ratio=float(strength),
                        defense_count=int(defense_count),
                    )
                    prior_levels.append(level)
                    output.append(level)
    output.sort(key=lambda item: (item.observed_time_ns, item.timeframe_minutes, item.level_id))

    highs_1m = one_minute["high"].to_numpy(dtype=float)
    lows_1m = one_minute["low"].to_numpy(dtype=float)
    for level in output:
        start = level.observed_index_1m + 1
        if start >= len(one_minute):
            continue
        mask = highs_1m[start:] >= level.price if level.side == "HIGH" else lows_1m[start:] <= level.price
        hits = np.flatnonzero(mask)
        if hits.size:
            level.first_touch_index_1m = int(start + hits[0])
    return output


def _approach_features(data: pd.DataFrame, index: int, boundary: PivotLevel) -> dict[str, float]:
    start = max(0, index - 30)
    prior = data.iloc[start:index]
    recent = data.iloc[max(start, index - 8) : index]
    if prior.empty:
        return {}
    closes = prior["close"].to_numpy(dtype=float)
    diffs = np.diff(closes)
    path = float(np.abs(diffs).sum())
    net = float(closes[-1] - closes[0]) if len(closes) > 1 else 0.0
    toward_sign = -1.0 if boundary.side == "LOW" else 1.0
    level = max(abs(boundary.price), 1e-12)
    distance_start = abs(closes[0] - boundary.price) / level * 10_000.0
    distance_end = abs(closes[-1] - boundary.price) / level * 10_000.0
    zone_tolerance = max(boundary.upper - boundary.lower, _finite(prior["prior_range_1m"].iloc[-1], 0.0))
    touches = int(
        (
            (prior["low"] <= boundary.upper + zone_tolerance)
            & (prior["high"] >= boundary.lower - zone_tolerance)
        ).sum()
    )
    return {
        "approach_net_bps": toward_sign * net / level * 10_000.0,
        "approach_path_efficiency": abs(net) / max(path, 1e-12),
        "approach_distance_start_bps": distance_start,
        "approach_distance_end_bps": distance_end,
        "approach_distance_compression": distance_start / max(distance_end, 1e-6),
        "approach_touch_count_30m": float(touches),
        "approach_range_ratio_8v30": (
            _median(recent["price_range"].tolist(), 0.0)
            / max(_median(prior["price_range"].tolist(), 1e-12), 1e-12)
        ),
        "approach_activity_ratio": _finite(recent["activity_ratio"].median(), 0.0),
        "approach_delta_share": _finite(recent["signed_quote"].sum() / max(recent["quote_volume"].sum(), 1e-12), 0.0),
        "approach_impact_per_activity": _finite(recent["impact_per_activity"].median(), 0.0),
    }


def _bar_features(row: pd.Series, prefix: str) -> dict[str, float]:
    fields = (
        "activity_ratio",
        "delta_ratio",
        "delta_share",
        "body_ratio",
        "range_ratio",
        "trade_size_ratio",
        "impact_per_activity",
        "close_location",
    )
    return {f"{prefix}_{field}": _finite(row.get(field), 0.0) for field in fields}


def _signed_progress(side: str, start: float, end: float) -> float:
    return end - start if side == "LONG" else start - end


def _side_sign(side: str) -> float:
    if side == "LONG":
        return 1.0
    if side == "SHORT":
        return -1.0
    raise ValueError(side)


def _source_reversal_side(boundary: PivotLevel) -> str:
    return "LONG" if boundary.side == "LOW" else "SHORT"


def _source_continuation_side(boundary: PivotLevel) -> str:
    return "SHORT" if boundary.side == "LOW" else "LONG"


def _objective_candidates(
    levels: Sequence[PivotLevel],
    *,
    side: str,
    entry: float,
    emission_index: int,
    emission_time_ns: int,
    micro_reference: float | None,
    tick_size: float,
) -> list[Objective]:
    wanted = "HIGH" if side == "LONG" else "LOW"
    candidates: list[Objective] = []
    if micro_reference is not None and (
        (side == "LONG" and micro_reference > entry + tick_size)
        or (side == "SHORT" and micro_reference < entry - tick_size)
    ):
        candidates.append(
            Objective(
                objective_id=f"MICRO:{emission_time_ns}:{micro_reference:.12g}",
                kind="PREINTERACTION_MICRO_CONTROL",
                timeframe_minutes=1,
                price=float(micro_reference),
                strength_ratio=1.0,
            ),
        )
    for level in levels:
        if level.side != wanted or level.observed_time_ns >= emission_time_ns:
            continue
        if level.first_touch_index_1m is not None and level.first_touch_index_1m <= emission_index:
            continue
        if side == "LONG" and level.price <= entry + tick_size:
            continue
        if side == "SHORT" and level.price >= entry - tick_size:
            continue
        candidates.append(
            Objective(
                objective_id=level.level_id,
                kind=level.source_kind,
                timeframe_minutes=level.timeframe_minutes,
                price=level.price,
                strength_ratio=level.strength_ratio,
            ),
        )
    candidates.sort(
        key=lambda item: (
            abs(item.price - entry),
            -item.timeframe_minutes,
            -item.strength_ratio,
            item.objective_id,
        ),
    )
    selected: list[Objective] = []
    for candidate in candidates:
        if any(abs(candidate.price - item.price) <= 2.0 * tick_size for item in selected):
            continue
        selected.append(candidate)
        if len(selected) >= 3:
            break
    return selected


def _economics(
    *,
    side: str,
    entry: float,
    stop: float,
    target: float,
    tick_size: float,
    entry_style: str,
) -> dict[str, float]:
    sign = _side_sign(side)
    risk = abs(entry - stop)
    reward = abs(target - entry)
    if risk <= 0.0 or reward <= 0.0:
        return {}
    entry_fee = MAKER_FEE_RATE if entry_style != "MARKET" else TAKER_FEE_RATE
    entry_slip = 0 if entry_style != "MARKET" else ENTRY_SLIPPAGE_TICKS

    actual_entry = entry + sign * entry_slip * tick_size
    actual_target = target
    actual_stop = stop - sign * STOP_SLIPPAGE_TICKS * tick_size
    target_gross = sign * (actual_target - actual_entry) / risk
    stop_gross = sign * (actual_stop - actual_entry) / risk
    target_fees = (entry_fee * abs(actual_entry) + MAKER_FEE_RATE * abs(actual_target)) / risk
    stop_fees = (entry_fee * abs(actual_entry) + TAKER_FEE_RATE * abs(actual_stop)) / risk
    target_net = target_gross - target_fees
    stop_net = stop_gross - stop_fees
    denominator = target_net - stop_net
    break_even = -stop_net / denominator if denominator > 0.0 else float("nan")
    return {
        "gross_rr": reward / risk,
        "risk_bps": risk / abs(entry) * 10_000.0,
        "target_bps": reward / abs(entry) * 10_000.0,
        "target_net_r": target_net,
        "stop_net_r": stop_net,
        "post_cost_reward_risk": target_net / abs(stop_net) if target_net > 0.0 and stop_net < 0.0 else float("nan"),
        "post_cost_break_even_probability": break_even,
        "round_trip_cost_r_target": reward / risk - target_net,
    }


def _valid_geometry(side: str, entry: float, stop: float, target: float, tick_size: float) -> bool:
    if side == "LONG":
        return stop < entry - tick_size and target > entry + tick_size
    return stop > entry + tick_size and target < entry - tick_size


def _entry_levels(
    *,
    event_type: str,
    side: str,
    decision_close: float,
    boundary: PivotLevel,
    event_extreme: float,
    tick_size: float,
) -> list[tuple[str, str, float]]:
    output = [("MARKET", "MARKET", float(decision_close))]
    if side == "LONG":
        boundary_entry = boundary.upper if event_type == "FAILED_AUCTION" else boundary.lower
        anchor = event_extreme if event_type == "FAILED_AUCTION" else boundary.lower
        half = anchor + 0.5 * (decision_close - anchor)
        limit_values = (
            ("BOUNDARY_LIMIT", boundary_entry),
            ("IMPULSE_HALF_LIMIT", half),
        )
        for name, value in limit_values:
            value = min(float(value), decision_close - tick_size)
            if value > event_extreme + tick_size:
                output.append((name, "LIMIT", value))
    else:
        boundary_entry = boundary.lower if event_type == "FAILED_AUCTION" else boundary.upper
        anchor = event_extreme if event_type == "FAILED_AUCTION" else boundary.upper
        half = anchor - 0.5 * (anchor - decision_close)
        limit_values = (
            ("BOUNDARY_LIMIT", boundary_entry),
            ("IMPULSE_HALF_LIMIT", half),
        )
        for name, value in limit_values:
            value = max(float(value), decision_close + tick_size)
            if value < event_extreme - tick_size:
                output.append((name, "LIMIT", value))
    deduped: list[tuple[str, str, float]] = []
    for item in output:
        if any(abs(item[2] - prior[2]) <= tick_size for prior in deduped):
            continue
        deduped.append(item)
    return deduped


def _make_actions(
    *,
    data: pd.DataFrame,
    levels: Sequence[PivotLevel],
    context: EpisodeContext,
    event_type: str,
    decision_stage: str,
    side: str,
    emission_index: int,
    event_extreme: float,
    stop_reference: float,
    micro_reference: float | None,
    feature_values: dict[str, Any],
    tick_size: float,
) -> list[ActionSpec]:
    row = data.iloc[emission_index]
    decision_close = float(row["close"])
    buffer = max(2.0 * tick_size, 0.05 * _finite(row.get("prior_range_1m"), tick_size))
    stop = stop_reference - buffer if side == "LONG" else stop_reference + buffer
    expiry = 20 if context.boundary.timeframe_minutes <= 15 else 45
    actions: list[ActionSpec] = []
    emission_time_ns = _time_ns(data.index, emission_index)
    for entry_name, order_type, entry in _entry_levels(
        event_type=event_type,
        side=side,
        decision_close=decision_close,
        boundary=context.boundary,
        event_extreme=event_extreme,
        tick_size=tick_size,
    ):
        objectives = _objective_candidates(
            levels,
            side=side,
            entry=entry,
            emission_index=emission_index,
            emission_time_ns=emission_time_ns,
            micro_reference=micro_reference,
            tick_size=tick_size,
        )
        for objective_rank, objective in enumerate(objectives, start=1):
            if not _valid_geometry(side, entry, stop, objective.price, tick_size):
                continue
            economics = _economics(
                side=side,
                entry=entry,
                stop=stop,
                target=objective.price,
                tick_size=tick_size,
                entry_style=order_type,
            )
            if not economics:
                continue
            # Do not create economically impossible geometries.  This is not a
            # performance threshold: a target that pays no positive net R can
            # never have positive expectancy at any probability.
            if economics["target_net_r"] <= 0.0 or economics["stop_net_r"] >= 0.0:
                continue
            key = (decision_stage, entry_name, objective.objective_id)
            if key in context.emitted:
                continue
            context.emitted.add(key)
            action_id = (
                f"AEP:{context.episode_id}:{decision_stage}:{entry_name}:"
                f"T{objective_rank}:{_stable_id(objective.objective_id)}"
            )
            values = {
                **context.approach,
                **feature_values,
                **economics,
                **_bar_features(row, "decision"),
                "event_extreme_bps": abs(event_extreme - context.boundary.price) / max(abs(context.boundary.price), 1e-12) * 10_000.0,
                "decision_progress_bps": _signed_progress(side, context.boundary.price, decision_close) / max(abs(context.boundary.price), 1e-12) * 10_000.0,
                "entry_distance_from_decision_bps": abs(decision_close - entry) / max(abs(entry), 1e-12) * 10_000.0,
                "objective_rank": float(objective_rank),
                "entry_order_type": order_type,
                "causal_structure_policy": CAUSAL_STRUCTURE_POLICY,
                "action_policy": ACTION_POLICY,
                "limit_fill_policy": LIMIT_FILL_POLICY,
            }
            actions.append(
                ActionSpec(
                    action_id=action_id,
                    episode_id=context.episode_id,
                    symbol=context.boundary.symbol,
                    event_type=event_type,
                    decision_stage=decision_stage,
                    side=side,
                    emission_index=emission_index,
                    emission_time_ns=emission_time_ns,
                    entry_style=entry_name,
                    entry=float(entry),
                    stop=float(stop),
                    target=float(objective.price),
                    entry_expiry_minutes=expiry,
                    source_level_id=context.boundary.level_id,
                    source_kind=context.boundary.source_kind,
                    source_timeframe_minutes=context.boundary.timeframe_minutes,
                    source_span=context.boundary.span,
                    source_price=context.boundary.price,
                    source_lower=context.boundary.lower,
                    source_upper=context.boundary.upper,
                    source_strength_ratio=context.boundary.strength_ratio,
                    source_defense_count=context.boundary.defense_count,
                    source_age_minutes=(emission_time_ns - context.boundary.observed_time_ns) / NS_PER_MINUTE,
                    objective_id=objective.objective_id,
                    objective_kind=objective.kind,
                    objective_timeframe_minutes=objective.timeframe_minutes,
                    objective_strength_ratio=objective.strength_ratio,
                    interaction_time_ns=context.interaction_time_ns,
                    feature_values=values,
                ),
            )
    return actions


def _failed_auction_actions(
    data: pd.DataFrame,
    levels: Sequence[PivotLevel],
    context: EpisodeContext,
    tick_size: float,
    horizon_bars: int = 30,
) -> list[ActionSpec]:
    boundary = context.boundary
    side = _source_reversal_side(boundary)
    interaction = context.interaction_index
    end = min(len(data), interaction + horizon_bars + 1)
    before = data.iloc[max(0, interaction - 5) : interaction]
    micro_reference = (
        float(before["high"].max()) if side == "LONG" and not before.empty
        else float(before["low"].min()) if side == "SHORT" and not before.empty
        else None
    )
    extreme = context.interaction_extreme
    first_penetration: int | None = None
    reclaim_index: int | None = None
    detach_index: int | None = None
    cumulative_signed_quote = 0.0
    cumulative_quote = 0.0
    output: list[ActionSpec] = []

    for index in range(interaction, end):
        row = data.iloc[index]
        if side == "LONG":
            penetrated = float(row["low"]) < boundary.lower
            extreme = min(extreme, float(row["low"]))
            reclaimed = penetrated and float(row["close"]) >= boundary.upper
        else:
            penetrated = float(row["high"]) > boundary.upper
            extreme = max(extreme, float(row["high"]))
            reclaimed = penetrated and float(row["close"]) <= boundary.lower
        if penetrated and first_penetration is None:
            first_penetration = index
        cumulative_signed_quote += _side_sign(side) * _finite(row.get("signed_quote"), 0.0)
        cumulative_quote += _finite(row.get("quote_volume"), 0.0)

        if first_penetration is not None and reclaim_index is None:
            if side == "LONG":
                reclaimed = float(row["close"]) >= boundary.upper
            else:
                reclaimed = float(row["close"]) <= boundary.lower
            if reclaimed and index - first_penetration <= 6:
                reclaim_index = index
            elif index - first_penetration > 6:
                break
        if reclaim_index is None:
            continue

        # A local control transfer is deliberately required before the episode
        # owns a reversal action.  Merely closing back inside is not enough.
        if detach_index is None and micro_reference is not None:
            if side == "LONG":
                detached = float(row["close"]) > micro_reference and float(row["close"]) > float(row["open"])
            else:
                detached = float(row["close"]) < micro_reference and float(row["close"]) < float(row["open"])
            if detached:
                detach_index = index
                features = {
                    "penetration_to_reclaim_minutes": float(reclaim_index - first_penetration),
                    "reclaim_to_decision_minutes": float(index - reclaim_index),
                    "episode_cumulative_aligned_delta_share": cumulative_signed_quote / max(cumulative_quote, 1e-12),
                    "reclaim_close_distance_bps": abs(float(data.iloc[reclaim_index]["close"]) - boundary.price) / max(abs(boundary.price), 1e-12) * 10_000.0,
                    **_bar_features(data.iloc[reclaim_index], "reclaim"),
                }
                output.extend(
                    _make_actions(
                        data=data,
                        levels=levels,
                        context=context,
                        event_type="FAILED_AUCTION",
                        decision_stage="RECLAIM_CONTROL_TRANSFER",
                        side=side,
                        emission_index=index,
                        event_extreme=extreme,
                        stop_reference=extreme,
                        micro_reference=micro_reference,
                        feature_values=features,
                        tick_size=tick_size,
                    ),
                )
                continue

        if detach_index is not None and index > detach_index:
            invalidated = float(row["low"]) <= extreme if side == "LONG" else float(row["high"]) >= extreme
            if invalidated:
                break
            retested = (
                float(row["low"]) <= boundary.upper + tick_size
                if side == "LONG"
                else float(row["high"]) >= boundary.lower - tick_size
            )
            response = (
                retested and float(row["close"]) > float(row["open"]) and float(row["close"]) >= boundary.upper
                if side == "LONG"
                else retested and float(row["close"]) < float(row["open"]) and float(row["close"]) <= boundary.lower
            )
            if response:
                prior_row = data.iloc[index - 1]
                control = (
                    float(row["close"]) > float(prior_row["high"])
                    if side == "LONG"
                    else float(row["close"]) < float(prior_row["low"])
                )
                if control:
                    features = {
                        "penetration_to_reclaim_minutes": float(reclaim_index - first_penetration),
                        "reclaim_to_decision_minutes": float(index - reclaim_index),
                        "detach_to_retest_minutes": float(index - detach_index),
                        "episode_cumulative_aligned_delta_share": cumulative_signed_quote / max(cumulative_quote, 1e-12),
                        **_bar_features(data.iloc[reclaim_index], "reclaim"),
                        **_bar_features(row, "retest_response"),
                    }
                    output.extend(
                        _make_actions(
                            data=data,
                            levels=levels,
                            context=context,
                            event_type="FAILED_AUCTION",
                            decision_stage="FIRST_RETEST_RESPONSE",
                            side=side,
                            emission_index=index,
                            event_extreme=extreme,
                            stop_reference=extreme,
                            micro_reference=micro_reference,
                            feature_values=features,
                            tick_size=tick_size,
                        ),
                    )
                    break
    return output


def _accepted_auction_actions(
    data: pd.DataFrame,
    levels: Sequence[PivotLevel],
    context: EpisodeContext,
    tick_size: float,
    horizon_bars: int = 35,
) -> list[ActionSpec]:
    boundary = context.boundary
    side = _source_continuation_side(boundary)
    interaction = context.interaction_index
    end = min(len(data), interaction + horizon_bars + 1)
    before = data.iloc[max(0, interaction - 8) : interaction]
    break_origin = (
        float(before["high"].max()) if side == "SHORT" and not before.empty
        else float(before["low"].min()) if side == "LONG" and not before.empty
        else context.interaction_extreme
    )
    micro_reference = (
        float(before["low"].min()) if side == "SHORT" and not before.empty
        else float(before["high"].max()) if side == "LONG" and not before.empty
        else None
    )
    first_outside: int | None = None
    hold_index: int | None = None
    output: list[ActionSpec] = []
    cumulative_signed_quote = 0.0
    cumulative_quote = 0.0
    event_extreme = context.interaction_extreme

    for index in range(interaction, end):
        row = data.iloc[index]
        cumulative_signed_quote += _side_sign(side) * _finite(row.get("signed_quote"), 0.0)
        cumulative_quote += _finite(row.get("quote_volume"), 0.0)
        if side == "LONG":
            outside = float(row["close"]) > boundary.upper
            event_extreme = max(event_extreme, float(row["high"]))
            reclaimed_inside = float(row["close"]) < boundary.lower
        else:
            outside = float(row["close"]) < boundary.lower
            event_extreme = min(event_extreme, float(row["low"]))
            reclaimed_inside = float(row["close"]) > boundary.upper

        if first_outside is None:
            if outside:
                first_outside = index
            continue
        if reclaimed_inside and hold_index is None:
            break
        if hold_index is None:
            previous = data.iloc[index - 1]
            previous_outside = (
                float(previous["close"]) > boundary.upper
                if side == "LONG"
                else float(previous["close"]) < boundary.lower
            )
            aligned_body = (
                float(row["close"]) > float(row["open"])
                if side == "LONG"
                else float(row["close"]) < float(row["open"])
            )
            if outside and previous_outside and aligned_body:
                hold_index = index
                features = {
                    "break_to_hold_minutes": float(index - first_outside),
                    "episode_cumulative_aligned_delta_share": cumulative_signed_quote / max(cumulative_quote, 1e-12),
                    **_bar_features(data.iloc[first_outside], "break"),
                    **_bar_features(row, "hold"),
                }
                output.extend(
                    _make_actions(
                        data=data,
                        levels=levels,
                        context=context,
                        event_type="ACCEPTED_AUCTION",
                        decision_stage="BREAK_HOLD",
                        side=side,
                        emission_index=index,
                        event_extreme=event_extreme,
                        stop_reference=break_origin,
                        micro_reference=micro_reference,
                        feature_values=features,
                        tick_size=tick_size,
                    ),
                )
                continue

        if hold_index is not None and index > hold_index:
            # The first return to the transferred boundary must close on the new
            # side and show a one-bar response.  A close back through the old
            # auction invalidates continuation immediately.
            if reclaimed_inside:
                break
            retested = (
                float(row["low"]) <= boundary.upper + tick_size
                if side == "LONG"
                else float(row["high"]) >= boundary.lower - tick_size
            )
            if not retested:
                continue
            aligned_body = (
                float(row["close"]) > float(row["open"]) and float(row["close"]) >= boundary.upper
                if side == "LONG"
                else float(row["close"]) < float(row["open"]) and float(row["close"]) <= boundary.lower
            )
            prior = data.iloc[index - 1]
            control = (
                float(row["close"]) > float(prior["high"])
                if side == "LONG"
                else float(row["close"]) < float(prior["low"])
            )
            if aligned_body and control:
                retest_extreme = float(row["low"]) if side == "LONG" else float(row["high"])
                features = {
                    "break_to_hold_minutes": float(hold_index - first_outside),
                    "hold_to_retest_minutes": float(index - hold_index),
                    "episode_cumulative_aligned_delta_share": cumulative_signed_quote / max(cumulative_quote, 1e-12),
                    **_bar_features(data.iloc[first_outside], "break"),
                    **_bar_features(data.iloc[hold_index], "hold"),
                    **_bar_features(row, "retest_response"),
                }
                output.extend(
                    _make_actions(
                        data=data,
                        levels=levels,
                        context=context,
                        event_type="ACCEPTED_AUCTION",
                        decision_stage="FIRST_RETEST_RESPONSE",
                        side=side,
                        emission_index=index,
                        event_extreme=event_extreme,
                        stop_reference=retest_extreme,
                        micro_reference=micro_reference,
                        feature_values=features,
                        tick_size=tick_size,
                    ),
                )
                break
    return output


def label_action(data: pd.DataFrame, action: ActionSpec, tick_size: float) -> LabelResult:
    sign = _side_sign(action.side)
    risk = abs(action.entry - action.stop)
    economics = _economics(
        side=action.side,
        entry=action.entry,
        stop=action.stop,
        target=action.target,
        tick_size=tick_size,
        entry_style="MARKET" if action.entry_style == "MARKET" else "LIMIT",
    )
    target_net = economics["target_net_r"]
    stop_net = economics["stop_net_r"]
    start = action.emission_index + 1
    if start >= len(data):
        return LabelResult("NO_FUTURE", "UNRESOLVED", None, None, None, None, None, None, target_net, stop_net, None, None, None)

    if action.entry_style == "MARKET":
        fill_index = start
        fill_state = "FILLED_MARKET"
    else:
        expiry = min(len(data) - 1, action.emission_index + action.entry_expiry_minutes)
        fill_index = None
        for index in range(start, expiry + 1):
            row = data.iloc[index]
            traded_through = (
                float(row["low"]) <= action.entry - LIMIT_TRADE_THROUGH_TICKS * tick_size
                if action.side == "LONG"
                else float(row["high"]) >= action.entry + LIMIT_TRADE_THROUGH_TICKS * tick_size
            )
            if traded_through:
                fill_index = index
                break
            invalidated = float(row["low"]) <= action.stop if action.side == "LONG" else float(row["high"]) >= action.stop
            target_spent = float(row["high"]) >= action.target if action.side == "LONG" else float(row["low"]) <= action.target
            if invalidated or target_spent:
                return LabelResult(
                    "CANCELED_PRE_FILL_INVALIDATION" if invalidated else "CANCELED_PRE_FILL_TARGET_SPENT",
                    "UNFILLED",
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                    target_net,
                    stop_net,
                    None,
                    None,
                    None,
                )
        if fill_index is None:
            return LabelResult("EXPIRED_UNFILLED", "UNFILLED", None, None, None, None, None, None, target_net, stop_net, None, None, None)
        fill_state = "FILLED_LIMIT"

    fill_time_ns = _time_ns(data.index, fill_index)
    fill_bar = data.iloc[fill_index]
    stop_on_fill = (
        float(fill_bar["low"]) <= action.stop
        if action.side == "LONG"
        else float(fill_bar["high"]) >= action.stop
    )
    target_on_fill = (
        float(fill_bar["high"]) >= action.target
        if action.side == "LONG"
        else float(fill_bar["low"]) <= action.target
    )
    if stop_on_fill:
        return LabelResult(
            fill_state,
            "STOP_FIRST",
            fill_index,
            fill_time_ns,
            fill_index,
            fill_time_ns,
            float(fill_index - action.emission_index),
            0.0,
            target_net,
            stop_net,
            stop_net,
            0.0,
            min(0.0, sign * (float(fill_bar["low"] if action.side == "LONG" else fill_bar["high"]) - action.entry) / risk),
        )
    if target_on_fill:
        # A one-minute bar does not reveal whether the maker fill occurred before
        # or after the target print.  Never credit this as a win or allow a later
        # target revisit to resolve it; keep ittop
     ecision"),
             ter
    atarget
   t0Ot(      min(0.0, sign * (float(fill_bar["low"] if action.side == "LOe == "LOeR   "CANCAR*fS       r["low"     else:
 n        # tar     t; keep itt l_time_ns,
            float(fill_index - action.emission_index),
            0.0,
            target_net,
            stop_net,
            stop_net,
            0.0,
            min(0.0, sign * (float(fill_bar["low"] if action.side == "LONG" else fill_bar[one_tolndex - action.emission_index),
            m_index: int | None = None
    detach                      m_index:On.emission_i[x[center].value),
        net,
         done_toflue),
          **_bar_features traded_thros 0.0 or economics["target_netction.stop,
        target=act= = economics["stop_net_r"]
    start = action.e=ne-minute bar does not reveal whether the maker fill occurred before
al whether2efore
al i  return LabelResult("EXPIRED_UNFILLED", "ary.turn .EXPIRED1ex,
          )
 _ion_inde target=action.taarget=action.taarget=ac        )
 _io], "ary.turn  )ROUGH_TICKS * filloiaction.side == "L"0111111on.st      )
  economccu      done_toflue)= one_minute["Tname,
          )
               float(r111111on.st    =(int | Non_inde targrult("EXPIREopen"])
 {0.0,
 _000.0,
     _side;
         11on.s _io], "ary.turn  )ROUGHy.price) / level * 10_00         11on.s _io], "ary.turn  )ROU      el * 1r["hirn  )ROU  lde = float(rowturn  level * 1     rn output


def _acceptedxt,
 * 1     rn output
ue)= one_minute["Tner the m.side == "L"0111111on.st  float(row["oC<         close"]) arence,
            levels=levels,
                            target_spenc_x:On.emission_i[x[c   _       )
           "]) areninde targetIptedxt,
 * 1  nde .stop,
        target=act= = econom111on.st  fli    ldata.iloc[first_outside], "break"),
                    **_bar_features(data.iloc[hold_index], "hold"),
                    =
boundary.lower
         x:On.dex], "holdary.lower
   ep itt l_tfli 1r["hirn  )ROU          hirnion_inde target=action.ry.lot[tput=
   float(         "]) atick_size=tick_size,
                rget_sp st   _
   float(        "])"o"rgetIptedxoh  None,
                    None,
          None,
                oat(                                                                  =
boundary.lower
 hold"),
                e_tion.stop
         }                No_ion.                 _make_actions(
                        data=data,
                        levels=levels,
                        context=context,
                        event_type="ACCEPTED_AUCTION",
                        decision_stage="BREAK_HOLD",
   *     -       =
bo]*]     }                          _ma.   tIptedxoh  None,
      *     -        -       =top_net_r"]
    start = ac - 8) u         e6 ovfore.empty0wrig     de;tIptedxoh  No                  "breakhare"aat_spex + act        _        "g     de;tIp   levels=l      f stop_o    =
b              p_o    =
b      [4}e
        # or after    11on.s _io], "ary.turn  )ROUGHy.price) / level * 10_00         11on.s _io], "ary.turn  )ROU      el * 1r["hirn  )ROU 3 ecp
         }                No_ion.            _tim   _r"]
      _, "ary.p,
 p
3 ecp
         }r     3  11on.s _ir,
    decision_s   _       )
        op_o   ecp
         }A     )
        o       action.  Merely closin[size fo00,8     }r     hodeContext,
    tiindex),
            0.0,
            target_net,
            stop_net,
            stop_net,
            0.0,
            min(0.0, sign * (float(fill_bar["low"] if action.side == "LONG" else fill_bar["high"]) - action.entry) / risk),
        )
    i_net,
       per_activity": _finite(recent["impact_per_activity"].median(), 0.0),
    }
OUGHy.priceD_UNFe"),
         eturn       laimed_inRs    ) > boundary.upper

      _minute["Tn"]) - 11on.s _io],   p_o         > bomed_inRs    )     nde targeh"]) >=       ar[",
  tion.entry) 
OUGHy.price                    m_index:On.emission_00000,
  ti.     (d="PREINTERACd"),
               ]er

      _minutsC
           l_time_ns,
  ]) >=   ,       =_   .stop
         }   n.s _io]_featu       }         }   n.s   n.s _io]_featu       }         }   n.s   n.
nce,
      no,       =_   .stop
         }   n.s _io]_featu       }         }   n.s   n.s _io]_featu       }         }   n.s   n.
non_00000,
  ti.
                 event_R       target_nete = None
    output: listrn  )RRATE
art = n       )
    if tad              ame,
]fill_state            fl   None,
                    None,
                    target_net,
                    stop_net,
                    None,
                    None,       _     ta.iloc[hdTE
art = n     _       )
 h  No "price_ran _     tction.ry.don_index),
            m_index: int | None = None
    detach                      m_index:On.emission_i[x[center].value),
        net,
         done_toflue),
          **_bar_features traded_thros 0.0 or economics["target_netction.stop,
        target=act= =ower - tick_size
            )
            =}    cl=acte_ns,
  _time_ns: int,
    micro_e;tIp (6nt,
     L00,8   0,
                      actraded_thros 0i_ty
          m_iIREopen"])et_r"]
    s   n.s _io]_feaendex),
  conte. start: float, end: float) -> floatfloat, end: float) -nf  cl=acte_target_net,
      coE    rely cloans: int,
    micro_e;tIp (6nt,
     L00,8   0,
       ) <= extremp"D) >= e_target_net,
      coE    rely cloans: int,
    micro_e;tIp (6nt,
     L00,8   0,
       ) <= extremp"D) >= e_target_net,
  
   0,8"rowZ micro_e;tIp (r      _str >= e_targeORT"

      net,
 w["source_conomics:
     contex    crce_hNone,       _       aontex    crce_hNone,            ) <= extrempn.tar_hNo aontwitt l_tfuex    crce_hNone,            ) <= extremp level.price >= rce_hNone,       None,9            _str >= e_targ    crce_hNone,            ) <= extrempn.tar_hNo aontwitt l_tfue       retur   levels=levels,  o     _str >R  co3rg        [=oc[indned_quotcro_refere,
  d_index is None:     target_net,
  == "L1ne:            m_rce_level_id=context.bou         m L0==   *     -   <ntwi_ # auction ininvalidates        a   entrytp)
    u_index),
 ,
  [    -   <ntwi_ # auctinite(     "episode_     }
          ) <= extrempn.tar_1on.st  fli    ldata.i      )) if side == a )ROU      el          p_   ),
        )
    candidates.so+)ROU      el          p_   ),
        )
    candidates.so+)R"o_refere,
  d       bo]*]     e    ne TAKER_FEE_RATE
    entry_slip = 0 if f tad            y.low     bo]*      Nontry=ac=                                                                               _str >R  co3rT1"tivet = n       t=ac  ),ck_size=tick_size,
                        +)ROU  6a or after M]e]size=tickVa or _slip =_feaendeefere,ntry_slip=u  stop = sce_kind=context.boundary.source_kind,
                              e, "LIMIT", value))
d event_R     p_o    =
b      [4}e
        # oR         t_r"]
        #    _str >= e_r"]
       o3rT1"tiD", None, None, No", None, No micro_reference=mic=        # ouNo micro_reference=mi     5         b
def _failed_(ce=mi     5   _  continue
        if rec= min(l         None,       _     ta.iloc[hdTE
art =     el          p aontex    crce_hNoneomed_inRs    )     nde taize,
 .sort(iul whetnary.lower - tick_sssssssss
(   tick_size=t(ce= e_r"] n.s            stoped and2),
        k_sssastoped and2),
enary.loweru: int | ard_rd_inRs    )ped a_levels=l      f stop_o    =
b              p_o    =
b      [4}eH boundaro_referen   }         }   n.s   n.
nce,
      no,       =__levels=       Lmics["stop_w89:         cision_u =
b     cision_u =omed_inRs    )     nde taize,
 .sort(iul whetNone,            ) <= extremp   )
           **_bar_featuraminute["Tn"]                   remp   )
       action_      aa remp   )
      if side == "e,
          None,
                oat(_ =__levels=  ame = max(event_extreme, float(row["hia"] n.s       None,       [aminute["T1f{!!!!!!!!! "e,
even_probability": bs     t_netPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP    tart 
    stop_on_fill =}          T,etac6"        "
    t      _minute["Tn"5    el"Tn"]) - 11on.s _io],   p_o         > bomed_inRs    )     nde targeh"]) >=       ar[",
  tion.entry) 
OUGHy.price                    m_index:On.emission_00000,
  ti.     (d="PREINTERACd"),
               ]er

      _minutsC
           l_time_ns,
  ]) >=   , lM           l_time_ns,
  ]) >=   , lM           l_time_ns,
  ]) >=   , lM           l_time_ns,
  ]) >=   , lM           l_time_ns,
  ]) >=   , lM           l_time_ns,
  ]) >=   , lM           l_time_ns,
  ]) >=   , lM           l_time_ns,TERACd   time_ns,
  ]) >=   ,   "]) atick_size=tick_size=       , eeuels=l_r"]
    kwmx], "rfapppp)
  rizon_bars + 1)e))
d event_R     p_o   k_size=tick_size=      data,fr  [4}eH boundedit this as    return LabelR   target_net,
  == "L1ne:            m_rce_level_id=context.bou         m L0==   *     -   <ntwi_ # auction ininvalidates        a   entrytp)
    u_index),
 ,
  [    -   <ntwi_ # auctinite(     "episode_     }
          ) <= extrempn.tar_1on.st  fli    ldat 1)e))
d event_R     p_o   k_size=tick_size=      data,fr  [4}eH boundedit ttick_size=               ,8   0,
       ) <= extremp"D) >= e_target_net,
      coE    rely cloans: int,
    micro_e;tIp (6nt,
     L00,8   0,
       ) <= extremp"D) >= e_target_net,
  
   0,8"rowZ micro_e;tIp (r      _str >= e_targeORT"

      net,
 w["source_conomics:
     contex  t close on t